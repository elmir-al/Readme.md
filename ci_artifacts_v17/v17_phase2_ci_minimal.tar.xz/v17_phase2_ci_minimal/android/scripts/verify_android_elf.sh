#!/usr/bin/env bash
# Copyright © 2026 Elmir Hajizada
# All rights reserved.
#
# This software was independently designed and developed for the
# Albay Russian Draughts Engine project.
set -euo pipefail
SO_PATH="${1:-}"
NDK_ROOT="${2:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
[[ -n "${SO_PATH}" && -f "${SO_PATH}" ]] || { echo "Usage: $0 libalbay.so [ndk]" >&2; exit 2; }
case "$(uname -s)" in
  Darwin) HOST_TAG="darwin-x86_64" ;;
  Linux) HOST_TAG="linux-x86_64" ;;
  *) echo "Unsupported host" >&2; exit 2 ;;
esac
READELF="${NDK_ROOT}/toolchains/llvm/prebuilt/${HOST_TAG}/bin/llvm-readelf"
NM="${NDK_ROOT}/toolchains/llvm/prebuilt/${HOST_TAG}/bin/llvm-nm"
[[ -x "${READELF}" && -x "${NM}" ]] || { echo "NDK LLVM tools unavailable" >&2; exit 2; }
HEADER="$(${READELF} -h "${SO_PATH}")"
grep -q 'Class:.*ELF64' <<<"${HEADER}"
grep -Eq 'Machine:.*AArch64' <<<"${HEADER}"
PROGRAM_HEADERS="$(${READELF} -lW "${SO_PATH}")"
while IFS= read -r line; do
  [[ "${line}" =~ ^[[:space:]]*LOAD ]] || continue
  align_hex="$(awk '{print $NF}' <<<"${line}")"
  (( $((align_hex)) >= 16384 )) || { echo "Unaligned LOAD: ${line}" >&2; exit 4; }
done <<<"${PROGRAM_HEADERS}"
if ${READELF} -dW "${SO_PATH}" | grep -q TEXTREL; then echo "TEXTREL detected" >&2; exit 5; fi
SYMBOLS="$(${NM} -D --defined-only "${SO_PATH}")"
for symbol in albay_engine_create JNI_OnLoad \
  Java_com_elmirhajizada_albay_AlbayNative_nativeCreate \
  Java_com_elmirhajizada_albay_AlbayNative_nativeGetBuildInfo; do
  grep -q " ${symbol}$" <<<"${SYMBOLS}" || { echo "Missing export: ${symbol}" >&2; exit 6; }
done
echo "ELF64 AArch64: PASS"
echo "16 KiB LOAD alignment: PASS"
echo "TEXTREL: none"
echo "C API and JNI exports: PASS"
