#!/usr/bin/env bash
# Copyright © 2026 Elmir Hajizada
# All rights reserved.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
NDK_ROOT="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
API_LEVEL="${ANDROID_API_LEVEL:-29}"
CPU_PROFILE="${CPU_PROFILE:-portable}"
PAIR_ROOT="${PAIR_OUT_DIR:-${ROOT_DIR}/build/v17-phase2-arm64-pair}"
BASELINE_HEADER="${ROOT_DIR}/android/v17_phase2_baseline/include/albay/move.hpp"

[[ -n "${NDK_ROOT}" ]] || { echo "ANDROID_NDK_HOME tələb olunur" >&2; exit 2; }
[[ -f "${NDK_ROOT}/source.properties" ]] || { echo "NDK source.properties tapılmadı" >&2; exit 2; }
grep -q 'Pkg.Revision = 29.0.14206865' "${NDK_ROOT}/source.properties" || {
  echo "Android NDK 29.0.14206865 tələb olunur" >&2; exit 2;
}
[[ -f "${BASELINE_HEADER}" ]] || { echo "V16 baseline move.hpp tapılmadı" >&2; exit 2; }

rm -rf "${PAIR_ROOT}"
mkdir -p "${PAIR_ROOT}/source-baseline" "${PAIR_ROOT}/artifacts"
# Recreate the exact pre-V17 MoveList in an isolated source tree. The candidate
# remains the current source tree. This prevents compiler/toolchain drift in the
# pair: both libraries are built in one job with the same NDK, flags and API.
tar -C "${ROOT_DIR}" --exclude='./build' --exclude='./.git' -cf - . \
  | tar -C "${PAIR_ROOT}/source-baseline" -xf -
cp "${BASELINE_HEADER}" "${PAIR_ROOT}/source-baseline/include/albay/move.hpp"

build_one() {
  local source_dir="$1"
  local out_dir="$2"
  cmake -S "${source_dir}" -B "${out_dir}" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="${NDK_ROOT}/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a \
    -DANDROID_PLATFORM="android-${API_LEVEL}" \
    -DANDROID_STL=c++_static \
    -DCMAKE_BUILD_TYPE=Release \
    -DALBAY_BUILD_TESTS=OFF \
    -DALBAY_BUILD_TOOLS=OFF \
    -DALBAY_BUILD_JNI=ON \
    -DALBAY_ENABLE_LTO=OFF \
    -DALBAY_ENABLE_THIN_LTO=OFF \
    -DALBAY_ENABLE_PGO_GENERATE=OFF \
    -DALBAY_ENABLE_PGO_USE=OFF \
    -DALBAY_ANDROID_CPU_PROFILE="${CPU_PROFILE}" \
    -DALBAY_ANDROID_16K_PAGE_ALIGNMENT=ON
  cmake --build "${out_dir}" --target albay --parallel "${BUILD_JOBS:-2}"
}

build_one "${PAIR_ROOT}/source-baseline" "${PAIR_ROOT}/build-baseline"
build_one "${ROOT_DIR}" "${PAIR_ROOT}/build-candidate"

BASELINE_SO="${PAIR_ROOT}/artifacts/libalbay_v16_baseline.so"
CANDIDATE_SO="${PAIR_ROOT}/artifacts/libalbay_v17_phase2.so"
cp "${PAIR_ROOT}/build-baseline/libalbay.so" "${BASELINE_SO}"
cp "${PAIR_ROOT}/build-candidate/libalbay.so" "${CANDIDATE_SO}"

"${ROOT_DIR}/android/scripts/verify_android_elf.sh" "${BASELINE_SO}" "${NDK_ROOT}"
"${ROOT_DIR}/android/scripts/verify_android_elf.sh" "${CANDIDATE_SO}" "${NDK_ROOT}"
python3 "${ROOT_DIR}/android/scripts/verify_v17_phase2_pair.py" \
  --baseline "${BASELINE_SO}" \
  --candidate "${CANDIDATE_SO}" \
  --ndk "${NDK_ROOT}" \
  --output "${PAIR_ROOT}/artifacts/V17_PHASE2_ARM64_PAIR_MANIFEST.json"

(
  cd "${PAIR_ROOT}/artifacts"
  sha256sum libalbay_v16_baseline.so libalbay_v17_phase2.so \
    > V17_PHASE2_ARM64_PAIR_SHA256.txt
)
echo "V17 Phase 2 ARM64 pair hazırdır: ${PAIR_ROOT}/artifacts"
