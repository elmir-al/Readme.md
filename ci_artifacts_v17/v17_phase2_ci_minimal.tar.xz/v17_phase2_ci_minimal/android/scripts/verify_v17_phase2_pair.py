#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any

REQUIRED_EXPORTS = {
    "albay_engine_create",
    "albay_engine_destroy",
    "albay_engine_set_position",
    "albay_engine_generate_legal_moves",
    "JNI_OnLoad",
    "Java_com_elmirhajizada_albay_AlbayNative_nativeCreate",
    "Java_com_elmirhajizada_albay_AlbayNative_nativeGetBuildInfo",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run(*args: str) -> str:
    return subprocess.run(args, check=True, text=True, capture_output=True).stdout


def host_tag() -> str:
    import platform
    system = platform.system()
    if system == "Linux":
        return "linux-x86_64"
    if system == "Darwin":
        return "darwin-x86_64"
    raise SystemExit(f"dəstəklənməyən host: {system}")


def inspect(path: Path, ndk: Path) -> dict[str, Any]:
    tools = ndk / "toolchains" / "llvm" / "prebuilt" / host_tag() / "bin"
    readelf = tools / "llvm-readelf"
    nm = tools / "llvm-nm"
    if not readelf.is_file() or not nm.is_file():
        raise SystemExit("NDK llvm-readelf/llvm-nm tapılmadı")
    header = run(str(readelf), "-h", str(path))
    if "ELF64" not in header or "AArch64" not in header:
        raise SystemExit(f"ARM64 ELF deyil: {path}")
    program = run(str(readelf), "-lW", str(path))
    alignments: list[int] = []
    for line in program.splitlines():
        fields = line.split()
        if fields and fields[0] == "LOAD":
            alignments.append(int(fields[-1], 16))
    if not alignments or min(alignments) < 16384:
        raise SystemExit(f"16 KiB LOAD alignment pozulub: {path}")
    dynamic = run(str(readelf), "-dW", str(path))
    if "TEXTREL" in dynamic:
        raise SystemExit(f"TEXTREL tapıldı: {path}")
    symbols_text = run(str(nm), "-D", "--defined-only", str(path))
    exports = sorted(line.split()[-1] for line in symbols_text.splitlines() if line.split())
    missing = sorted(REQUIRED_EXPORTS.difference(exports))
    if missing:
        raise SystemExit(f"eksport çatışmır ({path.name}): {missing}")
    needed = []
    for line in dynamic.splitlines():
        if "(NEEDED)" in line and "[" in line:
            needed.append(line.split("[", 1)[1].split("]", 1)[0])
    return {
        "file": path.name,
        "size_bytes": path.stat().st_size,
        "sha256": sha256(path),
        "load_alignments": alignments,
        "needed": sorted(needed),
        "exports": exports,
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--baseline", type=Path, required=True)
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--ndk", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    baseline = inspect(args.baseline.resolve(), args.ndk.resolve())
    candidate = inspect(args.candidate.resolve(), args.ndk.resolve())
    if baseline["exports"] != candidate["exports"]:
        raise SystemExit("baseline və candidate export siyahıları fərqlidir")
    if baseline["needed"] != candidate["needed"]:
        raise SystemExit("baseline və candidate NEEDED kitabxanaları fərqlidir")
    if baseline["sha256"] == candidate["sha256"]:
        raise SystemExit("candidate binary baseline ilə eynidir; V17 dəyişiklik düşməyib")
    report = {
        "schema": "albay-v17-phase2-arm64-pair-1",
        "ndk_revision": "29.0.14206865",
        "abi": "arm64-v8a",
        "android_api": 29,
        "cpp_runtime": "c++_static",
        "cpu_profile": "portable",
        "thinlto": False,
        "pgo": False,
        "baseline": baseline,
        "candidate": candidate,
        "same_exports": True,
        "same_needed_libraries": True,
        "different_binary_sha256": True,
        "device_speed_claimed": False,
    }
    rendered = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
