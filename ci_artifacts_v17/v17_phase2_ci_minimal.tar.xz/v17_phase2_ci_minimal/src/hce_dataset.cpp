/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/hce_dataset.hpp"

#include "albay/geometry.hpp"
#include "albay/movegen.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cstring>
#include <fstream>
#include <limits>
#include <string_view>
#include <unordered_map>
#include <unordered_set>

namespace albay {
namespace {

constexpr std::array<char, 8> kMagic{{'A', 'L', 'B', 'H', 'C', 'E', '2', '9'}};
constexpr std::uint64_t kFnvOffset = 1469598103934665603ULL;
constexpr std::uint64_t kFnvPrime = 1099511628211ULL;

[[nodiscard]] constexpr std::uint64_t mix64(std::uint64_t value) noexcept {
    value ^= value >> 30U;
    value *= 0xBF58476D1CE4E5B9ULL;
    value ^= value >> 27U;
    value *= 0x94D049BB133111EBULL;
    value ^= value >> 31U;
    return value;
}

[[nodiscard]] constexpr std::size_t phase_index(HcePhase phase) noexcept {
    return static_cast<std::size_t>(phase);
}
[[nodiscard]] constexpr std::size_t split_index(HceSplit split) noexcept {
    return static_cast<std::size_t>(split);
}
[[nodiscard]] constexpr std::size_t source_index(HceSource source) noexcept {
    return static_cast<std::size_t>(source);
}

void fnv_update(std::uint64_t& hash, const std::uint8_t* data, std::size_t size) noexcept {
    for (std::size_t index = 0; index < size; ++index) {
        hash ^= static_cast<std::uint64_t>(data[index]);
        hash *= kFnvPrime;
    }
}

void put_u16(std::uint8_t* output, std::uint16_t value) noexcept {
    output[0] = static_cast<std::uint8_t>(value & 0xFFU);
    output[1] = static_cast<std::uint8_t>((value >> 8U) & 0xFFU);
}
void put_i16(std::uint8_t* output, std::int16_t value) noexcept {
    put_u16(output, static_cast<std::uint16_t>(value));
}
void put_u32(std::uint8_t* output, std::uint32_t value) noexcept {
    for (int shift = 0; shift < 32; shift += 8) {
        output[shift / 8] = static_cast<std::uint8_t>((value >> shift) & 0xFFU);
    }
}
void put_u64(std::uint8_t* output, std::uint64_t value) noexcept {
    for (int shift = 0; shift < 64; shift += 8) {
        output[shift / 8] = static_cast<std::uint8_t>((value >> shift) & 0xFFU);
    }
}
[[nodiscard]] std::uint16_t get_u16(const std::uint8_t* input) noexcept {
    return static_cast<std::uint16_t>(input[0]) |
        static_cast<std::uint16_t>(static_cast<std::uint16_t>(input[1]) << 8U);
}
[[nodiscard]] std::int16_t get_i16(const std::uint8_t* input) noexcept {
    return static_cast<std::int16_t>(get_u16(input));
}
[[nodiscard]] std::uint32_t get_u32(const std::uint8_t* input) noexcept {
    std::uint32_t value = 0;
    for (int shift = 0; shift < 32; shift += 8) {
        value |= static_cast<std::uint32_t>(input[shift / 8]) << shift;
    }
    return value;
}
[[nodiscard]] std::uint64_t get_u64(const std::uint8_t* input) noexcept {
    std::uint64_t value = 0;
    for (int shift = 0; shift < 64; shift += 8) {
        value |= static_cast<std::uint64_t>(input[shift / 8]) << shift;
    }
    return value;
}

[[nodiscard]] Square mirror_square(Square square) noexcept {
    const BoardCoordinate coordinate = coordinate_of(square);
    const int first_file = (coordinate.rank % 2 == 0) ? 0 : 1;
    const int compressed_file = (coordinate.file - first_file) / 2;
    return square_from_file_rank(first_file + 2 * (3 - compressed_file), coordinate.rank);
}

[[nodiscard]] Square rotate_square_180(Square square) noexcept {
    const BoardCoordinate coordinate = coordinate_of(square);
    return square_from_file_rank(7 - coordinate.file, 7 - coordinate.rank);
}

[[nodiscard]] Bitboard rotate_bitboard_180(Bitboard board) noexcept {
    Bitboard result = 0;
    while (board != 0) {
        const Square square = static_cast<Square>(std::countr_zero(board));
        board &= board - 1U;
        result |= bit(rotate_square_180(square));
    }
    return result;
}

[[nodiscard]] Bitboard mirror_bitboard(Bitboard board) noexcept {
    Bitboard result = 0;
    while (board != 0) {
        const Square square = static_cast<Square>(std::countr_zero(board));
        board &= board - 1U;
        result |= bit(mirror_square(square));
    }
    return result;
}

[[nodiscard]] bool tuple_less(
    Bitboard white_a, Bitboard black_a, Bitboard kings_a,
    Bitboard white_b, Bitboard black_b, Bitboard kings_b) noexcept {
    if (white_a != white_b) return white_a < white_b;
    if (black_a != black_b) return black_a < black_b;
    return kings_a < kings_b;
}

void encode_record(const HceRecord& record, std::array<std::uint8_t, kHceDatasetRecordBytes>& bytes) noexcept {
    bytes.fill(0);
    put_u32(bytes.data() + 0, record.white);
    put_u32(bytes.data() + 4, record.black);
    put_u32(bytes.data() + 8, record.kings);
    put_u64(bytes.data() + 12, record.group_id);
    put_i16(bytes.data() + 20, record.teacher_score_white);
    put_u16(bytes.data() + 22, record.ply);
    put_u16(bytes.data() + 24, record.no_progress_plies);
    put_u16(bytes.data() + 26, record.flags);
    bytes[28] = record.side_to_move == Color::White ? 0U : 1U;
    bytes[29] = static_cast<std::uint8_t>(record.phase);
    bytes[30] = static_cast<std::uint8_t>(record.split);
    bytes[31] = static_cast<std::uint8_t>(record.source);
    bytes[32] = static_cast<std::uint8_t>(record.game_result_white);
    bytes[33] = record.teacher_depth;
    put_u16(bytes.data() + 34, record.reserved);
}

[[nodiscard]] HceRecord decode_record(const std::uint8_t* bytes) noexcept {
    HceRecord record{};
    record.white = get_u32(bytes + 0);
    record.black = get_u32(bytes + 4);
    record.kings = get_u32(bytes + 8);
    record.group_id = get_u64(bytes + 12);
    record.teacher_score_white = get_i16(bytes + 20);
    record.ply = get_u16(bytes + 22);
    record.no_progress_plies = get_u16(bytes + 24);
    record.flags = get_u16(bytes + 26);
    record.side_to_move = bytes[28] == 0 ? Color::White : Color::Black;
    record.phase = static_cast<HcePhase>(bytes[29]);
    record.split = static_cast<HceSplit>(bytes[30]);
    record.source = static_cast<HceSource>(bytes[31]);
    record.game_result_white = static_cast<std::int8_t>(bytes[32]);
    record.teacher_depth = bytes[33];
    record.reserved = get_u16(bytes + 34);
    return record;
}

[[nodiscard]] HceDatasetHeader summarize_records(
    const std::vector<HceRecord>& records,
    std::uint64_t seed,
    std::uint64_t payload_checksum) {
    HceDatasetHeader header{};
    header.record_count = records.size();
    header.seed = seed;
    header.payload_fnv1a64 = payload_checksum;
    std::unordered_set<std::uint64_t> groups;
    groups.reserve(records.size() / 8 + 1);
    for (const HceRecord& record : records) {
        ++header.phase_counts[phase_index(record.phase)];
        ++header.split_counts[split_index(record.split)];
        ++header.source_counts[source_index(record.source)];
        if ((record.flags & HceGameResultKnown) != 0) ++header.known_result_count;
        if ((record.flags & HceTeacherScoreKnown) != 0) ++header.known_teacher_score_count;
        groups.insert(record.group_id);
    }
    header.unique_group_count = groups.size();
    return header;
}

void encode_header(const HceDatasetHeader& header, std::array<std::uint8_t, kHceDatasetHeaderBytes>& bytes) noexcept {
    bytes.fill(0);
    std::memcpy(bytes.data(), kMagic.data(), kMagic.size());
    put_u32(bytes.data() + 8, header.format_version);
    put_u32(bytes.data() + 12, header.header_bytes);
    put_u32(bytes.data() + 16, header.record_bytes);
    put_u64(bytes.data() + 24, header.record_count);
    put_u64(bytes.data() + 32, header.seed);
    put_u64(bytes.data() + 40, header.payload_fnv1a64);
    std::size_t offset = 48;
    for (const std::uint64_t value : header.phase_counts) {
        put_u64(bytes.data() + offset, value);
        offset += 8;
    }
    for (const std::uint64_t value : header.split_counts) {
        put_u64(bytes.data() + offset, value);
        offset += 8;
    }
    for (const std::uint64_t value : header.source_counts) {
        put_u64(bytes.data() + offset, value);
        offset += 8;
    }
    put_u64(bytes.data() + 152, header.known_result_count);
    put_u64(bytes.data() + 160, header.known_teacher_score_count);
    put_u64(bytes.data() + 168, header.unique_group_count);
}

[[nodiscard]] bool decode_header(
    const std::array<std::uint8_t, kHceDatasetHeaderBytes>& bytes,
    HceDatasetHeader& header,
    std::string* error) {
    auto fail = [error](const char* message) {
        if (error != nullptr) *error = message;
        return false;
    };
    if (!std::equal(kMagic.begin(), kMagic.end(), bytes.begin())) return fail("invalid HCE dataset magic");
    header.format_version = get_u32(bytes.data() + 8);
    header.header_bytes = get_u32(bytes.data() + 12);
    header.record_bytes = get_u32(bytes.data() + 16);
    if (header.format_version != kHceDatasetFormatVersion) return fail("unsupported HCE dataset version");
    if (header.header_bytes != kHceDatasetHeaderBytes || header.record_bytes != kHceDatasetRecordBytes) {
        return fail("HCE dataset record/header size mismatch");
    }
    header.record_count = get_u64(bytes.data() + 24);
    header.seed = get_u64(bytes.data() + 32);
    header.payload_fnv1a64 = get_u64(bytes.data() + 40);
    std::size_t offset = 48;
    for (std::uint64_t& value : header.phase_counts) {
        value = get_u64(bytes.data() + offset);
        offset += 8;
    }
    for (std::uint64_t& value : header.split_counts) {
        value = get_u64(bytes.data() + offset);
        offset += 8;
    }
    for (std::uint64_t& value : header.source_counts) {
        value = get_u64(bytes.data() + offset);
        offset += 8;
    }
    header.known_result_count = get_u64(bytes.data() + 152);
    header.known_teacher_score_count = get_u64(bytes.data() + 160);
    header.unique_group_count = get_u64(bytes.data() + 168);
    return true;
}

struct PositionKey {
    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    std::uint8_t side = 0;
    [[nodiscard]] bool operator==(const PositionKey&) const noexcept = default;
};
struct PositionKeyHash {
    [[nodiscard]] std::size_t operator()(const PositionKey& key) const noexcept {
        std::uint64_t value = static_cast<std::uint64_t>(key.white) |
            (static_cast<std::uint64_t>(key.black) << 32U);
        value ^= mix64(static_cast<std::uint64_t>(key.kings) |
            (static_cast<std::uint64_t>(key.side) << 40U));
        return static_cast<std::size_t>(mix64(value));
    }
};

}  // namespace

HcePhase classify_hce_phase(const Position& position) noexcept {
    const int pieces = std::popcount(position.occupied());
    if (pieces <= 8) {
        return position.kings() == 0 ? HcePhase::ManEndgame : HcePhase::KingEndgame;
    }
    return pieces >= 20 ? HcePhase::Opening : HcePhase::Middlegame;
}

HceSplit hce_split_for_group(std::uint64_t group_id, std::uint64_t seed) noexcept {
    const std::uint64_t bucket = mix64(group_id ^ mix64(seed)) % 100ULL;
    if (bucket < 70ULL) return HceSplit::Train;
    if (bucket < 85ULL) return HceSplit::Validation;
    return HceSplit::Holdout;
}

HceCanonicalPosition canonicalize_hce_position(const Position& position) noexcept {
    HceCanonicalPosition result{
        position.white(), position.black(), position.kings(), position.side_to_move(), false};
    const Bitboard mirrored_white = mirror_bitboard(position.white());
    const Bitboard mirrored_black = mirror_bitboard(position.black());
    const Bitboard mirrored_kings = mirror_bitboard(position.kings());
    if (tuple_less(mirrored_white, mirrored_black, mirrored_kings,
                   result.white, result.black, result.kings)) {
        result.white = mirrored_white;
        result.black = mirrored_black;
        result.kings = mirrored_kings;
        result.mirrored = true;
    }
    return result;
}

Position color_swap_rotate_hce_position(const Position& position) {
    return Position::from_bitboards(
        rotate_bitboard_180(position.black()),
        rotate_bitboard_180(position.white()),
        rotate_bitboard_180(position.kings()),
        opposite(position.side_to_move()),
        position.no_progress_plies());
}

Position hce_record_position(const HceRecord& record) {
    return Position::from_bitboards(
        record.white, record.black, record.kings,
        record.side_to_move, record.no_progress_plies);
}

HceRecord make_hce_record(
    const Position& position,
    std::uint64_t group_id,
    std::uint16_t ply,
    HceSource source,
    HceSplit split,
    std::int8_t game_result_white,
    std::uint16_t extra_flags) {
    const HceCanonicalPosition canonical = canonicalize_hce_position(position);
    Position stored = Position::from_bitboards(
        canonical.white, canonical.black, canonical.kings,
        canonical.side_to_move, position.no_progress_plies());
    MoveList legal;
    generate_legal_moves(stored, legal);
    const bool capture = !legal.empty() && legal[0].is_capture();
    HceRecord record{};
    record.white = stored.white();
    record.black = stored.black();
    record.kings = stored.kings();
    record.group_id = group_id;
    record.ply = ply;
    record.no_progress_plies = stored.no_progress_plies();
    record.side_to_move = stored.side_to_move();
    record.phase = classify_hce_phase(stored);
    record.split = split;
    record.source = source;
    record.game_result_white = game_result_white;
    record.flags = static_cast<std::uint16_t>(extra_flags | HceLegalPosition);
    if (!capture) record.flags = static_cast<std::uint16_t>(record.flags | HceQuietPosition);
    if (!capture && legal.size() >= 2) {
        record.flags = static_cast<std::uint16_t>(record.flags | HceNonForcedPosition | HceStableQuietCandidate);
    }
    if (canonical.mirrored) record.flags = static_cast<std::uint16_t>(record.flags | HceMirroredCanonical);
    if (game_result_white >= -1 && game_result_white <= 1) {
        record.flags = static_cast<std::uint16_t>(record.flags | HceGameResultKnown);
    }
    return record;
}

std::string_view hce_phase_name(HcePhase phase) noexcept {
    switch (phase) {
        case HcePhase::Opening: return "opening";
        case HcePhase::Middlegame: return "middlegame";
        case HcePhase::ManEndgame: return "man_endgame";
        case HcePhase::KingEndgame: return "king_endgame";
        case HcePhase::Count: break;
    }
    return "unknown";
}
std::string_view hce_split_name(HceSplit split) noexcept {
    switch (split) {
        case HceSplit::Train: return "train";
        case HceSplit::Validation: return "validation";
        case HceSplit::Holdout: return "holdout";
        case HceSplit::Count: break;
    }
    return "unknown";
}
std::string_view hce_source_name(HceSource source) noexcept {
    switch (source) {
        case HceSource::Trajectory: return "trajectory";
        case HceSource::SyntheticManEndgame: return "synthetic_man_endgame";
        case HceSource::SyntheticKingEndgame: return "synthetic_king_endgame";
        case HceSource::ExternalTeacher: return "external_teacher";
        case HceSource::ExactEndgame: return "exact_endgame";
        case HceSource::ImportedGame: return "imported_game";
        case HceSource::Count: break;
    }
    return "unknown";
}

bool write_hce_dataset(
    const std::string& path,
    const std::vector<HceRecord>& records,
    std::uint64_t seed,
    HceDatasetHeader* written_header,
    std::string* error) {
    auto fail = [error](const std::string& message) {
        if (error != nullptr) *error = message;
        return false;
    };
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return fail("cannot open HCE dataset output");
    std::array<std::uint8_t, kHceDatasetHeaderBytes> empty_header{};
    output.write(reinterpret_cast<const char*>(empty_header.data()), empty_header.size());
    std::uint64_t payload_checksum = kFnvOffset;
    std::array<std::uint8_t, kHceDatasetRecordBytes> bytes{};
    for (const HceRecord& record : records) {
        encode_record(record, bytes);
        fnv_update(payload_checksum, bytes.data(), bytes.size());
        output.write(reinterpret_cast<const char*>(bytes.data()), bytes.size());
        if (!output) return fail("failed while writing HCE dataset payload");
    }
    HceDatasetHeader header = summarize_records(records, seed, payload_checksum);
    std::array<std::uint8_t, kHceDatasetHeaderBytes> header_bytes{};
    encode_header(header, header_bytes);
    output.seekp(0, std::ios::beg);
    output.write(reinterpret_cast<const char*>(header_bytes.data()), header_bytes.size());
    output.flush();
    if (!output) return fail("failed while finalizing HCE dataset header");
    if (written_header != nullptr) *written_header = header;
    return true;
}

bool read_hce_dataset(
    const std::string& path,
    HceDatasetHeader& header,
    std::vector<HceRecord>& records,
    std::string* error) {
    auto fail = [error](const std::string& message) {
        if (error != nullptr) *error = message;
        return false;
    };
    std::ifstream input(path, std::ios::binary);
    if (!input) return fail("cannot open HCE dataset input");
    std::array<std::uint8_t, kHceDatasetHeaderBytes> header_bytes{};
    input.read(reinterpret_cast<char*>(header_bytes.data()), header_bytes.size());
    if (!input || !decode_header(header_bytes, header, error)) return false;
    if (header.record_count > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        return fail("HCE dataset is too large for this process");
    }
    records.clear();
    records.reserve(static_cast<std::size_t>(header.record_count));
    std::uint64_t checksum = kFnvOffset;
    std::array<std::uint8_t, kHceDatasetRecordBytes> bytes{};
    for (std::uint64_t index = 0; index < header.record_count; ++index) {
        input.read(reinterpret_cast<char*>(bytes.data()), bytes.size());
        if (!input) return fail("truncated HCE dataset payload");
        fnv_update(checksum, bytes.data(), bytes.size());
        records.push_back(decode_record(bytes.data()));
    }
    char trailing = 0;
    if (input.read(&trailing, 1)) return fail("unexpected trailing bytes in HCE dataset");
    if (checksum != header.payload_fnv1a64) return fail("HCE dataset payload checksum mismatch");
    return validate_hce_dataset(header, records, error);
}

bool inspect_hce_dataset(
    const std::string& path,
    HceDatasetHeader& header,
    std::string* error) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        if (error != nullptr) *error = "cannot open HCE dataset input";
        return false;
    }
    std::array<std::uint8_t, kHceDatasetHeaderBytes> bytes{};
    input.read(reinterpret_cast<char*>(bytes.data()), bytes.size());
    if (!input) {
        if (error != nullptr) *error = "truncated HCE dataset header";
        return false;
    }
    return decode_header(bytes, header, error);
}

bool validate_hce_dataset(
    const HceDatasetHeader& header,
    const std::vector<HceRecord>& records,
    std::string* error) {
    auto fail = [error](const std::string& message) {
        if (error != nullptr) *error = message;
        return false;
    };
    if (header.record_count != records.size()) return fail("HCE header record count mismatch");
    std::array<std::uint64_t, static_cast<std::size_t>(HcePhase::Count)> phases{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSplit::Count)> splits{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSource::Count)> sources{};
    std::uint64_t known_results = 0;
    std::uint64_t known_scores = 0;
    std::unordered_set<PositionKey, PositionKeyHash> seen;
    seen.reserve(records.size() * 11 / 10 + 1);
    std::unordered_map<std::uint64_t, HceSplit> group_splits;
    group_splits.reserve(records.size() / 8 + 1);
    for (std::size_t index = 0; index < records.size(); ++index) {
        const HceRecord& record = records[index];
        if (phase_index(record.phase) >= phases.size() ||
            split_index(record.split) >= splits.size() ||
            source_index(record.source) >= sources.size()) {
            return fail("HCE record enum is out of range at index " + std::to_string(index));
        }
        if ((record.white & record.black) != 0 ||
            (record.kings & ~(record.white | record.black)) != 0 ||
            std::popcount(record.white) > 12 || std::popcount(record.black) > 12) {
            return fail("invalid HCE bitboards at index " + std::to_string(index));
        }
        if (record.game_result_white < -1 || record.game_result_white > 2) {
            return fail("invalid HCE game result at index " + std::to_string(index));
        }
        Position position;
        try {
            position = hce_record_position(record);
        } catch (const std::exception&) {
            return fail("cannot reconstruct HCE position at index " + std::to_string(index));
        }
        if (classify_hce_phase(position) != record.phase) {
            return fail("HCE phase mismatch at index " + std::to_string(index));
        }
        const HceCanonicalPosition canonical = canonicalize_hce_position(position);
        if (canonical.white != record.white || canonical.black != record.black ||
            canonical.kings != record.kings) {
            return fail("non-canonical HCE position at index " + std::to_string(index));
        }
        const PositionKey key{record.white, record.black, record.kings,
                              static_cast<std::uint8_t>(record.side_to_move == Color::White ? 0 : 1)};
        if (!seen.insert(key).second) {
            return fail("duplicate HCE position at index " + std::to_string(index));
        }
        const auto [group_iterator, inserted] = group_splits.emplace(record.group_id, record.split);
        if (!inserted && group_iterator->second != record.split) {
            return fail("HCE game group crosses dataset splits");
        }
        ++phases[phase_index(record.phase)];
        ++splits[split_index(record.split)];
        ++sources[source_index(record.source)];
        if ((record.flags & HceGameResultKnown) != 0) ++known_results;
        if ((record.flags & HceTeacherScoreKnown) != 0) ++known_scores;
    }
    if (phases != header.phase_counts || splits != header.split_counts || sources != header.source_counts ||
        known_results != header.known_result_count || known_scores != header.known_teacher_score_count ||
        group_splits.size() != header.unique_group_count) {
        return fail("HCE header statistics mismatch");
    }
    return true;
}

}  // namespace albay
