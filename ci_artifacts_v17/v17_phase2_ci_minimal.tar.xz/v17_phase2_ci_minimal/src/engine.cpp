/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/engine.hpp"

#include "albay/movegen.hpp"
#include "albay/notation.hpp"
#include "albay/nnue_runtime.hpp"

#include <algorithm>
#include <charconv>
#include <cctype>
#include <exception>
#include <limits>
#include <utility>

namespace albay {
namespace {

[[nodiscard]] std::string lowercase(std::string_view text) {
    std::string result(text);
    std::transform(result.begin(), result.end(), result.begin(), [](unsigned char character) {
        return static_cast<char>(std::tolower(character));
    });
    return result;
}

[[nodiscard]] bool parse_bool(std::string_view value, bool& result) {
    const std::string lowered = lowercase(value);
    if (lowered == "1" || lowered == "true" || lowered == "on" || lowered == "yes") {
        result = true;
        return true;
    }
    if (lowered == "0" || lowered == "false" || lowered == "off" || lowered == "no") {
        result = false;
        return true;
    }
    return false;
}

template <typename Integer>
[[nodiscard]] bool parse_integer(std::string_view value, Integer& result) {
    Integer parsed{};
    const auto [pointer, error] = std::from_chars(value.data(), value.data() + value.size(), parsed);
    if (error != std::errc{} || pointer != value.data() + value.size()) {
        return false;
    }
    result = parsed;
    return true;
}

}  // namespace

Engine::Engine() {
    runtime_environment_.logical_cpu_count = detected_logical_cpu_count();
    runtime_decision_ = select_thread_policy(
        performance_profile_, automatic_threads_, options_.threads, runtime_environment_);
}

Engine::~Engine() {
    stop_and_join();
}

void Engine::new_game() {
    stop_and_join();
    {
        std::lock_guard lock(position_mutex_);
        position_.reset_to_initial();
        move_history_.clear();
    }
    {
        std::lock_guard lock(result_mutex_);
        last_result_ = {};
        last_error_.clear();
    }
    searcher_.clear_hash();
}

bool Engine::set_position(std::string_view text, std::string* error) {
    std::string parse_error;
    const auto parsed = parse_apf(text, &parse_error);
    if (!parsed.has_value()) {
        if (error != nullptr) {
            *error = parse_error;
        }
        set_last_error(parse_error);
        return false;
    }

    stop_and_join();
    {
        std::lock_guard lock(position_mutex_);
        position_ = *parsed;
        move_history_.clear();
    }
    {
        std::lock_guard lock(result_mutex_);
        last_result_ = {};
        last_error_.clear();
    }
    return true;
}

std::string Engine::get_position() const {
    std::lock_guard lock(position_mutex_);
    return position_to_apf(position_);
}

std::vector<std::string> Engine::generate_legal_moves() const {
    std::lock_guard lock(position_mutex_);
    MoveList moves;
    albay::generate_legal_moves(position_, moves);
    std::vector<std::string> result;
    result.reserve(moves.size());
    for (const Move& move : moves) {
        result.push_back(move_to_string(move));
    }
    return result;
}

bool Engine::is_legal_move(std::string_view text) const {
    std::lock_guard lock(position_mutex_);
    return parse_legal_move(position_, text).has_value();
}

bool Engine::make_move(std::string_view text, std::string* error) {
    stop_and_join();
    std::lock_guard lock(position_mutex_);
    const auto move = parse_legal_move(position_, text);
    if (!move.has_value()) {
        const std::string message = "illegal move: " + std::string(text);
        if (error != nullptr) {
            *error = message;
        }
        set_last_error(message);
        return false;
    }

    PlayedMove played{};
    played.move = *move;
    position_.make_move(played.move, played.undo);
    move_history_.push_back(played);
    {
        std::lock_guard result_lock(result_mutex_);
        last_result_ = {};
        last_error_.clear();
    }
    return true;
}

bool Engine::undo_move() {
    stop_and_join();
    std::lock_guard lock(position_mutex_);
    if (move_history_.empty()) {
        return false;
    }
    const PlayedMove played = move_history_.back();
    move_history_.pop_back();
    position_.unmake_move(played.move, played.undo);
    {
        std::lock_guard result_lock(result_mutex_);
        last_result_ = {};
        last_error_.clear();
    }
    return true;
}

bool Engine::start_search(const SearchLimits& limits) {
    std::lock_guard worker_lock(worker_mutex_);
    bool expected = false;
    if (!worker_active_.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) {
        return false;
    }
    if (worker_.joinable()) {
        worker_.join();
    }

    Position root;
    {
        std::lock_guard lock(position_mutex_);
        root = position_;
    }
    SearchOptions selected_options;
    PerformanceProfile selected_profile{};
    bool selected_automatic = true;
    {
        std::lock_guard lock(options_mutex_);
        selected_options = options_;
        selected_profile = performance_profile_;
        selected_automatic = automatic_threads_;
    }
    {
        std::lock_guard lock(runtime_mutex_);
        runtime_decision_ = select_thread_policy(
            selected_profile, selected_automatic, selected_options.threads, runtime_environment_);
        active_pool_threads_ = runtime_decision_.pool_threads;
        selected_options.threads = runtime_decision_.pool_threads;
        selected_options.active_threads = runtime_decision_.target_threads;
    }
    {
        std::lock_guard lock(result_mutex_);
        last_result_ = {};
        last_error_.clear();
    }
    external_pause_requested_.store(false, std::memory_order_release);

    try {
        worker_ = std::jthread([this, root = std::move(root), limits, selected_options](std::stop_token stop_token) mutable {
            struct ActiveGuard {
                std::atomic<bool>& active;
                ~ActiveGuard() { active.store(false, std::memory_order_release); }
            } active_guard{worker_active_};
            try {
                SearchResult result = searcher_.search(
                    root, limits, selected_options, {}, stop_token, &external_pause_requested_);
                std::lock_guard lock(result_mutex_);
                last_result_ = std::move(result);
            } catch (const std::exception& exception) {
                set_last_error(exception.what());
            } catch (...) {
                set_last_error("unknown native search error");
            }
        });
    } catch (...) {
        worker_active_.store(false, std::memory_order_release);
        throw;
    }
    return true;
}

void Engine::stop_search() noexcept {
    std::lock_guard lock(worker_mutex_);
    external_pause_requested_.store(false, std::memory_order_release);
    if (worker_.joinable()) {
        worker_.request_stop();
    }
    searcher_.stop();
    searcher_.resume();
}

void Engine::pause_search() noexcept {
    external_pause_requested_.store(true, std::memory_order_release);
    searcher_.pause();
}

void Engine::resume_search() noexcept {
    external_pause_requested_.store(false, std::memory_order_release);
    searcher_.resume();
}

void Engine::wait_for_search() noexcept {
    std::lock_guard lock(worker_mutex_);
    if (worker_.joinable()) {
        worker_.join();
    }
}

bool Engine::set_option(std::string_view name, std::string_view value, std::string* error) {
    const std::string key = lowercase(name);
    SearchOptions updated;
    PerformanceProfile updated_profile{};
    bool updated_automatic = true;
    {
        std::lock_guard lock(options_mutex_);
        updated = options_;
        updated_profile = performance_profile_;
        updated_automatic = automatic_threads_;
    }

    auto fail = [&](std::string message) {
        if (error != nullptr) {
            *error = message;
        }
        set_last_error(message);
        return false;
    };

    if (key == "nnuemodelpath" || key == "nnue_model_path" || key == "nnuefile") {
        if (is_searching()) return fail("NNUE model cannot be changed while searching");
        if (value.empty()) {
            updated.nnue.model.reset();
            updated.nnue.model_path.clear();
            updated.nnue.enabled = false;
        } else {
            std::shared_ptr<const NnueModel> loaded;
            std::string model_error;
            if (!load_nnue_runtime_model(std::string(value), loaded, &model_error)) {
                return fail(model_error);
            }
            updated.nnue.model = std::move(loaded);
            updated.nnue.model_path = std::string(value);
        }
    } else if (key == "usennue" || key == "use_nnue" || key == "nnue") {
        if (is_searching()) return fail("UseNNUE cannot be changed while searching");
        bool enabled = false;
        if (!parse_bool(value, enabled)) return fail("UseNNUE expects true or false");
        if (enabled && !updated.nnue.model) {
            return fail("UseNNUE requires a valid NNUEModelPath first");
        }
        updated.nnue.enabled = enabled;
    } else if (key == "nnueincremental" || key == "nnue_incremental" ||
               key == "useincrementalnnue" || key == "use_incremental_nnue") {
        if (is_searching()) return fail("NNUEIncremental cannot be changed while searching");
        if (!parse_bool(value, updated.use_incremental_nnue)) {
            return fail("NNUEIncremental expects true or false");
        }
    } else if (key == "nnueblendpercent" || key == "nnue_blend_percent" || key == "nnueblend") {
        if (is_searching()) return fail("NNUEBlendPercent cannot be changed while searching");
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 100) {
            return fail("NNUEBlendPercent must be from 0 to 100");
        }
        updated.nnue.blend_percent = parsed;
    } else if (key == "hash" || key == "hashmb" || key == "hash_size_mb") {
        std::size_t parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 2048) {
            return fail("Hash must be an integer from 1 to 2048 MB");
        }
        if (is_searching()) {
            return fail("Hash cannot be resized while searching");
        }
        updated.hash_size_mb = parsed;
        searcher_.set_hash_size_mb(parsed);
    } else if (key == "multipv" || key == "multi_pv") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > kMaxMultiPV) {
            return fail("MultiPV must be an integer from 1 to 16");
        }
        updated.multi_pv = parsed;
    } else if (key == "aspiration" || key == "use_aspiration_windows") {
        if (!parse_bool(value, updated.use_aspiration_windows)) {
            return fail("Aspiration expects true or false");
        }
    } else if (key == "aspirationwindow" || key == "aspiration_window") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 8 || parsed > 5000) {
            return fail("AspirationWindow must be from 8 to 5000");
        }
        updated.aspiration_window = parsed;
    } else if (key == "aspirationmindepth" || key == "aspiration_min_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 64) {
            return fail("AspirationMinDepth must be from 1 to 64");
        }
        updated.aspiration_min_depth = parsed;
    } else if (key == "aspirationgrowthpercent" || key == "aspiration_growth_percent") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 125 || parsed > 400) {
            return fail("AspirationGrowthPercent must be from 125 to 400");
        }
        updated.aspiration_growth_percent = parsed;
    } else if (key == "aspirationsidebiaspercent" || key == "aspiration_side_bias_percent") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 100) {
            return fail("AspirationSideBiasPercent must be from 0 to 100");
        }
        updated.aspiration_side_bias_percent = parsed;
    } else if (key == "pvs" || key == "use_pvs") {
        if (!parse_bool(value, updated.use_pvs)) {
            return fail("PVS expects true or false");
        }
    } else if (key == "tt" || key == "transpositiontable" || key == "use_transposition_table") {
        if (!parse_bool(value, updated.use_transposition_table)) {
            return fail("TT expects true or false");
        }
    } else if (key == "fullcapacitytt" || key == "full_capacity_tt") {
        if (!parse_bool(value, updated.use_full_capacity_tt)) {
            return fail("FullCapacityTT expects true or false");
        }
    } else if (key == "ageawarettreplacement" || key == "age_aware_tt_replacement") {
        if (!parse_bool(value, updated.use_age_aware_tt_replacement)) {
            return fail("AgeAwareTTReplacement expects true or false");
        }
    } else if (key == "depthpreferredttupdates" || key == "depth_preferred_tt_updates") {
        if (!parse_bool(value, updated.use_depth_preferred_tt_updates)) {
            return fail("DepthPreferredTTUpdates expects true or false");
        }
    } else if (key == "ttagepenaltypergeneration" || key == "tt_age_penalty_per_generation") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 64) {
            return fail("TTAgePenaltyPerGeneration must be from 1 to 64");
        }
        updated.tt_age_penalty_per_generation = parsed;
    } else if (key == "ttexactboundbonus" || key == "tt_exact_bound_bonus") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 32) {
            return fail("TTExactBoundBonus must be from 0 to 32");
        }
        updated.tt_exact_bound_bonus = parsed;
    } else if (key == "countermove" || key == "use_countermove") {
        if (!parse_bool(value, updated.use_countermove)) {
            return fail("Countermove expects true or false");
        }
    } else if (key == "lmr" || key == "use_late_move_reductions") {
        if (!parse_bool(value, updated.use_late_move_reductions)) {
            return fail("LMR expects true or false");
        }
    } else if (key == "dynamiclmr" || key == "dynamic_lmr") {
        if (!parse_bool(value, updated.use_dynamic_lmr)) {
            return fail("DynamicLMR expects true or false");
        }
    } else if (key == "russianlmrv2" || key == "russian_lmr_v2") {
        if (!parse_bool(value, updated.use_russian_lmr_v2)) {
            return fail("RussianLMRv2 expects true or false");
        }
    } else if (key == "lmrpriorityguard" || key == "lmr_priority_guard") {
        if (!parse_bool(value, updated.use_lmr_priority_guard)) {
            return fail("LMRPriorityGuard expects true or false");
        }
    } else if (key == "lmrforcingcaptureguard" || key == "lmr_forcing_capture_guard") {
        if (!parse_bool(value, updated.use_lmr_forcing_capture_guard)) {
            return fail("LMRForcingCaptureGuard expects true or false");
        }
    } else if (key == "razoring" || key == "use_razoring") {
        if (!parse_bool(value, updated.use_razoring)) {
            return fail("Razoring expects true or false");
        }
    } else if (key == "staticfutilitypruning" || key == "static_futility_pruning") {
        if (!parse_bool(value, updated.use_static_futility_pruning)) {
            return fail("StaticFutilityPruning expects true or false");
        }
    } else if (key == "latemovepruning" || key == "late_move_pruning") {
        if (!parse_bool(value, updated.use_late_move_pruning)) {
            return fail("LateMovePruning expects true or false");
        }
    } else if (key == "lmrmindepth" || key == "lmr_min_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 2 || parsed > 20) {
            return fail("LMRMinDepth must be from 2 to 20");
        }
        updated.lmr_min_depth = parsed;
    } else if (key == "lmrmovethreshold" || key == "lmr_move_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 32) {
            return fail("LMRMoveThreshold must be from 1 to 32");
        }
        updated.lmr_move_threshold = parsed;
    } else if (key == "lmrhistorythreshold" || key == "lmr_history_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < -16384 || parsed > 16384) {
            return fail("LMRHistoryThreshold must be from -16384 to 16384");
        }
        updated.lmr_history_threshold = parsed;
    } else if (key == "lmrdeepdepth" || key == "lmr_deep_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 2 || parsed > 32) {
            return fail("LMRDeepDepth must be from 2 to 32");
        }
        updated.lmr_deep_depth = parsed;
    } else if (key == "lmrdeepmovethreshold" || key == "lmr_deep_move_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 48) {
            return fail("LMRDeepMoveThreshold must be from 1 to 48");
        }
        updated.lmr_deep_move_threshold = parsed;
    } else if (key == "lmrdeephistorythreshold" || key == "lmr_deep_history_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < -16384 || parsed > 16384) {
            return fail("LMRDeepHistoryThreshold must be from -16384 to 16384");
        }
        updated.lmr_deep_history_threshold = parsed;
    } else if (key == "lmrmaxreduction" || key == "lmr_max_reduction") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 3) {
            return fail("LMRMaxReduction must be from 1 to 3");
        }
        updated.lmr_max_reduction = parsed;
    } else if (key == "lmrphaseminpieces" || key == "lmr_phase_min_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) return fail("LMRPhaseMinPieces must be from 0 to 24");
        updated.lmr_phase_min_pieces = parsed;
    } else if (key == "lmrphasemaxpieces" || key == "lmr_phase_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) return fail("LMRPhaseMaxPieces must be from 0 to 24");
        updated.lmr_phase_max_pieces = parsed;
    } else if (key == "lmrphasemaxkings" || key == "lmr_phase_max_kings") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) return fail("LMRPhaseMaxKings must be from 0 to 24");
        updated.lmr_phase_max_kings = parsed;
    } else if (key == "lmrphasemindepth" || key == "lmr_phase_min_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 2 || parsed > 12) return fail("LMRPhaseMinDepth must be from 2 to 12");
        updated.lmr_phase_min_depth = parsed;
    } else if (key == "lmrphasemovethreshold" || key == "lmr_phase_move_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 32) return fail("LMRPhaseMoveThreshold must be from 1 to 32");
        updated.lmr_phase_move_threshold = parsed;
    } else if (key == "lmrprotectedhistorythreshold" || key == "lmr_protected_history_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < -16384 || parsed > 16384) return fail("LMRProtectedHistoryThreshold must be from -16384 to 16384");
        updated.lmr_protected_history_threshold = parsed;
    } else if (key == "lmrnegativehistorythreshold" || key == "lmr_negative_history_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < -16384 || parsed > 16384) return fail("LMRNegativeHistoryThreshold must be from -16384 to 16384");
        updated.lmr_negative_history_threshold = parsed;
    } else if (key == "lmrphasedeepdepth" || key == "lmr_phase_deep_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 2 || parsed > 24) return fail("LMRPhaseDeepDepth must be from 2 to 24");
        updated.lmr_phase_deep_depth = parsed;
    } else if (key == "lmrphasedeepmovethreshold" || key == "lmr_phase_deep_move_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 48) return fail("LMRPhaseDeepMoveThreshold must be from 1 to 48");
        updated.lmr_phase_deep_move_threshold = parsed;
    } else if (key == "razormaxdepth" || key == "razor_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 3) {
            return fail("RazorMaxDepth must be from 1 to 3");
        }
        updated.razor_max_depth = parsed;
    } else if (key == "razormarginbase" || key == "razor_margin_base") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 1000) {
            return fail("RazorMarginBase must be from 0 to 1000");
        }
        updated.razor_margin_base = parsed;
    } else if (key == "razormarginperdepth" || key == "razor_margin_per_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 1000) {
            return fail("RazorMarginPerDepth must be from 0 to 1000");
        }
        updated.razor_margin_per_depth = parsed;
    } else if (key == "razorminpieces" || key == "razor_min_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) {
            return fail("RazorMinPieces must be from 0 to 24");
        }
        updated.razor_min_pieces = parsed;
    } else if (key == "razormaxpieces" || key == "razor_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) {
            return fail("RazorMaxPieces must be from 0 to 24");
        }
        updated.razor_max_pieces = parsed;
    } else if (key == "razormaxtimems" || key == "razor_max_time_ms") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 60'000) {
            return fail("RazorMaxTimeMs must be from 0 to 60000");
        }
        updated.razor_max_time_ms = parsed;
    } else if (key == "futilitymaxdepth" || key == "futility_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 3) {
            return fail("FutilityMaxDepth must be from 1 to 3");
        }
        updated.futility_max_depth = parsed;
    } else if (key == "futilitymarginbase" || key == "futility_margin_base") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 1000) {
            return fail("FutilityMarginBase must be from 0 to 1000");
        }
        updated.futility_margin_base = parsed;
    } else if (key == "futilitymarginperdepth" || key == "futility_margin_per_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 1000) {
            return fail("FutilityMarginPerDepth must be from 0 to 1000");
        }
        updated.futility_margin_per_depth = parsed;
    } else if (key == "futilityminpieces" || key == "futility_min_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) {
            return fail("FutilityMinPieces must be from 0 to 24");
        }
        updated.futility_min_pieces = parsed;
    } else if (key == "futilitymaxpieces" || key == "futility_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) {
            return fail("FutilityMaxPieces must be from 0 to 24");
        }
        updated.futility_max_pieces = parsed;
    } else if (key == "latemovepruningmaxdepth" || key == "late_move_pruning_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 4) {
            return fail("LateMovePruningMaxDepth must be from 1 to 4");
        }
        updated.late_move_pruning_max_depth = parsed;
    } else if (key == "latemovepruningbasemoves" || key == "late_move_pruning_base_moves") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 2 || parsed > 32) {
            return fail("LateMovePruningBaseMoves must be from 2 to 32");
        }
        updated.late_move_pruning_base_moves = parsed;
    } else if (key == "capturesignaturehistory" || key == "capture_signature_history") {
        if (!parse_bool(value, updated.use_capture_signature_history)) {
            return fail("CaptureSignatureHistory expects true or false");
        }
    } else if (key == "capturecontinuationhistory" || key == "capture_continuation_history") {
        if (!parse_bool(value, updated.use_capture_continuation_history)) {
            return fail("CaptureContinuationHistory expects true or false");
        }
    } else if (key == "followuphistory" || key == "followup_history") {
        if (!parse_bool(value, updated.use_followup_history)) {
            return fail("FollowupHistory expects true or false");
        }
    } else if (key == "piecetypehistory" || key == "piece_type_history") {
        if (!parse_bool(value, updated.use_piece_type_history)) {
            return fail("PieceTypeHistory expects true or false");
        }
    } else if (key == "promotionthreatordering" || key == "promotion_threat_ordering") {
        if (!parse_bool(value, updated.use_promotion_threat_ordering)) {
            return fail("PromotionThreatOrdering expects true or false");
        }
    } else if (key == "recaptureordering" || key == "recapture_ordering") {
        if (!parse_bool(value, updated.use_recapture_ordering)) {
            return fail("RecaptureOrdering expects true or false");
        }
    } else if (key == "recaptureextensions" || key == "recapture_extensions") {
        if (!parse_bool(value, updated.use_recapture_extensions)) {
            return fail("RecaptureExtensions expects true or false");
        }
    } else if (key == "forcedlineextensions" || key == "forced_line_extensions") {
        if (!parse_bool(value, updated.use_forced_line_extensions)) {
            return fail("ForcedLineExtensions expects true or false");
        }
    } else if (key == "forcingquietlmrguard" || key == "forcing_quiet_lmr_guard") {
        if (!parse_bool(value, updated.use_forcing_quiet_lmr_guard)) {
            return fail("ForcingQuietLMRGuard expects true or false");
        }
    } else if (key == "quietsacrificeextensions" || key == "quiet_sacrifice_extensions") {
        if (!parse_bool(value, updated.use_quiet_sacrifice_extensions)) {
            return fail("QuietSacrificeExtensions expects true or false");
        }
    } else if (key == "followuphistoryweight" || key == "followup_history_weight") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("FollowupHistoryWeight must be from 0 to 300");
        }
        updated.followup_history_weight = parsed;
    } else if (key == "piecetypehistoryweight" || key == "piece_type_history_weight") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("PieceTypeHistoryWeight must be from 0 to 300");
        }
        updated.piece_type_history_weight = parsed;
    } else if (key == "promotionthreatorderbonus" || key == "promotion_threat_order_bonus") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 200000) {
            return fail("PromotionThreatOrderBonus must be from 0 to 200000");
        }
        updated.promotion_threat_order_bonus = parsed;
    } else if (key == "capturecontinuationweight" || key == "capture_continuation_weight") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("CaptureContinuationWeight must be from 0 to 300");
        }
        updated.capture_continuation_weight = parsed;
    } else if (key == "recaptureorderbonus" || key == "recapture_order_bonus") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 200000) {
            return fail("RecaptureOrderBonus must be from 0 to 200000");
        }
        updated.recapture_order_bonus = parsed;
    } else if (key == "recaptureextensionmaxdepth" || key == "recapture_extension_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 16) {
            return fail("RecaptureExtensionMaxDepth must be from 1 to 16");
        }
        updated.recapture_extension_max_depth = parsed;
    } else if (key == "forcedlineextensionmaxdepth" || key == "forced_line_extension_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 24) {
            return fail("ForcedLineExtensionMaxDepth must be from 1 to 24");
        }
        updated.forced_line_extension_max_depth = parsed;
    } else if (key == "quietsacrificeextensionmaxdepth" || key == "quiet_sacrifice_extension_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 16) {
            return fail("QuietSacrificeExtensionMaxDepth must be from 1 to 16");
        }
        updated.quiet_sacrifice_extension_max_depth = parsed;
    } else if (key == "endgamereplyordering" || key == "endgame_reply_ordering") {
        if (!parse_bool(value, updated.use_endgame_reply_ordering)) {
            return fail("EndgameReplyOrdering expects true or false");
        }
    } else if (key == "endgamelmrguard" || key == "endgame_lmr_guard") {
        if (!parse_bool(value, updated.use_endgame_lmr_guard)) {
            return fail("EndgameLMRGuard expects true or false");
        }
    } else if (key == "endgamereplyordermaxpieces" || key == "endgame_reply_order_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 2 || parsed > 12) {
            return fail("EndgameReplyOrderMaxPieces must be from 2 to 12");
        }
        updated.endgame_reply_order_max_pieces = parsed;
    } else if (key == "endgamereplyorderweight" || key == "endgame_reply_order_weight") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 400) {
            return fail("EndgameReplyOrderWeight must be from 0 to 400 percent");
        }
        updated.endgame_reply_order_weight = parsed;
    } else if (key == "endgamelmrguardreplythreshold" || key == "endgame_lmr_guard_reply_threshold") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 8) {
            return fail("EndgameLMRGuardReplyThreshold must be from 1 to 8");
        }
        updated.endgame_lmr_guard_reply_threshold = parsed;
    } else if (key == "tacticalextensions" || key == "tactical_extensions") {
        if (!parse_bool(value, updated.use_tactical_extensions)) {
            return fail("TacticalExtensions expects true or false");
        }
    } else if (key == "phase28extensionpolicy" || key == "phase28_extension_policy") {
        if (!parse_bool(value, updated.use_phase28_extension_policy)) {
            return fail("Phase28ExtensionPolicy expects true or false");
        }
    } else if (key == "phaseawarepromotionextension" || key == "phase_aware_promotion_extension") {
        if (!parse_bool(value, updated.use_phase_aware_promotion_extension)) {
            return fail("PhaseAwarePromotionExtension expects true or false");
        }
    } else if (key == "promotionextensions" || key == "promotion_extensions") {
        if (!parse_bool(value, updated.use_promotion_extensions)) {
            return fail("PromotionExtensions expects true or false");
        }
    } else if (key == "singlereplyextensions" || key == "single_reply_extensions") {
        if (!parse_bool(value, updated.use_single_reply_extensions)) {
            return fail("SingleReplyExtensions expects true or false");
        }
    } else if (key == "singlereplyquietonly" || key == "single_reply_quiet_only") {
        if (!parse_bool(value, updated.single_reply_quiet_only)) {
            return fail("SingleReplyQuietOnly expects true or false");
        }
    } else if (key == "promotionextensionmaxdepth" || key == "promotion_extension_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 16) {
            return fail("PromotionExtensionMaxDepth must be from 0 to 16");
        }
        updated.promotion_extension_max_depth = parsed;
    } else if (key == "promotionextensionextramaxpieces" || key == "promotion_extension_extra_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) {
            return fail("PromotionExtensionExtraMaxPieces must be from 0 to 24");
        }
        updated.promotion_extension_extra_max_pieces = parsed;
    } else if (key == "promotionextensionextramaxkings" || key == "promotion_extension_extra_max_kings") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) {
            return fail("PromotionExtensionExtraMaxKings must be from 0 to 24");
        }
        updated.promotion_extension_extra_max_kings = parsed;
    } else if (key == "singlereplyextensionmaxdepth" || key == "single_reply_extension_max_depth") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 16) {
            return fail("SingleReplyExtensionMaxDepth must be from 0 to 16");
        }
        updated.single_reply_extension_max_depth = parsed;
    } else if (key == "tacticalmaxextensions" || key == "tactical_max_extensions") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 8) {
            return fail("TacticalMaxExtensions must be from 0 to 8");
        }
        updated.tactical_max_extensions = parsed;
    } else if (key == "forcedreplyextensions" || key == "forced_reply_extensions") {
        if (!parse_bool(value, updated.use_forced_reply_extensions)) {
            return fail("ForcedReplyExtensions expects true or false");
        }
    } else if (key == "quiescencettexactonly" || key == "quiescence_tt_exact_only") {
        if (!parse_bool(value, updated.quiescence_tt_exact_only)) {
            return false;
        }
    } else if (key == "quiescencecapturemalus" || key == "quiescence_capture_malus") {
        if (!parse_bool(value, updated.use_quiescence_capture_malus)) {
            return false;
        }
    } else if (key == "promotionquiescence" || key == "promotion_quiescence") {
        if (!parse_bool(value, updated.use_promotion_quiescence)) {
            return fail("PromotionQuiescence expects true or false");
        }
    } else if (key == "quiescencepromotionmaxextensions" || key == "quiescence_promotion_max_extensions") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 4) {
            return fail("QuiescencePromotionMaxExtensions must be from 0 to 4");
        }
        updated.quiescence_promotion_max_extensions = parsed;
    } else if (key == "positionalquietordering" || key == "positional_quiet_ordering") {
        if (!parse_bool(value, updated.use_positional_quiet_ordering)) {
            return fail("PositionalQuietOrdering expects true or false");
        }
    } else if (key == "strategicquietordering" || key == "strategic_quiet_ordering") {
        if (!parse_bool(value, updated.use_strategic_quiet_ordering)) {
            return fail("StrategicQuietOrdering expects true or false");
        }
    } else if (key == "strategicquietopeningonly" || key == "strategic_quiet_opening_only") {
        if (!parse_bool(value, updated.strategic_quiet_opening_only)) {
            return fail("StrategicQuietOpeningOnly expects true or false");
        }
    } else if (key == "strategiccontinuationbias" || key == "strategic_continuation_bias") {
        if (!parse_bool(value, updated.use_strategic_continuation_bias)) {
            return fail("StrategicContinuationBias expects true or false");
        }
    } else if (key == "exacttablebase" || key == "exact_tablebase") {
        if (!parse_bool(value, updated.use_exact_tablebase)) {
            return fail("ExactTablebase expects true or false");
        }
    } else if (key == "exacttablebaseprobesearch" || key == "exact_tablebase_probe_search") {
        if (!parse_bool(value, updated.exact_tablebase_probe_search)) {
            return fail("ExactTablebaseProbeSearch expects true or false");
        }
    } else if (key == "exacttablebasepath" || key == "exact_tablebase_path") {
        updated.exact_tablebase_path = value;
    } else if (key == "exacttablebasemaxpieces" || key == "exact_tablebase_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 6) {
            return fail("ExactTablebaseMaxPieces must be from 1 to 6");
        }
        updated.exact_tablebase_max_pieces = parsed;
    } else if (key == "exactendgamesolver" || key == "exact_endgame_solver") {
        if (!parse_bool(value, updated.use_exact_endgame_solver)) {
            return fail("ExactEndgameSolver expects true or false");
        }
    } else if (key == "exactendgamesafeprobeonly" || key == "exact_endgame_safe_probe_only") {
        if (!parse_bool(value, updated.exact_endgame_safe_probe_only)) {
            return fail("ExactEndgameSafeProbeOnly expects true or false");
        }
    } else if (key == "exactendgamemaxpieces" || key == "exact_endgame_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 2 || parsed > 6) {
            return fail("ExactEndgameMaxPieces must be from 2 to 6");
        }
        updated.exact_endgame_max_pieces = parsed;
    } else if (key == "exactendgamenodelimit" || key == "exact_endgame_node_limit") {
        std::uint64_t parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 1 || parsed > 100'000'000ULL) {
            return fail("ExactEndgameNodeLimit must be from 1 to 100000000");
        }
        updated.exact_endgame_node_limit = parsed;
    } else if (key == "quietorderweight" || key == "quiet_order_weight") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("QuietOrderWeight must be from 0 to 300 percent");
        }
        updated.quiet_order_weight = parsed;
    } else if (key == "positionalquietmaxply" || key == "positional_quiet_max_ply") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > kMaxSearchPly) {
            return fail("PositionalQuietMaxPly must be from 0 to 96");
        }
        updated.positional_quiet_max_ply = parsed;
    } else if (key == "strategicquietorderweight" || key == "strategic_quiet_order_weight") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("StrategicQuietOrderWeight must be from 0 to 300 percent");
        }
        updated.strategic_quiet_order_weight = parsed;
    } else if (key == "strategicquietmaxply" || key == "strategic_quiet_max_ply") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > kMaxSearchPly) {
            return fail("StrategicQuietMaxPly must be from 0 to 96");
        }
        updated.strategic_quiet_max_ply = parsed;
    } else if (key == "strategiccontinuationweight" || key == "strategic_continuation_weight") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("StrategicContinuationWeight must be from 0 to 300 percent");
        }
        updated.strategic_continuation_weight = parsed;
    } else if (key == "quietcenter" || key == "quiet_center") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietCenter must be 0..300");
        updated.quiet_ordering_weights.center = parsed;
    } else if (key == "quietsupport" || key == "quiet_support") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietSupport must be 0..300");
        updated.quiet_ordering_weights.support = parsed;
    } else if (key == "quietforwardlanes" || key == "quiet_forward_lanes") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietForwardLanes must be 0..300");
        updated.quiet_ordering_weights.forward_lanes = parsed;
    } else if (key == "quietkingmobility" || key == "quiet_king_mobility") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietKingMobility must be 0..300");
        updated.quiet_ordering_weights.king_mobility = parsed;
    } else if (key == "quietedgepenalty" || key == "quiet_edge_penalty") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietEdgePenalty must be 0..300");
        updated.quiet_ordering_weights.edge_entry = parsed;
    } else if (key == "quiethomepenalty" || key == "quiet_home_penalty") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietHomePenalty must be 0..300");
        updated.quiet_ordering_weights.home_rank_departure = parsed;
    } else if (key == "quietadvancement" || key == "quiet_advancement") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietAdvancement must be 0..300");
        updated.quiet_ordering_weights.advancement = parsed;
    } else if (key == "quietpromotion" || key == "quiet_promotion") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("QuietPromotion must be 0..300");
        updated.quiet_ordering_weights.promotion = parsed;
    } else if (key == "evalmaterial" || key == "eval_material") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalMaterial must be from 0 to 300 percent");
        }
        updated.evaluation_weights.material = parsed;
    } else if (key == "evalcenter" || key == "eval_center") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalCenter must be from 0 to 300 percent");
        }
        updated.evaluation_weights.center = parsed;
    } else if (key == "evaladvancement" || key == "eval_advancement") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalAdvancement must be from 0 to 300 percent");
        }
        updated.evaluation_weights.advancement = parsed;
    } else if (key == "evalpromotion" || key == "eval_promotion") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalPromotion must be from 0 to 300 percent");
        }
        updated.evaluation_weights.promotion_potential = parsed;
    } else if (key == "evalbackrank" || key == "eval_back_rank") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalBackRank must be from 0 to 300 percent");
        }
        updated.evaluation_weights.back_rank = parsed;
    } else if (key == "evalmobility" || key == "eval_mobility") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalMobility must be from 0 to 300 percent");
        }
        updated.evaluation_weights.mobility = parsed;
    } else if (key == "evalkingactivity" || key == "eval_king_activity") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalKingActivity must be from 0 to 300 percent");
        }
        updated.evaluation_weights.king_activity = parsed;
    } else if (key == "evalrestriction" || key == "eval_restriction") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalRestriction must be from 0 to 300 percent");
        }
        updated.evaluation_weights.restriction = parsed;
    } else if (key == "evaltactical" || key == "eval_tactical") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalTactical must be from 0 to 300 percent");
        }
        updated.evaluation_weights.tactical_pressure = parsed;
    } else if (key == "evalphase" || key == "eval_phase") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalPhase must be from 0 to 300 percent");
        }
        updated.evaluation_weights.phase_adjustment = parsed;
    } else if (key == "evalstructure" || key == "eval_structure") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalStructure must be from 0 to 300 percent");
        }
        updated.evaluation_weights.structure = parsed;
    } else if (key == "evalsupportstructure" || key == "eval_support_structure") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalSupportStructure must be from 0 to 300 percent");
        }
        updated.evaluation_weights.support_structure = parsed;
    } else if (key == "evalisolation" || key == "eval_isolation") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalIsolation must be from 0 to 300 percent");
        }
        updated.evaluation_weights.isolation = parsed;
    } else if (key == "evalpromotionlanes" || key == "eval_promotion_lanes") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalPromotionLanes must be from 0 to 300 percent");
        }
        updated.evaluation_weights.promotion_lanes = parsed;
    } else if (key == "evaledgepassivity" || key == "eval_edge_passivity") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) {
            return fail("EvalEdgePassivity must be from 0 to 300 percent");
        }
        updated.evaluation_weights.edge_passivity = parsed;
    } else if (key == "evalphaserepeat" || key == "eval_phase_repeat") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalPhaseRepeat must be 0..300");
        updated.evaluation_weights.phase_adjustment_repeat = parsed;
    } else if (key == "evalopeningcenterscale" || key == "eval_opening_center_scale") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalOpeningCenterScale must be 0..300");
        updated.evaluation_weights.opening_center_scale = parsed;
    } else if (key == "evalopeningbackrankscale" || key == "eval_opening_back_rank_scale") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalOpeningBackRankScale must be 0..300");
        updated.evaluation_weights.opening_back_rank_scale = parsed;
    } else if (key == "evalmiddlegamestructurescale" || key == "eval_middlegame_structure_scale") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalMiddlegameStructureScale must be 0..300");
        updated.evaluation_weights.middlegame_structure_scale = parsed;
    } else if (key == "evalendgamekingscale" || key == "eval_endgame_king_scale") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalEndgameKingScale must be 0..300");
        updated.evaluation_weights.endgame_king_scale = parsed;
    } else if (key == "evalendgamemobilityscale" || key == "eval_endgame_mobility_scale") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalEndgameMobilityScale must be 0..300");
        updated.evaluation_weights.endgame_mobility_scale = parsed;
    } else if (key == "evalendgamerestrictionscale" || key == "eval_endgame_restriction_scale") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalEndgameRestrictionScale must be 0..300");
        updated.evaluation_weights.endgame_restriction_scale = parsed;
    } else if (key == "evalendgamepromotionscale" || key == "eval_endgame_promotion_scale") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalEndgamePromotionScale must be 0..300");
        updated.evaluation_weights.endgame_promotion_scale = parsed;
    } else if (key == "evalkingconfinement" || key == "eval_king_confinement") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalKingConfinement must be 0..300");
        updated.evaluation_weights.king_confinement = parsed;
    } else if (key == "evalpromotionrace" || key == "eval_promotion_race") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalPromotionRace must be 0..300");
        updated.evaluation_weights.promotion_race = parsed;
    } else if (key == "evalwingbalance" || key == "eval_wing_balance") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalWingBalance must be 0..300");
        updated.evaluation_weights.wing_balance = parsed;
    } else if (key == "evalrearsupport" || key == "eval_rear_support") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalRearSupport must be 0..300");
        updated.evaluation_weights.rear_support = parsed;
    } else if (key == "evaladvancedexposure" || key == "eval_advanced_exposure") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalAdvancedExposure must be 0..300");
        updated.evaluation_weights.advanced_exposure = parsed;
    } else if (key == "evaldiagonalcontrol" || key == "eval_diagonal_control") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalDiagonalControl must be 0..300");
        updated.evaluation_weights.diagonal_control = parsed;
    } else if (key == "evalreservetempo" || key == "eval_reserve_tempo") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalReserveTempo must be 0..300");
        updated.evaluation_weights.reserve_tempo = parsed;
    } else if (key == "evalspacepressure" || key == "eval_space_pressure") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalSpacePressure must be 0..300");
        updated.evaluation_weights.space_pressure = parsed;
    } else if (key == "evalstrategicpst" || key == "eval_strategic_pst") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 300) return fail("EvalStrategicPST must be 0..300");
        updated.evaluation_weights.strategic_pst = parsed;
    } else if (key == "evalstrategicminpieces" || key == "eval_strategic_min_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) return fail("EvalStrategicMinPieces must be 0..24");
        if (parsed > updated.evaluation_weights.strategic_max_pieces) return fail("EvalStrategicMinPieces cannot exceed EvalStrategicMaxPieces");
        updated.evaluation_weights.strategic_min_pieces = parsed;
    } else if (key == "evalstrategicmaxpieces" || key == "eval_strategic_max_pieces") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) return fail("EvalStrategicMaxPieces must be 0..24");
        if (parsed < updated.evaluation_weights.strategic_min_pieces) return fail("EvalStrategicMaxPieces cannot be below EvalStrategicMinPieces");
        updated.evaluation_weights.strategic_max_pieces = parsed;
    } else if (key == "evalstrategicmaxkings" || key == "eval_strategic_max_kings") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 24) return fail("EvalStrategicMaxKings must be 0..24");
        updated.evaluation_weights.strategic_max_kings = parsed;
    } else if (key == "strategicevaluationmintimems" || key == "strategic_evaluation_min_time_ms") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || parsed < 0 || parsed > 10000) return fail("StrategicEvaluationMinTimeMs must be 0..10000");
        updated.strategic_evaluation_min_time_ms = parsed;
    } else if (key == "threads") {
        int parsed = 0;
        if (!parse_integer(value, parsed) || !is_supported_thread_count(parsed)) {
            return fail("Threads must be one of 1, 2, 3, 4, 6, or 8");
        }
        updated.threads = parsed;
        updated_automatic = false;
        updated_profile = PerformanceProfile::Manual;
    } else if (key == "autothreads" || key == "auto_threads") {
        if (!parse_bool(value, updated_automatic)) {
            return fail("AutoThreads expects true or false");
        }
        if (updated_automatic && updated_profile == PerformanceProfile::Manual) {
            updated_profile = PerformanceProfile::Balanced;
        }
    } else if (key == "profile" || key == "performanceprofile" || key == "performance_profile") {
        PerformanceProfile parsed{};
        if (!parse_performance_profile(value, parsed)) {
            return fail("Profile must be eco, balanced, performance, analysis, or manual");
        }
        updated_profile = parsed;
        updated_automatic = parsed != PerformanceProfile::Manual;
    } else if (key == "clearhash" || key == "clear_hash") {
        if (is_searching()) {
            return fail("Hash cannot be cleared while searching");
        }
        searcher_.clear_hash();
    } else {
        return fail("unknown option: " + std::string(name));
    }

    if (updated.razor_min_pieces > updated.razor_max_pieces) {
        return fail("RazorMinPieces cannot exceed RazorMaxPieces");
    }
    if (updated.futility_min_pieces > updated.futility_max_pieces) {
        return fail("FutilityMinPieces cannot exceed FutilityMaxPieces");
    }

    {
        std::lock_guard lock(options_mutex_);
        options_ = updated;
        performance_profile_ = updated_profile;
        automatic_threads_ = updated_automatic;
    }
    if (key == "threads" || key == "autothreads" || key == "auto_threads" ||
        key == "profile" || key == "performanceprofile" || key == "performance_profile") {
        update_runtime_environment(runtime_environment());
    }
    if (key == "nnuemodelpath" || key == "nnue_model_path" || key == "nnuefile" ||
        key == "usennue" || key == "use_nnue" || key == "nnue" ||
        key == "nnueblendpercent" || key == "nnue_blend_percent" || key == "nnueblend" ||
        key == "nnueincremental" || key == "nnue_incremental" ||
        key == "useincrementalnnue" || key == "use_incremental_nnue") {
        searcher_.clear_hash();
    }
    {
        std::lock_guard lock(result_mutex_);
        last_error_.clear();
    }
    return true;
}


void Engine::update_runtime_environment(const RuntimeEnvironment& environment) noexcept {
    SearchOptions selected_options;
    PerformanceProfile selected_profile{};
    bool selected_automatic = true;
    {
        std::lock_guard lock(options_mutex_);
        selected_options = options_;
        selected_profile = performance_profile_;
        selected_automatic = automatic_threads_;
    }
    ThreadPolicyDecision decision{};
    {
        std::lock_guard lock(runtime_mutex_);
        runtime_environment_ = environment;
        runtime_environment_.logical_cpu_count = std::max(runtime_environment_.logical_cpu_count, 1);
        decision = select_thread_policy(
            selected_profile, selected_automatic, selected_options.threads, runtime_environment_);
        if (is_searching()) {
            decision.pool_threads = active_pool_threads_;
            decision.target_threads = std::clamp(decision.target_threads, 1, active_pool_threads_);
        }
        runtime_decision_ = decision;
    }
    if (is_searching()) {
        searcher_.set_active_thread_limit(decision.target_threads);
    }
}

RuntimeEnvironment Engine::runtime_environment() const noexcept {
    std::lock_guard lock(runtime_mutex_);
    return runtime_environment_;
}

ThreadPolicyDecision Engine::runtime_policy_info() const noexcept {
    std::lock_guard lock(runtime_mutex_);
    ThreadPolicyDecision result = runtime_decision_;
    if (is_searching()) {
        const SearchInfo info = searcher_.info();
        result.pool_threads = info.threads;
        result.target_threads = info.target_threads;
    }
    return result;
}

SearchOptions Engine::options() const {
    std::lock_guard lock(options_mutex_);
    return options_;
}

SearchInfo Engine::search_info() const {
    return searcher_.info();
}

SearchResult Engine::last_result() const {
    std::lock_guard lock(result_mutex_);
    return last_result_;
}

std::optional<Move> Engine::best_move() const {
    if (searcher_.is_searching()) {
        const SearchInfo info = searcher_.info();
        if (!info.principal_variation.empty()) {
            return info.principal_variation.front();
        }
    }
    std::lock_guard lock(result_mutex_);
    return last_result_.best_move;
}

std::vector<Move> Engine::principal_variation() const {
    if (searcher_.is_searching()) {
        return searcher_.info().principal_variation;
    }
    std::lock_guard lock(result_mutex_);
    return last_result_.principal_variation;
}

std::vector<PrincipalVariationLine> Engine::multipv() const {
    if (searcher_.is_searching()) {
        return searcher_.info().multipv;
    }
    std::lock_guard lock(result_mutex_);
    return last_result_.multipv;
}

Score Engine::evaluate_position() const {
    std::lock_guard lock(position_mutex_);
    SearchOptions selected_options;
    {
        std::lock_guard options_lock(options_mutex_);
        selected_options = options_;
    }
    const Score hce_score = evaluate(position_, selected_options.evaluation_weights);
    return evaluate_with_nnue_fallback(position_, hce_score, selected_options.nnue).score;
}

bool Engine::is_searching() const noexcept {
    return worker_active_.load(std::memory_order_acquire);
}

std::string Engine::last_error() const {
    std::lock_guard lock(result_mutex_);
    return last_error_;
}

void Engine::stop_and_join() noexcept {
    std::lock_guard lock(worker_mutex_);
    external_pause_requested_.store(false, std::memory_order_release);
    if (worker_.joinable()) {
        worker_.request_stop();
    }
    searcher_.stop();
    searcher_.resume();
    if (worker_.joinable()) {
        worker_.join();
    }
    worker_active_.store(false, std::memory_order_release);
}

void Engine::set_last_error(std::string message) {
    std::lock_guard lock(result_mutex_);
    last_error_ = std::move(message);
}

}  // namespace albay
