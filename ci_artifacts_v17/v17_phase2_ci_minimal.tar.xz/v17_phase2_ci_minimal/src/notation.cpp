/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/notation.hpp"

#include "albay/geometry.hpp"
#include "albay/movegen.hpp"

#include <algorithm>
#include <bit>
#include <cstdint>
#include <exception>
#include <cctype>
#include <charconv>
#include <sstream>
#include <vector>

namespace albay {

namespace {

[[nodiscard]] std::string trim_copy(std::string_view text) {
    std::size_t first = 0;
    while (first < text.size() && std::isspace(static_cast<unsigned char>(text[first]))) {
        ++first;
    }
    std::size_t last = text.size();
    while (last > first && std::isspace(static_cast<unsigned char>(text[last - 1]))) {
        --last;
    }
    return std::string(text.substr(first, last - first));
}

[[nodiscard]] bool parse_piece_list(
    std::string_view list,
    Color color,
    Bitboard& white,
    Bitboard& black,
    Bitboard& kings,
    std::string* error) {
    const std::string cleaned = trim_copy(list);
    if (cleaned.empty() || cleaned == "-") {
        return true;
    }

    std::size_t start = 0;
    while (start <= cleaned.size()) {
        const std::size_t comma = cleaned.find(',', start);
        const std::size_t end = comma == std::string::npos ? cleaned.size() : comma;
        std::string token = trim_copy(std::string_view(cleaned).substr(start, end - start));
        bool king = false;
        if (!token.empty() && (token.front() == 'K' || token.front() == 'k')) {
            king = true;
            token.erase(token.begin());
        }
        const auto square = parse_square(token);
        if (!square.has_value()) {
            if (error != nullptr) {
                *error = "invalid APF square token: " + token;
            }
            return false;
        }
        const Bitboard square_bit = bit(*square);
        if (((white | black) & square_bit) != 0) {
            if (error != nullptr) {
                *error = "duplicate APF square: " + token;
            }
            return false;
        }
        if (color == Color::White) {
            white |= square_bit;
        } else {
            black |= square_bit;
        }
        if (king) {
            kings |= square_bit;
        }
        if (comma == std::string::npos) {
            break;
        }
        start = comma + 1;
    }
    return true;
}

void append_piece_list(std::ostringstream& output, const Position& position, Color color) {
    bool first = true;
    Bitboard pieces = position.pieces(color);
    while (pieces != 0) {
        const Square square = static_cast<Square>(std::countr_zero(pieces));
        pieces &= pieces - 1U;
        if (!first) {
            output << ',';
        }
        if (position.is_king(square)) {
            output << 'K';
        }
        output << square_name(square);
        first = false;
    }
    if (first) {
        output << '-';
    }
}

}  // namespace


std::string move_to_string(const Move& move) {
    std::string result = square_name(move.from);
    const char separator = move.is_capture() ? 'x' : '-';
    for (std::uint8_t index = 0; index < move.landing_count; ++index) {
        result.push_back(separator);
        result += square_name(move.landings[index]);
    }
    return result;
}

std::optional<Move> parse_legal_move(const Position& position, std::string_view text) {
    std::vector<Square> path;
    bool saw_capture_separator = false;
    std::size_t index = 0;

    while (index < text.size()) {
        while (index < text.size() && std::isspace(static_cast<unsigned char>(text[index]))) {
            ++index;
        }
        if (index + 1 >= text.size()) {
            return std::nullopt;
        }
        const auto square = parse_square(text.substr(index, 2));
        if (!square.has_value()) {
            return std::nullopt;
        }
        path.push_back(*square);
        index += 2;

        while (index < text.size() && std::isspace(static_cast<unsigned char>(text[index]))) {
            ++index;
        }
        if (index >= text.size()) {
            break;
        }
        const char separator = static_cast<char>(std::tolower(static_cast<unsigned char>(text[index])));
        if (separator != '-' && separator != 'x' && separator != ':') {
            return std::nullopt;
        }
        saw_capture_separator = saw_capture_separator || separator == 'x' || separator == ':';
        ++index;
    }

    if (path.size() < 2) {
        return std::nullopt;
    }

    MoveList legal_moves;
    generate_legal_moves(position, legal_moves);
    for (const Move& move : legal_moves) {
        if (move.is_capture() != saw_capture_separator || move.from != path.front() ||
            move.landing_count != path.size() - 1) {
            continue;
        }
        bool matches = true;
        for (std::size_t path_index = 1; path_index < path.size(); ++path_index) {
            if (move.landings[path_index - 1] != path[path_index]) {
                matches = false;
                break;
            }
        }
        if (matches) {
            return move;
        }
    }
    return std::nullopt;
}

std::string position_to_ascii(const Position& position) {
    std::ostringstream output;
    output << "  a b c d e f g h\n";
    for (int rank = 7; rank >= 0; --rank) {
        output << (rank + 1) << ' ';
        for (int file = 0; file < 8; ++file) {
            const Square square = square_from_file_rank(file, rank);
            char symbol = '.';
            if (!is_valid_square(square)) {
                symbol = ' ';
            } else if ((position.white() & bit(square)) != 0) {
                symbol = position.is_king(square) ? 'W' : 'w';
            } else if ((position.black() & bit(square)) != 0) {
                symbol = position.is_king(square) ? 'B' : 'b';
            }
            output << symbol << ' ';
        }
        output << (rank + 1) << '\n';
    }
    output << "  a b c d e f g h\n";
    output << "Side: " << (position.side_to_move() == Color::White ? "White" : "Black") << '\n';
    return output.str();
}


std::string position_to_apf(const Position& position) {
    std::ostringstream output;
    output << (position.side_to_move() == Color::White ? 'W' : 'B') << ":W";
    append_piece_list(output, position, Color::White);
    output << ":B";
    append_piece_list(output, position, Color::Black);
    output << ";NP=" << position.no_progress_plies();
    return output.str();
}

std::optional<Position> parse_apf(std::string_view text, std::string* error) {
    const std::string input = trim_copy(text);
    if (input.size() < 6 || (input[0] != 'W' && input[0] != 'w' && input[0] != 'B' && input[0] != 'b') ||
        input[1] != ':') {
        if (error != nullptr) {
            *error = "APF must begin with W: or B:";
        }
        return std::nullopt;
    }

    const std::size_t white_marker = 2;
    if (white_marker >= input.size() || (input[white_marker] != 'W' && input[white_marker] != 'w')) {
        if (error != nullptr) {
            *error = "APF is missing the white piece list";
        }
        return std::nullopt;
    }
    const std::size_t black_separator = input.find(":B", white_marker + 1);
    const std::size_t black_separator_lower = input.find(":b", white_marker + 1);
    const std::size_t black_pos = black_separator != std::string::npos ? black_separator : black_separator_lower;
    if (black_pos == std::string::npos) {
        if (error != nullptr) {
            *error = "APF is missing the black piece list";
        }
        return std::nullopt;
    }
    const std::size_t option_pos = input.find(';', black_pos + 2);
    const std::string_view white_list(input.data() + white_marker + 1, black_pos - white_marker - 1);
    const std::size_t black_end = option_pos == std::string::npos ? input.size() : option_pos;
    const std::string_view black_list(input.data() + black_pos + 2, black_end - (black_pos + 2));

    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    if (!parse_piece_list(white_list, Color::White, white, black, kings, error) ||
        !parse_piece_list(black_list, Color::Black, white, black, kings, error)) {
        return std::nullopt;
    }

    std::uint16_t no_progress = 0;
    if (option_pos != std::string::npos) {
        const std::string option = trim_copy(std::string_view(input).substr(option_pos + 1));
        if (option.rfind("NP=", 0) != 0 && option.rfind("np=", 0) != 0) {
            if (error != nullptr) {
                *error = "unsupported APF option";
            }
            return std::nullopt;
        }
        unsigned value = 0;
        const char* begin = option.data() + 3;
        const char* end = option.data() + option.size();
        const auto [ptr, code] = std::from_chars(begin, end, value);
        if (code != std::errc{} || ptr != end || value > UINT16_MAX) {
            if (error != nullptr) {
                *error = "invalid APF no-progress value";
            }
            return std::nullopt;
        }
        no_progress = static_cast<std::uint16_t>(value);
    }

    try {
        return Position::from_bitboards(
            white,
            black,
            kings,
            input[0] == 'W' || input[0] == 'w' ? Color::White : Color::Black,
            no_progress);
    } catch (const std::exception& exception) {
        if (error != nullptr) {
            *error = exception.what();
        }
        return std::nullopt;
    }
}

}  // namespace albay
