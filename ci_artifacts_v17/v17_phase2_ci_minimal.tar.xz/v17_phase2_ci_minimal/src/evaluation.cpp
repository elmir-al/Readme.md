/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/evaluation.hpp"

#include "albay/geometry.hpp"
#include "albay/strategic_ordering.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cstdlib>

namespace albay {
namespace {

[[nodiscard]] constexpr int sign(Color color) noexcept {
    return color == Color::White ? 1 : -1;
}

[[nodiscard]] consteval auto make_coordinates() noexcept {
    std::array<BoardCoordinate, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        result[static_cast<std::size_t>(square)] = coordinate_of(static_cast<Square>(square));
    }
    return result;
}

inline constexpr auto kCoordinates = make_coordinates();

[[nodiscard]] consteval auto make_center_values() noexcept {
    std::array<int, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        const BoardCoordinate coordinate = kCoordinates[static_cast<std::size_t>(square)];
        const int edge_distance = std::min(
            std::min(coordinate.file, 7 - coordinate.file),
            std::min(coordinate.rank, 7 - coordinate.rank));
        result[static_cast<std::size_t>(square)] = edge_distance >= 2 ? 3 :
            (edge_distance == 1 ? 1 : -1);
    }
    return result;
}

inline constexpr auto kCenterValues = make_center_values();

[[nodiscard]] consteval auto make_neighbour_masks() noexcept {
    std::array<Bitboard, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        Bitboard mask = 0;
        for (std::size_t direction = 0; direction < 4; ++direction) {
            const Square target = diagonal_step(static_cast<Square>(square), direction);
            if (is_valid_square(target)) {
                mask |= bit(target);
            }
        }
        result[static_cast<std::size_t>(square)] = mask;
    }
    return result;
}

inline constexpr auto kNeighbourMasks = make_neighbour_masks();


[[nodiscard]] consteval auto make_man_static_values(Color color) noexcept {
    std::array<int, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        const BoardCoordinate coordinate = kCoordinates[static_cast<std::size_t>(square)];
        const int advance = color == Color::White ? coordinate.rank : 7 - coordinate.rank;
        const int promotion = advance >= 5 ? (advance - 4) * 12 : 0;
        const bool home = color == Color::White ? coordinate.rank == 0 : coordinate.rank == 7;
        result[static_cast<std::size_t>(square)] =
            kCenterValues[static_cast<std::size_t>(square)] * 4 +
            advance * 3 + promotion + (home ? 8 : 0);
    }
    return result;
}

[[nodiscard]] constexpr int absolute_int(int value) noexcept {
    return value < 0 ? -value : value;
}

[[nodiscard]] consteval auto make_king_static_values() noexcept {
    std::array<int, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        const BoardCoordinate coordinate = kCoordinates[static_cast<std::size_t>(square)];
        const int central_distance =
            absolute_int(coordinate.file - 3) + absolute_int(coordinate.rank - 3);
        result[static_cast<std::size_t>(square)] =
            kCenterValues[static_cast<std::size_t>(square)] * 7 +
            (18 - central_distance * 2);
    }
    return result;
}

inline constexpr auto kWhiteManStaticValues = make_man_static_values(Color::White);
inline constexpr auto kBlackManStaticValues = make_man_static_values(Color::Black);
inline constexpr auto kKingStaticValues = make_king_static_values();

[[nodiscard]] constexpr Bitboard shift_direction_0(Bitboard board) noexcept {
    return ((board & 0xF0F0F0F0U) >> 4U) |
        ((board & 0x0E0E0E00U) >> 5U);
}

[[nodiscard]] constexpr Bitboard shift_direction_1(Bitboard board) noexcept {
    return ((board & 0x70707070U) >> 3U) |
        ((board & 0x0F0F0F00U) >> 4U);
}

[[nodiscard]] constexpr Bitboard shift_direction_2(Bitboard board) noexcept {
    return ((board & 0x0E0E0E0EU) << 3U) |
        ((board & 0x00F0F0F0U) << 4U);
}

[[nodiscard]] constexpr Bitboard shift_direction_3(Bitboard board) noexcept {
    return ((board & 0x0F0F0F0FU) << 4U) |
        ((board & 0x00707070U) << 5U);
}

template <std::size_t N>
[[nodiscard]] consteval auto make_byte_sum_table(const std::array<int, N>& values) noexcept {
    static_assert(N == kBoardSquares);
    std::array<std::array<int, 256>, 4> result{};
    for (std::size_t chunk = 0; chunk < 4; ++chunk) {
        for (std::size_t byte = 0; byte < 256; ++byte) {
            int sum = 0;
            for (std::size_t bit_index = 0; bit_index < 8; ++bit_index) {
                if ((byte & (std::size_t{1} << bit_index)) != 0) {
                    sum += values[chunk * 8 + bit_index];
                }
            }
            result[chunk][byte] = sum;
        }
    }
    return result;
}

[[nodiscard]] consteval auto make_white_man_base_values() noexcept {
    std::array<int, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        result[static_cast<std::size_t>(square)] =
            100 + kWhiteManStaticValues[static_cast<std::size_t>(square)];
    }
    return result;
}

[[nodiscard]] consteval auto make_black_man_base_values() noexcept {
    std::array<int, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        result[static_cast<std::size_t>(square)] =
            100 + kBlackManStaticValues[static_cast<std::size_t>(square)];
    }
    return result;
}

[[nodiscard]] consteval auto make_king_base_values() noexcept {
    std::array<int, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        result[static_cast<std::size_t>(square)] =
            315 + kKingStaticValues[static_cast<std::size_t>(square)];
    }
    return result;
}

inline constexpr auto kWhiteManBaseSums =
    make_byte_sum_table(make_white_man_base_values());
inline constexpr auto kBlackManBaseSums =
    make_byte_sum_table(make_black_man_base_values());
inline constexpr auto kKingBaseSums =
    make_byte_sum_table(make_king_base_values());

[[nodiscard]] int byte_table_sum(
    Bitboard board,
    const std::array<std::array<int, 256>, 4>& table) noexcept {
    return table[0][board & 0xFFU] +
        table[1][(board >> 8U) & 0xFFU] +
        table[2][(board >> 16U) & 0xFFU] +
        table[3][(board >> 24U) & 0xFFU];
}

struct DefaultManDynamicTotals {
    int mobility = 0;
    int immobile = 0;
    int capture_opportunities = 0;
};

[[nodiscard]] int default_man_capture_opportunities(
    Bitboard men,
    Bitboard opponents,
    Bitboard empty) noexcept {
    return
        std::popcount(men & shift_direction_3(opponents) &
            shift_direction_3(shift_direction_3(empty))) +
        std::popcount(men & shift_direction_2(opponents) &
            shift_direction_2(shift_direction_2(empty))) +
        std::popcount(men & shift_direction_1(opponents) &
            shift_direction_1(shift_direction_1(empty))) +
        std::popcount(men & shift_direction_0(opponents) &
            shift_direction_0(shift_direction_0(empty)));
}

[[nodiscard]] DefaultManDynamicTotals default_white_man_totals(
    Bitboard men,
    Bitboard opponents,
    Bitboard empty) noexcept {
    DefaultManDynamicTotals result{};
    result.mobility = std::popcount(shift_direction_2(men) & empty) +
        std::popcount(shift_direction_3(men) & empty);
    const Bitboard mobile_sources = men &
        (shift_direction_1(empty) | shift_direction_0(empty));
    result.immobile = std::popcount(men & ~mobile_sources);
    result.capture_opportunities =
        default_man_capture_opportunities(men, opponents, empty);
    return result;
}

[[nodiscard]] DefaultManDynamicTotals default_black_man_totals(
    Bitboard men,
    Bitboard opponents,
    Bitboard empty) noexcept {
    DefaultManDynamicTotals result{};
    result.mobility = std::popcount(shift_direction_0(men) & empty) +
        std::popcount(shift_direction_1(men) & empty);
    const Bitboard mobile_sources = men &
        (shift_direction_3(empty) | shift_direction_2(empty));
    result.immobile = std::popcount(men & ~mobile_sources);
    result.capture_opportunities =
        default_man_capture_opportunities(men, opponents, empty);
    return result;
}

[[nodiscard]] int default_king_dynamic_score(
    Bitboard occupied,
    Bitboard opponents,
    Square square) noexcept {
    int mobility = 0;
    int opportunities = 0;
    for (std::size_t direction = 0; direction < 4; ++direction) {
        Square cursor = kDiagonalStepTable[static_cast<std::size_t>(square)][direction];
        while (is_valid_square(cursor) && (occupied & bit(cursor)) == 0) {
            ++mobility;
            cursor = kDiagonalStepTable[static_cast<std::size_t>(cursor)][direction];
        }
        if (!is_valid_square(cursor) || (opponents & bit(cursor)) == 0) {
            continue;
        }
        const Square landing = kDiagonalStepTable[static_cast<std::size_t>(cursor)][direction];
        opportunities += is_valid_square(landing) && (occupied & bit(landing)) == 0;
    }
    return mobility * 2 + opportunities * 16 - (mobility == 0 ? 16 : 0);
}

[[nodiscard]] Score evaluate_default_white_fast(const Position& position) noexcept {
    const Bitboard occupied = position.occupied();
    const Bitboard kings = position.kings();
    const Bitboard white = position.white();
    const Bitboard black = position.black();
    const Bitboard white_men = white & ~kings;
    const Bitboard black_men = black & ~kings;
    const Bitboard white_kings = white & kings;
    const Bitboard black_kings = black & kings;
    const Bitboard empty = ~occupied;
    const int total_pieces = std::popcount(occupied);
    const int endgame_weight = std::clamp(24 - total_pieces, 0, 16);

    Score score =
        byte_table_sum(white_men, kWhiteManBaseSums) -
        byte_table_sum(black_men, kBlackManBaseSums) +
        byte_table_sum(white_kings, kKingBaseSums) -
        byte_table_sum(black_kings, kKingBaseSums);

    const DefaultManDynamicTotals white_dynamic =
        default_white_man_totals(white_men, black, empty);
    const DefaultManDynamicTotals black_dynamic =
        default_black_man_totals(black_men, white, empty);
    score += (white_dynamic.mobility - black_dynamic.mobility) * 3;
    score -= (white_dynamic.immobile - black_dynamic.immobile) * 5;
    score += (white_dynamic.capture_opportunities - black_dynamic.capture_opportunities) * 13;

    const int king_count_difference =
        std::popcount(white_kings) - std::popcount(black_kings);
    score += king_count_difference * endgame_weight * 2;

    Bitboard pieces = white_kings;
    while (pieces != 0) {
        const Square square = static_cast<Square>(std::countr_zero(pieces));
        pieces &= pieces - 1U;
        score += default_king_dynamic_score(occupied, black, square);
    }
    pieces = black_kings;
    while (pieces != 0) {
        const Square square = static_cast<Square>(std::countr_zero(pieces));
        pieces &= pieces - 1U;
        score -= default_king_dynamic_score(occupied, white, square);
    }

    const int back_rank_difference =
        std::popcount(white_men & 0x0000000FU) -
        std::popcount(black_men & 0xF0000000U);
    score += back_rank_difference * (total_pieces > 14 ? 5 : -2);
    return score;
}

[[nodiscard]] constexpr int man_advance(Color color, Square square) noexcept {
    const int rank = kCoordinates[static_cast<std::size_t>(square)].rank;
    return color == Color::White ? rank : 7 - rank;
}

[[nodiscard]] int quiet_mobility_for_piece(
    Bitboard occupied,
    Bitboard kings,
    Color color,
    Square square) noexcept {
    int mobility = 0;
    if ((kings & bit(square)) != 0) {
        for (std::size_t direction = 0; direction < 4; ++direction) {
            Square cursor = diagonal_step(square, direction);
            while (is_valid_square(cursor) && (occupied & bit(cursor)) == 0) {
                ++mobility;
                cursor = diagonal_step(cursor, direction);
            }
        }
        return mobility;
    }

    const std::size_t first_direction = color == Color::White ? 2U : 0U;
    for (std::size_t offset = 0; offset < 2; ++offset) {
        const Square target = diagonal_step(square, first_direction + offset);
        if (is_valid_square(target) && (occupied & bit(target)) == 0) {
            ++mobility;
        }
    }
    return mobility;
}

[[nodiscard]] int capture_opportunities_for_piece(
    Bitboard occupied,
    Bitboard kings,
    Bitboard opponents,
    Square square) noexcept {
    int opportunities = 0;

    if ((kings & bit(square)) == 0) {
        for (std::size_t direction = 0; direction < 4; ++direction) {
            const Square jumped = diagonal_step(square, direction);
            const Square landing = diagonal_jump(square, direction);
            if (is_valid_square(jumped) && is_valid_square(landing) &&
                (opponents & bit(jumped)) != 0 && (occupied & bit(landing)) == 0) {
                ++opportunities;
            }
        }
        return opportunities;
    }

    for (std::size_t direction = 0; direction < 4; ++direction) {
        Square cursor = diagonal_step(square, direction);
        while (is_valid_square(cursor) && (occupied & bit(cursor)) == 0) {
            cursor = diagonal_step(cursor, direction);
        }
        if (!is_valid_square(cursor) || (opponents & bit(cursor)) == 0) {
            continue;
        }
        const Square landing = diagonal_step(cursor, direction);
        if (is_valid_square(landing) && (occupied & bit(landing)) == 0) {
            ++opportunities;
        }
    }
    return opportunities;
}

[[nodiscard]] int forward_lane_count(
    Bitboard occupied, Color color, Square square) noexcept {
    const std::size_t first_direction = color == Color::White ? 2U : 0U;
    int lanes = 0;
    for (std::size_t offset = 0; offset < 2; ++offset) {
        const Square target = diagonal_step(square, first_direction + offset);
        if (is_valid_square(target) && (occupied & bit(target)) == 0) {
            ++lanes;
        }
    }
    return lanes;
}

[[nodiscard]] int rear_support_count(
    Bitboard friendly, Color color, Square square) noexcept {
    const std::size_t first_direction = color == Color::White ? 0U : 2U;
    int supports = 0;
    for (std::size_t offset = 0; offset < 2; ++offset) {
        const Square target = diagonal_step(square, first_direction + offset);
        if (is_valid_square(target) && (friendly & bit(target)) != 0) {
            ++supports;
        }
    }
    return supports;
}

[[nodiscard]] constexpr int diagonal_span_value(BoardCoordinate coordinate) noexcept {
    const int main_length = 8 - std::abs(coordinate.file - coordinate.rank);
    const int cross_length = 8 - std::abs((coordinate.file + coordinate.rank) - 7);
    return std::max(main_length, cross_length) - 4;
}

[[nodiscard]] bool phase19_fast_compatible(const EvaluationWeights& weights) noexcept {
    const EvaluationWeights defaults{};
    return weights.material == defaults.material &&
        weights.center == defaults.center &&
        weights.advancement == defaults.advancement &&
        weights.promotion_potential == defaults.promotion_potential &&
        weights.back_rank == defaults.back_rank &&
        weights.mobility == defaults.mobility &&
        weights.king_activity == defaults.king_activity &&
        weights.restriction == defaults.restriction &&
        weights.tactical_pressure == defaults.tactical_pressure &&
        weights.phase_adjustment == defaults.phase_adjustment &&
        weights.structure == defaults.structure &&
        weights.support_structure == defaults.support_structure &&
        weights.isolation == defaults.isolation &&
        weights.promotion_lanes == defaults.promotion_lanes &&
        weights.edge_passivity == defaults.edge_passivity &&
        weights.phase_adjustment_repeat == defaults.phase_adjustment_repeat &&
        weights.opening_center_scale == defaults.opening_center_scale &&
        weights.opening_back_rank_scale == defaults.opening_back_rank_scale &&
        weights.middlegame_structure_scale == defaults.middlegame_structure_scale &&
        weights.endgame_king_scale == defaults.endgame_king_scale &&
        weights.endgame_mobility_scale == defaults.endgame_mobility_scale &&
        weights.endgame_restriction_scale == defaults.endgame_restriction_scale &&
        weights.endgame_promotion_scale == defaults.endgame_promotion_scale &&
        weights.king_confinement == 0 &&
        weights.promotion_race == 0 &&
        weights.wing_balance == 0 &&
        weights.rear_support == 0 &&
        weights.diagonal_control == 0 &&
        weights.space_pressure == 0 &&
        weights.strategic_pst == 0;
}

[[nodiscard]] Score evaluate_phase19_fast_white(
    const Position& position,
    const EvaluationWeights& weights) noexcept {
    Score score = evaluate_default_white_fast(position);
    const int total_pieces = std::popcount(position.occupied());
    if (total_pieces < weights.strategic_min_pieces ||
        total_pieces > weights.strategic_max_pieces ||
        std::popcount(position.kings()) > weights.strategic_max_kings ||
        (weights.advanced_exposure == 0 && weights.reserve_tempo == 0)) {
        return score;
    }

    const Bitboard occupied = position.occupied();
    const Bitboard kings = position.kings();
    Score advanced_exposure = 0;
    Score reserve_tempo = 0;
    for (const Color color : {Color::White, Color::Black}) {
        const int color_sign = sign(color);
        const Bitboard friendly = position.pieces(color);
        Bitboard men = friendly & ~kings;
        while (men != 0) {
            const Square square = static_cast<Square>(std::countr_zero(men));
            men &= men - 1U;
            const int advance = man_advance(color, square);
            if (advance < 3 && weights.reserve_tempo == 0) continue;
            if (advance > 2 && weights.advanced_exposure == 0) continue;
            const int mobility = quiet_mobility_for_piece(occupied, kings, color, square);
            if (weights.advanced_exposure != 0 && advance >= 3 &&
                rear_support_count(friendly, color, square) == 0) {
                const int exposure = 4 + (advance - 3) * 2 + (mobility == 0 ? 3 : 0);
                advanced_exposure -= color_sign * exposure;
            }
            if (weights.reserve_tempo != 0 && advance <= 2 && mobility > 0) {
                reserve_tempo += color_sign * (3 - advance) * 3;
            }
        }
    }
    score += advanced_exposure * weights.advanced_exposure / 100;
    score += reserve_tempo * weights.reserve_tempo / 100;
    return score;
}

}  // namespace

EvaluationBreakdown evaluate_breakdown(
    const Position& position,
    bool include_structure,
    bool include_phase5_features,
    bool include_phase9_features) {
    EvaluationBreakdown result{};
    const Bitboard occupied = position.occupied();
    const Bitboard kings = position.kings();
    const int total_pieces = std::popcount(occupied);
    const int endgame_weight = std::clamp(24 - total_pieces, 0, 16);
    std::array<int, 2> best_man_advance{0, 0};
    std::array<int, 2> man_counts{0, 0};
    std::array<int, 2> left_wing_men{0, 0};
    std::array<int, 2> right_wing_men{0, 0};

    for (const Color color : {Color::White, Color::Black}) {
        const int color_sign = sign(color);
        Bitboard pieces_left = position.pieces(color);
        while (pieces_left != 0) {
            const Square square = static_cast<Square>(std::countr_zero(pieces_left));
            pieces_left &= pieces_left - 1U;
            const bool king = (kings & bit(square)) != 0;
            const BoardCoordinate coordinate = kCoordinates[static_cast<std::size_t>(square)];
            const int mobility = quiet_mobility_for_piece(occupied, kings, color, square);

            result.material += color_sign * (king ? 315 : 100);
            result.center += color_sign * kCenterValues[static_cast<std::size_t>(square)] * (king ? 7 : 4);
            result.mobility += color_sign * mobility * (king ? 2 : 3);
            if (mobility == 0) {
                result.restriction -= color_sign * (king ? 16 : 5);
            }
            result.tactical_pressure += color_sign *
                capture_opportunities_for_piece(occupied, kings, position.pieces(opposite(color)), square) *
                (king ? 16 : 13);

            if (include_phase9_features) {
                result.diagonal_control += color_sign * diagonal_span_value(coordinate) * (king ? 5 : 2);
            }

            if (include_phase5_features || include_structure) {
                const int neighbours = std::popcount(
                    position.pieces(color) & kNeighbourMasks[static_cast<std::size_t>(square)]);
                if (include_phase5_features) {
                    result.support_structure += color_sign * neighbours * (king ? 2 : 4);
                    if (!king) {
                        const bool middle_board = coordinate.rank >= 2 && coordinate.rank <= 5;
                        if (middle_board && neighbours == 0) {
                            result.isolation -= color_sign * 6;
                        }
                        if (middle_board && (coordinate.file == 0 || coordinate.file == 7)) {
                            result.edge_passivity -= color_sign * 4;
                        }
                    }
                }

                if (include_structure) {
                    if (king) {
                        result.structure += color_sign * neighbours * 2;
                    } else {
                        const bool middle_board = coordinate.rank >= 2 && coordinate.rank <= 5;
                        result.structure += color_sign * neighbours * 3;
                        if (middle_board && neighbours == 0) {
                            result.structure -= color_sign * 4;
                        }
                        if (middle_board && (coordinate.file == 0 || coordinate.file == 7)) {
                            result.structure -= color_sign * 2;
                        }
                    }
                }
            }

            if (king) {
                const int central_distance = absolute_int(coordinate.file - 3) + absolute_int(coordinate.rank - 3);
                result.king_activity += color_sign * (18 - central_distance * 2);
                result.phase_adjustment += color_sign * endgame_weight * 2;
                if (total_pieces <= 8) {
                    result.king_confinement += color_sign * (mobility * 2 - central_distance);
                }
                continue;
            }

            const int advance = man_advance(color, square);
            const std::size_t color_slot = color == Color::White ? 0U : 1U;
            best_man_advance[color_slot] = std::max(best_man_advance[color_slot], advance);
            ++man_counts[color_slot];
            if (include_phase9_features) {
                result.strategic_pst += color_sign *
                    strategic_man_square_value(position, color, square);
                if (coordinate.file <= 3) ++left_wing_men[color_slot];
                else ++right_wing_men[color_slot];
                const int rear_supports = rear_support_count(position.pieces(color), color, square);
                result.rear_support += color_sign * rear_supports * (advance >= 3 ? 5 : 3);
                if (advance >= 3 && rear_supports == 0) {
                    const int exposure = 4 + (advance - 3) * 2 + (mobility == 0 ? 3 : 0);
                    result.advanced_exposure -= color_sign * exposure;
                }
                if (advance <= 2 && mobility > 0) {
                    result.reserve_tempo += color_sign * (3 - advance) * 3;
                }
                if (advance >= 4 && rear_supports > 0 && mobility > 0) {
                    result.space_pressure += color_sign * (advance - 2) * (rear_supports + 1);
                }
            }
            result.advancement += color_sign * advance * 3;
            result.promotion_potential += color_sign * (advance >= 5 ? (advance - 4) * 12 : 0);
            if ((include_phase5_features || include_structure) && advance >= 4) {
                const int forward_lanes = forward_lane_count(occupied, color, square);
                if (include_phase5_features) {
                    result.promotion_lanes += color_sign * forward_lanes * (advance >= 6 ? 9 : 4);
                    if (forward_lanes == 0 && advance >= 5) {
                        result.promotion_lanes -= color_sign * 5;
                    }
                }
                if (include_structure) {
                    result.structure += color_sign * forward_lanes * (advance >= 6 ? 7 : 3);
                    if (forward_lanes == 0) {
                        result.structure -= color_sign * 4;
                    }
                }
            }

            const bool on_home_rank = color == Color::White ? coordinate.rank == 0 : coordinate.rank == 7;
            if (on_home_rank) {
                result.back_rank += color_sign * 8;
            }
        }
    }

    if (include_phase9_features) {
        const int white_imbalance = std::abs(left_wing_men[0] - right_wing_men[0]);
        const int black_imbalance = std::abs(left_wing_men[1] - right_wing_men[1]);
        result.wing_balance = (black_imbalance - white_imbalance) * 4;
    }

    const int white_back_rank_count = std::popcount(position.men(Color::White) & 0x0000000FU);
    const int black_back_rank_count = std::popcount(position.men(Color::Black) & 0xF0000000U);
    if (total_pieces > 14) {
        result.back_rank += (white_back_rank_count - black_back_rank_count) * 5;
    } else {
        result.back_rank -= (white_back_rank_count - black_back_rank_count) * 2;
    }

    if (total_pieces <= 8 && (man_counts[0] > 0 || man_counts[1] > 0)) {
        result.promotion_race = (best_man_advance[0] - best_man_advance[1]) * 12;
        if (man_counts[0] > 0 && man_counts[1] > 0) {
            result.promotion_race += position.side_to_move() == Color::White ? 3 : -3;
        }
    }

    result.total_white_perspective =
        result.material + result.center + result.advancement + result.promotion_potential +
        result.back_rank + result.mobility + result.king_activity + result.restriction +
        result.tactical_pressure + result.phase_adjustment;
    return result;
}

EvaluationPhaseMix evaluation_phase_mix(const Position& position) noexcept {
    const int pieces = std::popcount(position.occupied());
    EvaluationPhaseMix mix{};
    mix.opening = std::clamp((pieces - 16) * 100 / 8, 0, 100);
    mix.endgame = std::clamp((12 - pieces) * 100 / 8, 0, 100);
    mix.middlegame = std::max(0, 100 - mix.opening - mix.endgame);
    return mix;
}

Score weighted_total(
    const EvaluationBreakdown& breakdown,
    const EvaluationWeights& weights) noexcept {
    const auto scaled = [](Score value, int percent) noexcept -> Score {
        return static_cast<Score>((static_cast<long long>(value) * percent) / 100LL);
    };
    const Score phase_once = scaled(breakdown.phase_adjustment, weights.phase_adjustment);
    return scaled(breakdown.material, weights.material) +
        scaled(breakdown.center, weights.center) +
        scaled(breakdown.advancement, weights.advancement) +
        scaled(breakdown.promotion_potential, weights.promotion_potential) +
        scaled(breakdown.back_rank, weights.back_rank) +
        scaled(breakdown.mobility, weights.mobility) +
        scaled(breakdown.king_activity, weights.king_activity) +
        scaled(breakdown.restriction, weights.restriction) +
        scaled(breakdown.tactical_pressure, weights.tactical_pressure) +
        phase_once + scaled(phase_once, weights.phase_adjustment_repeat) +
        scaled(breakdown.structure, weights.structure) +
        scaled(breakdown.support_structure, weights.support_structure) +
        scaled(breakdown.isolation, weights.isolation) +
        scaled(breakdown.promotion_lanes, weights.promotion_lanes) +
        scaled(breakdown.edge_passivity, weights.edge_passivity) +
        scaled(breakdown.king_confinement, weights.king_confinement) +
        scaled(breakdown.promotion_race, weights.promotion_race) +
        scaled(breakdown.wing_balance, weights.wing_balance) +
        scaled(breakdown.rear_support, weights.rear_support) +
        scaled(breakdown.advanced_exposure, weights.advanced_exposure) +
        scaled(breakdown.diagonal_control, weights.diagonal_control) +
        scaled(breakdown.reserve_tempo, weights.reserve_tempo) +
        scaled(breakdown.space_pressure, weights.space_pressure) +
        scaled(breakdown.strategic_pst, weights.strategic_pst);
}

Score weighted_total_for_position(
    const Position& position,
    const EvaluationBreakdown& breakdown,
    const EvaluationWeights& weights) noexcept {
    const auto phase_scale = [](int configured, int phase_percent) noexcept -> int {
        return 100 + ((configured - 100) * phase_percent) / 100;
    };
    const EvaluationPhaseMix mix = evaluation_phase_mix(position);
    EvaluationWeights adjusted = weights;
    adjusted.center = adjusted.center * phase_scale(weights.opening_center_scale, mix.opening) / 100;
    adjusted.back_rank = adjusted.back_rank * phase_scale(weights.opening_back_rank_scale, mix.opening) / 100;
    const int middle_scale = phase_scale(weights.middlegame_structure_scale, mix.middlegame);
    adjusted.structure = adjusted.structure * middle_scale / 100;
    adjusted.support_structure = adjusted.support_structure * middle_scale / 100;
    adjusted.isolation = adjusted.isolation * middle_scale / 100;
    adjusted.king_activity = adjusted.king_activity *
        phase_scale(weights.endgame_king_scale, mix.endgame) / 100;
    adjusted.king_confinement = adjusted.king_confinement *
        phase_scale(weights.endgame_king_scale, mix.endgame) / 100;
    adjusted.mobility = adjusted.mobility *
        phase_scale(weights.endgame_mobility_scale, mix.endgame) / 100;
    adjusted.restriction = adjusted.restriction *
        phase_scale(weights.endgame_restriction_scale, mix.endgame) / 100;
    const int promotion_scale = phase_scale(weights.endgame_promotion_scale, mix.endgame);
    adjusted.promotion_potential = adjusted.promotion_potential * promotion_scale / 100;
    adjusted.promotion_lanes = adjusted.promotion_lanes * promotion_scale / 100;
    adjusted.promotion_race = adjusted.promotion_race * promotion_scale / 100;
    return weighted_total(breakdown, adjusted);
}

Score evaluate_white_perspective(
    const Position& position,
    const EvaluationWeights& weights) {
    if (phase19_fast_compatible(weights)) {
        return evaluate_phase19_fast_white(position, weights);
    }
    const bool phase5_enabled = weights.support_structure != 0 || weights.isolation != 0 ||
        weights.promotion_lanes != 0 || weights.edge_passivity != 0 ||
        weights.king_confinement != 0 || weights.promotion_race != 0;
    const int total_pieces = std::popcount(position.occupied());
    const bool strategic_weights_enabled = weights.wing_balance != 0 || weights.rear_support != 0 ||
        weights.advanced_exposure != 0 || weights.diagonal_control != 0 ||
        weights.reserve_tempo != 0 || weights.space_pressure != 0 ||
        weights.strategic_pst != 0;
    const bool phase9_enabled = strategic_weights_enabled &&
        total_pieces >= weights.strategic_min_pieces &&
        total_pieces <= weights.strategic_max_pieces &&
        std::popcount(position.kings()) <= weights.strategic_max_kings;
    return weighted_total_for_position(
        position, evaluate_breakdown(position, weights.structure != 0, phase5_enabled, phase9_enabled), weights);
}

Score evaluate_default(const Position& position) noexcept {
    const Score white_score = evaluate_default_white_fast(position);
    return position.side_to_move() == Color::White ? white_score : -white_score;
}

Score evaluate(const Position& position, const EvaluationWeights& weights) {
    const Score white_score = evaluate_white_perspective(position, weights);
    return position.side_to_move() == Color::White ? white_score : -white_score;
}

}  // namespace albay
