/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/exact_tablebase.hpp"

#include "albay/geometry.hpp"
#include "albay/movegen.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstring>
#include <fstream>
#include <limits>
#include <queue>
#include <span>
#include <type_traits>

namespace albay {
namespace {

inline constexpr std::array<char, 8> kMagic{{'A','L','B','T','B','3','1','\0'}};
inline constexpr std::size_t kHeaderBytes = 128;
inline constexpr std::uint64_t kFnvOffset = 1469598103934665603ULL;
inline constexpr std::uint64_t kFnvPrime = 1099511628211ULL;
inline constexpr std::int8_t kInternalInvalidOutcome = 0x7f;

[[nodiscard]] std::uint8_t pack_entry(EndgameOutcome outcome, std::uint16_t distance) {
    if (distance > 126U) return kTablebaseInvalidEntry;
    if (outcome == EndgameOutcome::Draw) return 0U;
    if (outcome == EndgameOutcome::Win) return static_cast<std::uint8_t>(1U + distance);
    if (outcome == EndgameOutcome::Loss) return static_cast<std::uint8_t>(128U + distance);
    return kTablebaseInvalidEntry;
}

[[nodiscard]] EndgameOutcome unpack_outcome(std::uint8_t entry) noexcept {
    if (entry == kTablebaseInvalidEntry) return EndgameOutcome::Unknown;
    if (entry == 0U) return EndgameOutcome::Draw;
    if (entry < 128U) return EndgameOutcome::Win;
    return EndgameOutcome::Loss;
}

[[nodiscard]] std::uint16_t unpack_distance(std::uint8_t entry) noexcept {
    if (entry == 0U || entry == kTablebaseInvalidEntry) return 0U;
    return entry < 128U ? static_cast<std::uint16_t>(entry - 1U)
                        : static_cast<std::uint16_t>(entry - 128U);
}

struct HeaderFields {
    std::uint32_t version = kExactTablebaseFormatVersion;
    std::uint32_t maximum_pieces = 0;
    std::uint64_t dense_states = 0;
    std::uint64_t legal_states = 0;
    std::uint64_t wins = 0;
    std::uint64_t draws = 0;
    std::uint64_t losses = 0;
    std::uint64_t payload_checksum = 0;
};

[[nodiscard]] constexpr std::uint64_t choose(int n, int k) noexcept {
    if (k < 0 || k > n) return 0;
    if (k == 0 || k == n) return 1;
    std::uint64_t result = 1;
    for (int i = 1; i <= k; ++i) {
        result = result * static_cast<std::uint64_t>(n - k + i) /
            static_cast<std::uint64_t>(i);
    }
    return result;
}

[[nodiscard]] constexpr std::uint64_t pow4(int exponent) noexcept {
    return std::uint64_t{1} << (2 * exponent);
}

[[nodiscard]] constexpr std::uint64_t states_for_piece_count(int pieces) noexcept {
    return choose(kBoardSquares, pieces) * pow4(pieces) * 2ULL;
}

[[nodiscard]] constexpr std::uint64_t offset_for_piece_count(int pieces) noexcept {
    std::uint64_t offset = 0;
    for (int count = 1; count < pieces; ++count) offset += states_for_piece_count(count);
    return offset;
}

[[nodiscard]] std::uint64_t rank_combination(std::span<const Square> squares) noexcept {
    std::uint64_t rank = 0;
    for (std::size_t index = 0; index < squares.size(); ++index) {
        rank += choose(static_cast<int>(squares[index]), static_cast<int>(index + 1));
    }
    return rank;
}

[[nodiscard]] bool unrank_combination(
    std::uint64_t rank,
    int pieces,
    std::array<Square, 6>& squares) noexcept {
    int maximum = kBoardSquares - 1;
    for (int slot = pieces; slot >= 1; --slot) {
        int square = maximum;
        while (square >= 0 && choose(square, slot) > rank) --square;
        if (square < 0) return false;
        squares[static_cast<std::size_t>(slot - 1)] = static_cast<Square>(square);
        rank -= choose(square, slot);
        maximum = square - 1;
    }
    return rank == 0;
}

[[nodiscard]] std::optional<std::uint64_t> encode_position(
    const Position& position,
    int maximum_pieces) noexcept {
    const int pieces = std::popcount(position.occupied());
    if (pieces < 1 || pieces > maximum_pieces || pieces > 6) return std::nullopt;

    std::array<Square, 6> squares{};
    std::array<std::uint8_t, 6> types{};
    int used = 0;
    Bitboard occupied = position.occupied();
    while (occupied != 0) {
        const Square square = static_cast<Square>(std::countr_zero(occupied));
        occupied &= occupied - 1U;
        squares[static_cast<std::size_t>(used)] = square;
        const bool white = (position.white() & bit(square)) != 0;
        const bool king = position.is_king(square);
        types[static_cast<std::size_t>(used)] = static_cast<std::uint8_t>(
            white ? (king ? 1 : 0) : (king ? 3 : 2));
        ++used;
    }

    std::uint64_t type_code = 0;
    for (int index = 0; index < pieces; ++index) {
        type_code |= static_cast<std::uint64_t>(types[static_cast<std::size_t>(index)]) << (2 * index);
    }
    const std::uint64_t combination = rank_combination(
        std::span<const Square>(squares.data(), static_cast<std::size_t>(pieces)));
    const std::uint64_t local = (combination * pow4(pieces) + type_code) * 2ULL +
        static_cast<std::uint64_t>(position.side_to_move() == Color::Black);
    return offset_for_piece_count(pieces) + local;
}

struct DecodedState {
    Position position{};
    bool valid = false;
};

[[nodiscard]] DecodedState decode_state(std::uint64_t global_index, int maximum_pieces) {
    int pieces = 1;
    std::uint64_t offset = 0;
    for (; pieces <= maximum_pieces; ++pieces) {
        const std::uint64_t count = states_for_piece_count(pieces);
        if (global_index < offset + count) break;
        offset += count;
    }
    if (pieces > maximum_pieces || pieces > 6) return {};

    std::uint64_t local = global_index - offset;
    const Color side = (local & 1ULL) != 0 ? Color::Black : Color::White;
    local >>= 1U;
    const std::uint64_t type_mask = pow4(pieces) - 1ULL;
    const std::uint64_t type_code = local & type_mask;
    const std::uint64_t combination_rank = local >> (2 * pieces);

    std::array<Square, 6> squares{};
    if (!unrank_combination(combination_rank, pieces, squares)) return {};

    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    for (int index = 0; index < pieces; ++index) {
        const Square square = squares[static_cast<std::size_t>(index)];
        const std::uint8_t type = static_cast<std::uint8_t>((type_code >> (2 * index)) & 3ULL);
        const bool is_white = type < 2;
        const bool is_king_piece = (type & 1U) != 0;
        if (!is_king_piece) {
            const Color color = is_white ? Color::White : Color::Black;
            if (is_promotion_rank(color, square)) return {};
        }
        if (is_white) white |= bit(square);
        else black |= bit(square);
        if (is_king_piece) kings |= bit(square);
    }

    return {Position::from_bitboards(white, black, kings, side, 0), true};
}

[[nodiscard]] std::uint64_t fnv_update(std::uint64_t hash, const void* data, std::size_t size) noexcept {
    const auto* bytes = static_cast<const std::uint8_t*>(data);
    for (std::size_t index = 0; index < size; ++index) {
        hash ^= bytes[index];
        hash *= kFnvPrime;
    }
    return hash;
}

template <typename Integer>
void write_le(std::array<std::uint8_t, kHeaderBytes>& bytes, std::size_t offset, Integer value) {
    using Unsigned = std::make_unsigned_t<Integer>;
    const Unsigned converted = static_cast<Unsigned>(value);
    for (std::size_t index = 0; index < sizeof(Integer); ++index) {
        bytes[offset + index] = static_cast<std::uint8_t>((converted >> (8U * index)) & 0xFFU);
    }
}

template <typename Integer>
[[nodiscard]] Integer read_le(std::span<const std::uint8_t> bytes, std::size_t offset) {
    using Unsigned = std::make_unsigned_t<Integer>;
    Unsigned value = 0;
    for (std::size_t index = 0; index < sizeof(Integer); ++index) {
        value |= static_cast<Unsigned>(bytes[offset + index]) << (8U * index);
    }
    return static_cast<Integer>(value);
}

[[nodiscard]] std::array<std::uint8_t, kHeaderBytes> make_header(const HeaderFields& fields) {
    std::array<std::uint8_t, kHeaderBytes> bytes{};
    std::memcpy(bytes.data(), kMagic.data(), kMagic.size());
    write_le(bytes, 8, fields.version);
    write_le(bytes, 12, fields.maximum_pieces);
    write_le(bytes, 16, fields.dense_states);
    write_le(bytes, 24, fields.legal_states);
    write_le(bytes, 32, fields.wins);
    write_le(bytes, 40, fields.draws);
    write_le(bytes, 48, fields.losses);
    write_le(bytes, 56, fields.payload_checksum);
    return bytes;
}

[[nodiscard]] bool parse_header(
    std::span<const std::uint8_t> bytes,
    HeaderFields& fields,
    std::string* error) {
    auto fail = [error](const char* message) {
        if (error != nullptr) *error = message;
        return false;
    };
    if (bytes.size() < kHeaderBytes) return fail("tablebase header is truncated");
    if (!std::equal(kMagic.begin(), kMagic.end(), bytes.begin())) return fail("invalid ALBTB31 magic");
    fields.version = read_le<std::uint32_t>(bytes, 8);
    fields.maximum_pieces = read_le<std::uint32_t>(bytes, 12);
    fields.dense_states = read_le<std::uint64_t>(bytes, 16);
    fields.legal_states = read_le<std::uint64_t>(bytes, 24);
    fields.wins = read_le<std::uint64_t>(bytes, 32);
    fields.draws = read_le<std::uint64_t>(bytes, 40);
    fields.losses = read_le<std::uint64_t>(bytes, 48);
    fields.payload_checksum = read_le<std::uint64_t>(bytes, 56);
    if (fields.version != kExactTablebaseFormatVersion) return fail("unsupported ALBTB31 version");
    if (fields.maximum_pieces < 1 || fields.maximum_pieces > 6) return fail("invalid ALBTB31 maximum piece count");
    if (fields.dense_states != ExactEndgameTablebase::dense_state_count(static_cast<int>(fields.maximum_pieces))) {
        return fail("ALBTB31 dense state count does not match format");
    }
    return true;
}

[[nodiscard]] EndgameOutcome decode_outcome(std::int8_t raw) noexcept {
    if (raw == static_cast<std::int8_t>(EndgameOutcome::Win)) return EndgameOutcome::Win;
    if (raw == static_cast<std::int8_t>(EndgameOutcome::Loss)) return EndgameOutcome::Loss;
    if (raw == static_cast<std::int8_t>(EndgameOutcome::Draw)) return EndgameOutcome::Draw;
    return EndgameOutcome::Unknown;
}

[[nodiscard]] bool decisive_probe_is_draw_rule_safe(
    const Position& position,
    EndgameOutcome outcome,
    std::uint16_t distance) noexcept {
    if (outcome == EndgameOutcome::Draw) return true;
    if (outcome == EndgameOutcome::Unknown) return false;
    if (position.repetition_count() > 1) return false;
    const int remaining = std::max(0, 30 - static_cast<int>(position.no_progress_plies()));
    return static_cast<int>(distance) <= remaining;
}

}  // namespace

std::uint64_t ExactEndgameTablebase::dense_state_count(int maximum_pieces) noexcept {
    maximum_pieces = std::clamp(maximum_pieces, 1, 6);
    std::uint64_t total = 0;
    for (int pieces = 1; pieces <= maximum_pieces; ++pieces) total += states_for_piece_count(pieces);
    return total;
}

std::optional<std::uint64_t> ExactEndgameTablebase::dense_index(const Position& position) const noexcept {
    if (!loaded()) return std::nullopt;
    return encode_position(position, statistics_.maximum_pieces);
}

bool ExactEndgameTablebase::load(const std::filesystem::path& path, std::string* error) {
    clear();
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        if (error != nullptr) *error = "cannot open tablebase file";
        return false;
    }
    std::array<std::uint8_t, kHeaderBytes> header_bytes{};
    input.read(reinterpret_cast<char*>(header_bytes.data()), static_cast<std::streamsize>(header_bytes.size()));
    HeaderFields fields{};
    if (!input || !parse_header(header_bytes, fields, error)) return false;
    if (fields.dense_states > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        if (error != nullptr) *error = "tablebase is too large for this process";
        return false;
    }

    entries_.resize(static_cast<std::size_t>(fields.dense_states));
    input.read(reinterpret_cast<char*>(entries_.data()), static_cast<std::streamsize>(entries_.size()));
    if (!input) {
        clear();
        if (error != nullptr) *error = "tablebase payload is truncated";
        return false;
    }
    char extra = 0;
    if (input.read(&extra, 1)) {
        clear();
        if (error != nullptr) *error = "tablebase contains unexpected trailing bytes";
        return false;
    }

    std::uint64_t checksum = kFnvOffset;
    checksum = fnv_update(checksum, entries_.data(), entries_.size());
    if (checksum != fields.payload_checksum) {
        clear();
        if (error != nullptr) *error = "tablebase payload checksum mismatch";
        return false;
    }

    path_ = path;
    statistics_.maximum_pieces = static_cast<int>(fields.maximum_pieces);
    statistics_.dense_states = fields.dense_states;
    statistics_.legal_states = fields.legal_states;
    statistics_.wins = fields.wins;
    statistics_.draws = fields.draws;
    statistics_.losses = fields.losses;
    statistics_.payload_checksum = fields.payload_checksum;
    return true;
}

void ExactEndgameTablebase::clear() noexcept {
    path_.clear();
    statistics_ = {};
    entries_.clear();
}

ExactTablebaseVerification ExactEndgameTablebase::verify() const {
    ExactTablebaseVerification report{};
    if (!loaded()) return report;
    for (std::uint64_t index = 0; index < statistics_.dense_states; ++index) {
        DecodedState decoded = decode_state(index, statistics_.maximum_pieces);
        const std::uint8_t entry = entries_[static_cast<std::size_t>(index)];
        const bool stored_valid = entry != kTablebaseInvalidEntry;
        if (decoded.valid != stored_valid) {
            ++report.invalid_state_errors;
            continue;
        }
        if (!decoded.valid) continue;
        ++report.legal_states;
        const EndgameOutcome stored = unpack_outcome(entry);
        MoveList moves;
        if (decoded.position.pieces(decoded.position.side_to_move()) != 0 &&
            decoded.position.pieces(opposite(decoded.position.side_to_move())) != 0) {
            generate_legal_moves(decoded.position, moves);
        }
        EndgameOutcome terminal = EndgameOutcome::Unknown;
        if (decoded.position.pieces(decoded.position.side_to_move()) == 0) terminal = EndgameOutcome::Loss;
        else if (decoded.position.pieces(opposite(decoded.position.side_to_move())) == 0) terminal = EndgameOutcome::Win;
        else if (moves.empty()) terminal = EndgameOutcome::Loss;
        if (terminal != EndgameOutcome::Unknown) {
            if (stored != terminal) ++report.outcome_errors;
            if (unpack_distance(entries_[static_cast<std::size_t>(index)]) != 0) ++report.distance_errors;
            continue;
        }

        bool has_loss_child = false;
        bool has_draw_child = false;
        bool all_win_children = true;
        std::uint16_t minimum_loss_distance = std::numeric_limits<std::uint16_t>::max();
        std::uint16_t maximum_win_distance = 0;
        for (const Move& move : moves) {
            Position child = decoded.position;
            UndoState undo{};
            child.make_move_unchecked(move, undo);
            const auto child_index = encode_position(child, statistics_.maximum_pieces);
            if (!child_index.has_value() || *child_index >= entries_.size()) {
                ++report.invalid_state_errors;
                continue;
            }
            ++report.checked_edges;
            const EndgameOutcome child_outcome = unpack_outcome(entries_[static_cast<std::size_t>(*child_index)]);
            const std::uint16_t child_distance = unpack_distance(entries_[static_cast<std::size_t>(*child_index)]);
            if (child_outcome == EndgameOutcome::Loss) {
                has_loss_child = true;
                all_win_children = false;
                minimum_loss_distance = std::min(minimum_loss_distance, child_distance);
            } else if (child_outcome == EndgameOutcome::Draw) {
                has_draw_child = true;
                all_win_children = false;
            } else if (child_outcome == EndgameOutcome::Win) {
                maximum_win_distance = std::max(maximum_win_distance, child_distance);
            } else {
                all_win_children = false;
                ++report.outcome_errors;
            }
        }

        EndgameOutcome expected = EndgameOutcome::Draw;
        std::uint16_t expected_distance = 0;
        if (has_loss_child) {
            expected = EndgameOutcome::Win;
            expected_distance = static_cast<std::uint16_t>(minimum_loss_distance + 1U);
        } else if (all_win_children) {
            expected = EndgameOutcome::Loss;
            expected_distance = static_cast<std::uint16_t>(maximum_win_distance + 1U);
        } else if (has_draw_child) {
            expected = EndgameOutcome::Draw;
        }
        if (stored != expected) ++report.outcome_errors;
        if (stored != EndgameOutcome::Draw &&
            unpack_distance(entries_[static_cast<std::size_t>(index)]) != expected_distance) {
            ++report.distance_errors;
        }
        const ExactTablebaseProbe probe_result = probe_index(decoded.position, index, true);
        if (probe_result.draw_rule_safe && !moves.empty() && !probe_result.best_move.has_value()) {
            ++report.best_move_errors;
        }
    }
    report.complete = report.legal_states == statistics_.legal_states &&
        report.invalid_state_errors == 0 && report.outcome_errors == 0 &&
        report.distance_errors == 0 && report.best_move_errors == 0;
    return report;
}

ExactTablebaseProbe ExactEndgameTablebase::probe(const Position& position) const {
    const auto index = dense_index(position);
    if (!index.has_value()) return {};
    return probe_index(position, *index, true);
}

ExactTablebaseProbe ExactEndgameTablebase::probe_index(
    const Position& position,
    std::uint64_t index,
    bool include_best_move) const {
    ExactTablebaseProbe result{};
    if (index >= entries_.size()) return result;
    const std::uint8_t entry = entries_[static_cast<std::size_t>(index)];
    if (entry == kTablebaseInvalidEntry) return result;
    result.outcome = unpack_outcome(entry);
    if (result.outcome == EndgameOutcome::Unknown) return result;
    result.distance_to_terminal = unpack_distance(entries_[static_cast<std::size_t>(index)]);
    result.exact = true;
    result.draw_rule_safe = decisive_probe_is_draw_rule_safe(
        position, result.outcome, result.distance_to_terminal);
    if (!include_best_move || !result.draw_rule_safe) return result;

    MoveList moves;
    generate_legal_moves(position, moves);
    if (moves.empty()) return result;

    bool have_choice = false;
    std::uint16_t chosen_distance = result.outcome == EndgameOutcome::Loss ? 0 :
        std::numeric_limits<std::uint16_t>::max();
    for (const Move& move : moves) {
        Position child = position;
        UndoState undo{};
        child.make_move_unchecked(move, undo);
        const auto child_index = encode_position(child, statistics_.maximum_pieces);
        if (!child_index.has_value() || *child_index >= entries_.size()) continue;
        const EndgameOutcome child_outcome = unpack_outcome(entries_[static_cast<std::size_t>(*child_index)]);
        const std::uint16_t child_distance = unpack_distance(entries_[static_cast<std::size_t>(*child_index)]);
        const EndgameOutcome current = child_outcome == EndgameOutcome::Win ? EndgameOutcome::Loss :
            child_outcome == EndgameOutcome::Loss ? EndgameOutcome::Win : child_outcome;
        if (current != result.outcome) continue;

        bool better = !have_choice;
        if (result.outcome == EndgameOutcome::Win) better = better || child_distance < chosen_distance;
        else if (result.outcome == EndgameOutcome::Loss) better = better || child_distance > chosen_distance;
        if (better) {
            result.best_move = move;
            chosen_distance = child_distance;
            have_choice = true;
        }
    }
    return result;
}

ExactTablebaseBuildResult build_exact_tablebase(const ExactTablebaseBuildOptions& options) {
    ExactTablebaseBuildResult result{};
    if (options.maximum_pieces < 1 || options.maximum_pieces > 4) {
        result.error = "in-memory retrograde builder supports 1..4 pieces; 5/6 require external-memory material-class shards";
        return result;
    }
    const int maximum_pieces = options.maximum_pieces;
    if (options.output_path.empty()) {
        result.error = "output path is empty";
        return result;
    }
    const std::uint64_t dense_states = ExactEndgameTablebase::dense_state_count(maximum_pieces);
    if (dense_states > static_cast<std::uint64_t>(std::numeric_limits<std::uint32_t>::max())) {
        result.error = "dense state count exceeds predecessor index format";
        return result;
    }

    const auto enumeration_start = std::chrono::steady_clock::now();
    std::vector<std::uint8_t> valid(static_cast<std::size_t>(dense_states), 0);
    std::vector<std::uint16_t> degree(static_cast<std::size_t>(dense_states), 0);
    std::vector<std::uint32_t> predecessor_count(static_cast<std::size_t>(dense_states), 0);

    std::uint64_t legal_states = 0;
    std::uint64_t edges = 0;
    for (std::uint64_t index = 0; index < dense_states; ++index) {
        DecodedState decoded = decode_state(index, maximum_pieces);
        if (!decoded.valid) continue;
        valid[static_cast<std::size_t>(index)] = 1;
        ++legal_states;
        if (decoded.position.pieces(decoded.position.side_to_move()) == 0 ||
            decoded.position.pieces(opposite(decoded.position.side_to_move())) == 0) {
            continue;
        }
        MoveList moves;
        generate_legal_moves(decoded.position, moves);
        if (moves.size() > std::numeric_limits<std::uint16_t>::max()) {
            result.error = "move degree exceeds tablebase format";
            return result;
        }
        degree[static_cast<std::size_t>(index)] = static_cast<std::uint16_t>(moves.size());
        for (const Move& move : moves) {
            Position child = decoded.position;
            UndoState undo{};
            child.make_move_unchecked(move, undo);
            const auto child_index = encode_position(child, maximum_pieces);
            if (!child_index.has_value()) {
                result.error = "generated successor is outside tablebase index";
                return result;
            }
            ++predecessor_count[static_cast<std::size_t>(*child_index)];
            ++edges;
            if (options.maximum_edges != 0 && edges > options.maximum_edges) {
                result.error = "configured maximum edge count exceeded";
                return result;
            }
        }
    }

    std::vector<std::uint64_t> predecessor_offset(static_cast<std::size_t>(dense_states + 1), 0);
    for (std::uint64_t index = 0; index < dense_states; ++index) {
        predecessor_offset[static_cast<std::size_t>(index + 1)] =
            predecessor_offset[static_cast<std::size_t>(index)] +
            predecessor_count[static_cast<std::size_t>(index)];
    }
    std::vector<std::uint32_t> predecessors(static_cast<std::size_t>(edges));
    std::vector<std::uint64_t> cursor = predecessor_offset;

    for (std::uint64_t index = 0; index < dense_states; ++index) {
        if (valid[static_cast<std::size_t>(index)] == 0 || degree[static_cast<std::size_t>(index)] == 0) continue;
        DecodedState decoded = decode_state(index, maximum_pieces);
        MoveList moves;
        generate_legal_moves(decoded.position, moves);
        for (const Move& move : moves) {
            Position child = decoded.position;
            UndoState undo{};
            child.make_move_unchecked(move, undo);
            const auto child_index = encode_position(child, maximum_pieces);
            const std::uint64_t slot = cursor[static_cast<std::size_t>(*child_index)]++;
            predecessors[static_cast<std::size_t>(slot)] = static_cast<std::uint32_t>(index);
        }
    }
    result.enumeration_seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - enumeration_start).count();

    const auto retrograde_start = std::chrono::steady_clock::now();
    std::vector<std::int8_t> outcomes(static_cast<std::size_t>(dense_states),
        kInternalInvalidOutcome);
    std::vector<std::uint16_t> distances(static_cast<std::size_t>(dense_states), 0);
    std::vector<std::uint16_t> remaining = degree;
    std::vector<std::uint16_t> maximum_winning_child_distance(static_cast<std::size_t>(dense_states), 0);
    std::queue<std::uint32_t> queue;
    std::uint64_t terminal_states = 0;

    for (std::uint64_t index = 0; index < dense_states; ++index) {
        if (valid[static_cast<std::size_t>(index)] == 0) continue;
        outcomes[static_cast<std::size_t>(index)] = static_cast<std::int8_t>(EndgameOutcome::Unknown);
        DecodedState decoded = decode_state(index, maximum_pieces);
        EndgameOutcome terminal = EndgameOutcome::Unknown;
        if (decoded.position.pieces(decoded.position.side_to_move()) == 0) terminal = EndgameOutcome::Loss;
        else if (decoded.position.pieces(opposite(decoded.position.side_to_move())) == 0) terminal = EndgameOutcome::Win;
        else if (degree[static_cast<std::size_t>(index)] == 0) terminal = EndgameOutcome::Loss;
        if (terminal != EndgameOutcome::Unknown) {
            outcomes[static_cast<std::size_t>(index)] = static_cast<std::int8_t>(terminal);
            queue.push(static_cast<std::uint32_t>(index));
            ++terminal_states;
        }
    }

    std::uint64_t updates = 0;
    while (!queue.empty()) {
        const std::uint32_t child = queue.front();
        queue.pop();
        const EndgameOutcome child_outcome = decode_outcome(outcomes[child]);
        const std::uint16_t child_distance = distances[child];
        const std::uint64_t begin = predecessor_offset[child];
        const std::uint64_t end = predecessor_offset[static_cast<std::size_t>(child) + 1U];
        for (std::uint64_t slot = begin; slot < end; ++slot) {
            const std::uint32_t predecessor = predecessors[static_cast<std::size_t>(slot)];
            if (decode_outcome(outcomes[predecessor]) != EndgameOutcome::Unknown) continue;
            if (child_outcome == EndgameOutcome::Loss) {
                outcomes[predecessor] = static_cast<std::int8_t>(EndgameOutcome::Win);
                distances[predecessor] = static_cast<std::uint16_t>(
                    std::min<int>(std::numeric_limits<std::uint16_t>::max(), child_distance + 1));
                queue.push(predecessor);
                ++updates;
            } else if (child_outcome == EndgameOutcome::Win) {
                maximum_winning_child_distance[predecessor] = std::max(
                    maximum_winning_child_distance[predecessor], child_distance);
                if (remaining[predecessor] > 0) --remaining[predecessor];
                if (remaining[predecessor] == 0) {
                    outcomes[predecessor] = static_cast<std::int8_t>(EndgameOutcome::Loss);
                    distances[predecessor] = static_cast<std::uint16_t>(
                        std::min<int>(std::numeric_limits<std::uint16_t>::max(),
                            maximum_winning_child_distance[predecessor] + 1));
                    queue.push(predecessor);
                    ++updates;
                }
            }
        }
    }

    std::uint64_t wins = 0;
    std::uint64_t draws = 0;
    std::uint64_t losses = 0;
    for (std::uint64_t index = 0; index < dense_states; ++index) {
        if (valid[static_cast<std::size_t>(index)] == 0) continue;
        EndgameOutcome outcome = decode_outcome(outcomes[static_cast<std::size_t>(index)]);
        if (outcome == EndgameOutcome::Unknown) {
            outcomes[static_cast<std::size_t>(index)] = static_cast<std::int8_t>(EndgameOutcome::Draw);
            outcome = EndgameOutcome::Draw;
        }
        if (outcome == EndgameOutcome::Win) ++wins;
        else if (outcome == EndgameOutcome::Loss) ++losses;
        else ++draws;
    }
    result.retrograde_seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - retrograde_start).count();

    const auto write_start = std::chrono::steady_clock::now();
    std::vector<std::uint8_t> entries(static_cast<std::size_t>(dense_states), kTablebaseInvalidEntry);
    for (std::size_t index = 0; index < entries.size(); ++index) {
        if (valid[index] == 0) continue;
        entries[index] = pack_entry(decode_outcome(outcomes[index]), distances[index]);
        if (entries[index] == kTablebaseInvalidEntry) {
            result.error = "tablebase distance exceeds packed ALBTB31 v2 range";
            return result;
        }
    }
    std::uint64_t checksum = kFnvOffset;
    checksum = fnv_update(checksum, entries.data(), entries.size());
    HeaderFields fields{};
    fields.maximum_pieces = static_cast<std::uint32_t>(maximum_pieces);
    fields.dense_states = dense_states;
    fields.legal_states = legal_states;
    fields.wins = wins;
    fields.draws = draws;
    fields.losses = losses;
    fields.payload_checksum = checksum;
    const auto header = make_header(fields);

    std::ofstream output(options.output_path, std::ios::binary | std::ios::trunc);
    if (!output) {
        result.error = "cannot create tablebase output";
        return result;
    }
    output.write(reinterpret_cast<const char*>(header.data()), static_cast<std::streamsize>(header.size()));
    output.write(reinterpret_cast<const char*>(entries.data()), static_cast<std::streamsize>(entries.size()));
    output.close();
    if (!output) {
        result.error = "failed while writing tablebase output";
        return result;
    }
    result.write_seconds = std::chrono::duration<double>(
        std::chrono::steady_clock::now() - write_start).count();

    result.statistics.maximum_pieces = maximum_pieces;
    result.statistics.dense_states = dense_states;
    result.statistics.legal_states = legal_states;
    result.statistics.wins = wins;
    result.statistics.draws = draws;
    result.statistics.losses = losses;
    result.statistics.payload_checksum = checksum;
    result.edges = edges;
    result.terminal_states = terminal_states;
    result.retrograde_updates = updates;
    result.complete = true;

    if (options.verify_after_write) {
        ExactEndgameTablebase verification;
        std::string error;
        if (!verification.load(options.output_path, &error)) {
            result.complete = false;
            result.error = "post-write verification failed: " + error;
        }
    }
    return result;
}

}  // namespace albay
