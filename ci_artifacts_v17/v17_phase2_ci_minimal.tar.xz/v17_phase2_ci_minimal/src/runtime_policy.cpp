/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/runtime_policy.hpp"

#include "albay/search.hpp"

#include <algorithm>
#include <cctype>
#include <string>
#include <thread>

namespace albay {
namespace {

[[nodiscard]] std::string lowercase(std::string_view text) {
    std::string result(text);
    std::transform(result.begin(), result.end(), result.begin(), [](unsigned char character) {
        return static_cast<char>(std::tolower(character));
    });
    return result;
}

[[nodiscard]] int profile_cap(PerformanceProfile profile) noexcept {
    switch (profile) {
        case PerformanceProfile::Eco: return 2;
        case PerformanceProfile::Balanced: return 4;
        case PerformanceProfile::Performance: return 6;
        case PerformanceProfile::Analysis: return 8;
        case PerformanceProfile::Manual: return 8;
    }
    return 4;
}

[[nodiscard]] int one_step_down(int threads) noexcept {
    switch (threads) {
        case 8: return 6;
        case 6: return 4;
        case 4: return 3;
        case 3: return 2;
        default: return 1;
    }
}

}  // namespace

int detected_logical_cpu_count() noexcept {
    const unsigned int detected = std::thread::hardware_concurrency();
    return detected == 0U ? 1 : static_cast<int>(std::min(detected, 256U));
}

int normalize_supported_thread_count(int requested) noexcept {
    requested = std::max(requested, 1);
    int selected = 1;
    for (const int supported : kSupportedThreadCounts) {
        if (supported <= requested) {
            selected = supported;
        }
    }
    return selected;
}

ThreadPolicyDecision select_thread_policy(
    PerformanceProfile profile,
    bool automatic,
    int manual_threads,
    const RuntimeEnvironment& environment) noexcept {
    ThreadPolicyDecision decision{};
    decision.profile = profile;
    decision.thermal_status = environment.thermal_status;
    decision.automatic = automatic;
    decision.hardware_threads = std::max(environment.logical_cpu_count, 1);

    if (!automatic || profile == PerformanceProfile::Manual) {
        decision.pool_threads = is_supported_thread_count(manual_threads)
            ? manual_threads
            : normalize_supported_thread_count(manual_threads);
        decision.target_threads = decision.pool_threads;
        return decision;
    }

    const int hardware_cap = normalize_supported_thread_count(decision.hardware_threads);
    decision.pool_threads = normalize_supported_thread_count(
        std::min(hardware_cap, profile_cap(profile)));
    decision.target_threads = decision.pool_threads;

    switch (environment.thermal_status) {
        case ThermalStatus::Light:
            decision.target_threads = one_step_down(decision.target_threads);
            decision.constrained_by_thermal = true;
            break;
        case ThermalStatus::Moderate:
            decision.target_threads = one_step_down(one_step_down(decision.target_threads));
            decision.constrained_by_thermal = true;
            break;
        case ThermalStatus::Severe:
            decision.target_threads = std::min(decision.target_threads, 2);
            decision.constrained_by_thermal = true;
            break;
        case ThermalStatus::Critical:
        case ThermalStatus::Emergency:
        case ThermalStatus::Shutdown:
            decision.target_threads = 1;
            decision.constrained_by_thermal = true;
            break;
        case ThermalStatus::Unknown:
        case ThermalStatus::None:
            break;
    }

    if (environment.power_save_mode && decision.target_threads > 2) {
        decision.target_threads = 2;
        decision.constrained_by_power_saver = true;
    }
    if (environment.app_in_background && decision.target_threads > 1) {
        decision.target_threads = 1;
        decision.constrained_by_background = true;
    }
    decision.target_threads = std::clamp(decision.target_threads, 1, decision.pool_threads);
    return decision;
}

const char* performance_profile_name(PerformanceProfile profile) noexcept {
    switch (profile) {
        case PerformanceProfile::Eco: return "eco";
        case PerformanceProfile::Balanced: return "balanced";
        case PerformanceProfile::Performance: return "performance";
        case PerformanceProfile::Analysis: return "analysis";
        case PerformanceProfile::Manual: return "manual";
    }
    return "balanced";
}

const char* thermal_status_name(ThermalStatus status) noexcept {
    switch (status) {
        case ThermalStatus::Unknown: return "unknown";
        case ThermalStatus::None: return "none";
        case ThermalStatus::Light: return "light";
        case ThermalStatus::Moderate: return "moderate";
        case ThermalStatus::Severe: return "severe";
        case ThermalStatus::Critical: return "critical";
        case ThermalStatus::Emergency: return "emergency";
        case ThermalStatus::Shutdown: return "shutdown";
    }
    return "unknown";
}

bool parse_performance_profile(std::string_view text, PerformanceProfile& profile) noexcept {
    const std::string key = lowercase(text);
    if (key == "eco" || key == "battery") {
        profile = PerformanceProfile::Eco;
    } else if (key == "balanced" || key == "default") {
        profile = PerformanceProfile::Balanced;
    } else if (key == "performance" || key == "fast") {
        profile = PerformanceProfile::Performance;
    } else if (key == "analysis" || key == "maximum" || key == "max") {
        profile = PerformanceProfile::Analysis;
    } else if (key == "manual") {
        profile = PerformanceProfile::Manual;
    } else {
        return false;
    }
    return true;
}

}  // namespace albay
