/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 38 — incremental NNUE and optimized integer kernels.
*/
#include "albay/nnue.hpp"

#include <algorithm>
#include <bit>
#include <cstddef>
#include <cstring>
#include <fstream>
#include <limits>
#include <type_traits>
#include <vector>

#if defined(__aarch64__) && defined(__ARM_NEON)
#include <arm_neon.h>
#endif

namespace albay {
namespace {
constexpr std::array<std::uint8_t, 8> kMagic{{'A','L','B','N','N','3','4','\0'}};
constexpr std::size_t kHeaderBytes = 64;
constexpr std::uint64_t kFnvOffset = 1469598103934665603ULL;
constexpr std::uint64_t kFnvPrime = 1099511628211ULL;
constexpr std::size_t kPayloadBytes =
    kNnueHiddenSize * sizeof(std::int32_t) +
    kNnueInputFeatures * kNnueHiddenSize * sizeof(std::int16_t) +
    kNnueHiddenSize * sizeof(std::int16_t) + sizeof(std::int32_t);

[[nodiscard]] std::size_t perspective_index(Color color) noexcept {
    return color == Color::White ? 0U : 1U;
}

[[nodiscard]] Square canonical_square(Square square, Color perspective) noexcept {
    return perspective == Color::White
        ? square
        : static_cast<Square>(kBoardSquares - 1 - square);
}

[[nodiscard]] std::uint16_t feature_index(
    Color piece_color,
    bool king,
    Square square,
    Color perspective) noexcept {
    const bool own = piece_color == perspective;
    const std::uint16_t plane = static_cast<std::uint16_t>(
        own ? (king ? 1 : 0) : (king ? 3 : 2));
    return static_cast<std::uint16_t>(
        plane * kBoardSquares + canonical_square(square, perspective));
}

void set_feature(NnueFeatureMask& mask, std::uint16_t feature) noexcept {
    mask.words[feature / 64U] |= std::uint64_t{1} << (feature % 64U);
}

void clear_feature(NnueFeatureMask& mask, std::uint16_t feature) noexcept {
    mask.words[feature / 64U] &= ~(std::uint64_t{1} << (feature % 64U));
}

template <typename T>
void append_le(std::vector<std::uint8_t>& bytes, T value) {
    using U = std::make_unsigned_t<T>;
    U raw = static_cast<U>(value);
    for (std::size_t index = 0; index < sizeof(T); ++index) {
        bytes.push_back(static_cast<std::uint8_t>((raw >> (index * 8U)) & 0xFFU));
    }
}

template <typename T>
[[nodiscard]] T read_le(const std::vector<std::uint8_t>& bytes, std::size_t offset) noexcept {
    using U = std::make_unsigned_t<T>;
    std::uint64_t raw = 0;
    for (std::size_t index = 0; index < sizeof(T); ++index) {
        raw |= static_cast<std::uint64_t>(bytes[offset + index]) << (index * 8U);
    }
    return static_cast<T>(static_cast<U>(raw));
}

[[nodiscard]] std::uint64_t fnv1a(const std::uint8_t* data, std::size_t size) noexcept {
    std::uint64_t hash = kFnvOffset;
    for (std::size_t index = 0; index < size; ++index) {
        hash ^= data[index];
        hash *= kFnvPrime;
    }
    return hash;
}

[[nodiscard]] std::vector<std::uint8_t> serialize_payload(const NnueModel& model) {
    std::vector<std::uint8_t> payload;
    payload.reserve(kPayloadBytes);
    for (const auto value : model.hidden_bias()) append_le(payload, value);
    for (const auto value : model.input_weights()) append_le(payload, value);
    for (const auto value : model.output_weights()) append_le(payload, value);
    append_le(payload, model.output_bias());
    return payload;
}

[[nodiscard]] bool fail(std::string* error, std::string message) {
    if (error != nullptr) *error = std::move(message);
    return false;
}

void add_feature(
    std::array<std::int32_t, kNnueHiddenSize>& accumulator,
    const NnueModel& model,
    std::uint16_t feature,
    int sign) noexcept {
    const std::size_t base = static_cast<std::size_t>(feature) * kNnueHiddenSize;
#if defined(__aarch64__) && defined(__ARM_NEON)
    const auto* weights = model.input_weights().data() + base;
    for (std::size_t hidden = 0; hidden < kNnueHiddenSize; hidden += 8) {
        const int16x8_t packed = vld1q_s16(weights + hidden);
        const int32x4_t low = vmovl_s16(vget_low_s16(packed));
        const int32x4_t high = vmovl_s16(vget_high_s16(packed));
        int32x4_t accumulator_low = vld1q_s32(accumulator.data() + hidden);
        int32x4_t accumulator_high = vld1q_s32(accumulator.data() + hidden + 4);
        accumulator_low = sign > 0
            ? vaddq_s32(accumulator_low, low)
            : vsubq_s32(accumulator_low, low);
        accumulator_high = sign > 0
            ? vaddq_s32(accumulator_high, high)
            : vsubq_s32(accumulator_high, high);
        vst1q_s32(accumulator.data() + hidden, accumulator_low);
        vst1q_s32(accumulator.data() + hidden + 4, accumulator_high);
    }
#else
    for (std::size_t hidden = 0; hidden < kNnueHiddenSize; ++hidden) {
        accumulator[hidden] += sign * model.input_weights()[base + hidden];
    }
#endif
}

[[maybe_unused, nodiscard]] std::int64_t accumulator_dot_scalar(
    const std::array<std::int32_t, kNnueHiddenSize>& accumulator,
    const NnueModel& model) noexcept {
    std::int64_t sum = model.output_bias();
    for (std::size_t hidden = 0; hidden < kNnueHiddenSize; ++hidden) {
        const std::int32_t activated = std::clamp<std::int32_t>(
            accumulator[hidden], 0, model.metadata().activation_max);
        sum += static_cast<std::int64_t>(activated) * model.output_weights()[hidden];
    }
    return sum;
}

#if defined(__aarch64__) && defined(__ARM_NEON)
[[nodiscard]] std::int64_t accumulator_dot_neon(
    const std::array<std::int32_t, kNnueHiddenSize>& accumulator,
    const NnueModel& model) noexcept {
    int64x2_t total = vdupq_n_s64(0);
    const auto* weights = model.output_weights().data();
    for (std::size_t hidden = 0; hidden < kNnueHiddenSize; hidden += 8) {
        const int32x4_t a0 = vld1q_s32(accumulator.data() + hidden);
        const int32x4_t a1 = vld1q_s32(accumulator.data() + hidden + 4);
        const int32x4_t zero = vdupq_n_s32(0);
        const int32x4_t maximum = vdupq_n_s32(model.metadata().activation_max);
        const int16x4_t x0 = vmovn_s32(vminq_s32(vmaxq_s32(a0, zero), maximum));
        const int16x4_t x1 = vmovn_s32(vminq_s32(vmaxq_s32(a1, zero), maximum));
        const int16x8_t x = vcombine_s16(x0, x1);
        const int16x8_t w = vld1q_s16(weights + hidden);
        const int32x4_t products0 = vmull_s16(vget_low_s16(x), vget_low_s16(w));
        const int32x4_t products1 = vmull_s16(vget_high_s16(x), vget_high_s16(w));
        total = vaddq_s64(total, vpaddlq_s32(products0));
        total = vaddq_s64(total, vpaddlq_s32(products1));
    }
    return model.output_bias() + vaddvq_s64(total);
}
#endif

[[nodiscard]] Score accumulator_score(
    const std::array<std::int32_t, kNnueHiddenSize>& accumulator,
    const NnueModel& model) noexcept {
#if defined(__aarch64__) && defined(__ARM_NEON)
    const std::int64_t sum = accumulator_dot_neon(accumulator, model);
#else
    const std::int64_t sum = accumulator_dot_scalar(accumulator, model);
#endif
    const std::int64_t scaled = sum / model.metadata().output_scale;
    return static_cast<Score>(std::clamp<std::int64_t>(
        scaled, -kMateThreshold + 1, kMateThreshold - 1));
}

}  // namespace

NnueKernel nnue_active_kernel() noexcept {
#if defined(__aarch64__) && defined(__ARM_NEON)
    return NnueKernel::ArmNeon;
#else
    return NnueKernel::Scalar;
#endif
}

const char* nnue_kernel_name(NnueKernel kernel) noexcept {
    switch (kernel) {
        case NnueKernel::ArmNeon: return "arm64-neon";
        case NnueKernel::Scalar: default: return "scalar";
    }
}

NnueFeatureMask nnue_feature_mask(const Position& position, Color perspective) noexcept {
    NnueFeatureMask result{};
    const Bitboard kings = position.kings();
    for (const Color color : {Color::White, Color::Black}) {
        Bitboard pieces = position.pieces(color);
        while (pieces != 0) {
            const Square square = static_cast<Square>(std::countr_zero(pieces));
            pieces &= pieces - 1U;
            set_feature(result, feature_index(color, (kings & bit(square)) != 0, square, perspective));
        }
    }
    return result;
}

NnueFeatureList nnue_active_features(const Position& position, Color perspective) noexcept {
    NnueFeatureList result{};
    const NnueFeatureMask mask = nnue_feature_mask(position, perspective);
    for (std::size_t word_index = 0; word_index < mask.words.size(); ++word_index) {
        std::uint64_t word = mask.words[word_index];
        while (word != 0) {
            const int bit_index = std::countr_zero(word);
            if (result.count < result.indices.size()) {
                result.indices[result.count++] = static_cast<std::uint16_t>(word_index * 64U + static_cast<std::size_t>(bit_index));
            }
            word &= word - 1U;
        }
    }
    return result;
}

NnueFeatureDelta nnue_move_delta(
    Color mover,
    Bitboard parent_kings,
    const Move& move) noexcept {
    NnueFeatureDelta result{};
    if (!is_valid_square(move.from) || !is_valid_square(move.to)) {
        return result;
    }
    const Color captured_color = opposite(mover);
    const bool moving_king = (parent_kings & bit(move.from)) != 0 ||
        move.moving_piece_was_king();
    const bool resulting_king = moving_king || move.is_promotion();
    for (const Color perspective : {Color::White, Color::Black}) {
        const std::size_t index = perspective_index(perspective);
        auto& delta = result.perspectives[index];
        delta.removed[delta.removed_count++] = feature_index(
            mover, moving_king, move.from, perspective);
        for (std::uint8_t capture = 0; capture < move.capture_count; ++capture) {
            const Square square = move.captures[capture];
            if (!is_valid_square(square)) continue;
            delta.removed[delta.removed_count++] = feature_index(
                captured_color, (parent_kings & bit(square)) != 0, square, perspective);
        }
        delta.added[delta.added_count++] = feature_index(
            mover, resulting_king, move.to, perspective);
    }
    return result;
}

NnueFeatureDelta nnue_move_delta(
    const Position& before,
    const Move& move) noexcept {
    return nnue_move_delta(before.side_to_move(), before.kings(), move);
}

NnueModel NnueModel::zero_model() {
    NnueModel model;
    model.metadata_.payload_checksum = model.payload_checksum();
    return model;
}

NnueModel NnueModel::deterministic_fixture(std::uint64_t seed) {
    NnueModel model;
    auto next = [&seed]() noexcept {
        seed ^= seed >> 12U;
        seed ^= seed << 25U;
        seed ^= seed >> 27U;
        return seed * 2685821657736338717ULL;
    };
    for (auto& value : model.hidden_bias_) {
        value = static_cast<std::int32_t>(next() % 33U) - 16;
    }
    for (auto& value : model.input_weights_) {
        value = static_cast<std::int16_t>(static_cast<int>(next() % 9U) - 4);
    }
    for (auto& value : model.output_weights_) {
        value = static_cast<std::int16_t>(static_cast<int>(next() % 17U) - 8);
    }
    model.output_bias_ = static_cast<std::int32_t>(next() % 129U) - 64;
    model.metadata_.payload_checksum = model.payload_checksum();
    return model;
}

NnueModel NnueModel::from_parameters(
    const std::array<std::int32_t, kNnueHiddenSize>& hidden_bias,
    const std::array<std::int16_t, kNnueInputFeatures * kNnueHiddenSize>& input_weights,
    const std::array<std::int16_t, kNnueHiddenSize>& output_weights,
    std::int32_t output_bias) {
    NnueModel model;
    model.hidden_bias_ = hidden_bias;
    model.input_weights_ = input_weights;
    model.output_weights_ = output_weights;
    model.output_bias_ = output_bias;
    model.metadata_.payload_checksum = model.payload_checksum();
    return model;
}

std::uint64_t NnueModel::payload_checksum() const {
    const auto payload = serialize_payload(*this);
    return fnv1a(payload.data(), payload.size());
}

bool NnueModel::validate(std::string* error) const {
    if (metadata_.format_version != kNnueFormatVersion) return fail(error, "NNUE format version mismatch");
    if (metadata_.input_features != kNnueInputFeatures) return fail(error, "NNUE input feature count mismatch");
    if (metadata_.hidden_size != kNnueHiddenSize) return fail(error, "NNUE hidden size mismatch");
    if (metadata_.feature_schema != kNnueFeatureSchema) return fail(error, "NNUE feature schema mismatch");
    if (metadata_.activation_max != kNnueActivationMax ||
        metadata_.output_scale != kNnueOutputScale) {
        return fail(error, "NNUE scaling metadata mismatch");
    }
    if (metadata_.payload_checksum != payload_checksum()) return fail(error, "NNUE payload checksum mismatch");
    return true;
}

bool NnueModel::save(const std::filesystem::path& path, std::string* error) const {
    NnueModel copy = *this;
    copy.metadata_.payload_checksum = copy.payload_checksum();
    if (!copy.validate(error)) return false;
    const auto payload = serialize_payload(copy);
    std::vector<std::uint8_t> bytes;
    bytes.reserve(kHeaderBytes + payload.size());
    bytes.insert(bytes.end(), kMagic.begin(), kMagic.end());
    append_le(bytes, copy.metadata_.format_version);
    append_le(bytes, copy.metadata_.input_features);
    append_le(bytes, copy.metadata_.hidden_size);
    append_le(bytes, copy.metadata_.activation_max);
    append_le(bytes, copy.metadata_.output_scale);
    append_le(bytes, static_cast<std::uint32_t>(kHeaderBytes));
    append_le(bytes, static_cast<std::uint64_t>(payload.size()));
    append_le(bytes, copy.metadata_.payload_checksum);
    append_le(bytes, copy.metadata_.feature_schema);
    append_le(bytes, std::uint64_t{0});
    bytes.insert(bytes.end(), payload.begin(), payload.end());

    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return fail(error, "cannot open NNUE model for writing");
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!output) return fail(error, "failed to write NNUE model");
    return true;
}

bool NnueModel::load(const std::filesystem::path& path, std::string* error) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return fail(error, "cannot open NNUE model");
    std::vector<std::uint8_t> bytes(
        (std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    if (bytes.size() != kHeaderBytes + kPayloadBytes) return fail(error, "NNUE model size mismatch");
    if (!std::equal(kMagic.begin(), kMagic.end(), bytes.begin())) return fail(error, "NNUE magic mismatch");

    NnueModel loaded;
    loaded.metadata_.format_version = read_le<std::uint32_t>(bytes, 8);
    loaded.metadata_.input_features = read_le<std::uint32_t>(bytes, 12);
    loaded.metadata_.hidden_size = read_le<std::uint32_t>(bytes, 16);
    loaded.metadata_.activation_max = read_le<std::int32_t>(bytes, 20);
    loaded.metadata_.output_scale = read_le<std::int32_t>(bytes, 24);
    const auto header_bytes = read_le<std::uint32_t>(bytes, 28);
    const auto payload_bytes = read_le<std::uint64_t>(bytes, 32);
    loaded.metadata_.payload_checksum = read_le<std::uint64_t>(bytes, 40);
    loaded.metadata_.feature_schema = read_le<std::uint64_t>(bytes, 48);
    if (header_bytes != kHeaderBytes || payload_bytes != kPayloadBytes) return fail(error, "NNUE layout mismatch");

    std::size_t offset = kHeaderBytes;
    for (auto& value : loaded.hidden_bias_) { value = read_le<std::int32_t>(bytes, offset); offset += sizeof(value); }
    for (auto& value : loaded.input_weights_) { value = read_le<std::int16_t>(bytes, offset); offset += sizeof(value); }
    for (auto& value : loaded.output_weights_) { value = read_le<std::int16_t>(bytes, offset); offset += sizeof(value); }
    loaded.output_bias_ = read_le<std::int32_t>(bytes, offset);
    if (!loaded.validate(error)) return false;
    *this = std::move(loaded);
    return true;
}

void NnueAccumulator::refresh(const Position& position, const NnueModel& model) noexcept {
    model_checksum_ = model.metadata().payload_checksum;
    for (const Color perspective : {Color::White, Color::Black}) {
        const std::size_t index = perspective_index(perspective);
        accumulators_[index] = model.hidden_bias();
        masks_[index] = nnue_feature_mask(position, perspective);
        for (std::size_t word_index = 0; word_index < 2; ++word_index) {
            std::uint64_t word = masks_[index].words[word_index];
            while (word != 0) {
                const int bit_index = std::countr_zero(word);
                add_feature(accumulators_[index], model,
                    static_cast<std::uint16_t>(word_index * 64U + static_cast<std::size_t>(bit_index)), 1);
                word &= word - 1U;
            }
        }
    }
    initialized_ = true;
}

void NnueAccumulator::update(
    const Position& before,
    const Position& after,
    const NnueModel& model) noexcept {
    if (!valid_for(before, model)) {
        refresh(after, model);
        return;
    }
    update_to(after, model);
}

void NnueAccumulator::update_to(
    const Position& after,
    const NnueModel& model) noexcept {
    if (!initialized_ || model_checksum_ != model.metadata().payload_checksum) {
        refresh(after, model);
        return;
    }
    for (const Color perspective : {Color::White, Color::Black}) {
        const std::size_t index = perspective_index(perspective);
        const NnueFeatureMask next = nnue_feature_mask(after, perspective);
        for (std::size_t word_index = 0; word_index < 2; ++word_index) {
            std::uint64_t removed = masks_[index].words[word_index] & ~next.words[word_index];
            std::uint64_t added = next.words[word_index] & ~masks_[index].words[word_index];
            while (removed != 0) {
                const int bit_index = std::countr_zero(removed);
                add_feature(accumulators_[index], model,
                    static_cast<std::uint16_t>(word_index * 64U + static_cast<std::size_t>(bit_index)), -1);
                removed &= removed - 1U;
            }
            while (added != 0) {
                const int bit_index = std::countr_zero(added);
                add_feature(accumulators_[index], model,
                    static_cast<std::uint16_t>(word_index * 64U + static_cast<std::size_t>(bit_index)), 1);
                added &= added - 1U;
            }
        }
        masks_[index] = next;
    }
}

void NnueAccumulator::apply_delta(
    const NnueFeatureDelta& delta,
    const NnueModel& model) noexcept {
    if (!initialized_ || model_checksum_ != model.metadata().payload_checksum) {
        initialized_ = false;
        return;
    }
    for (std::size_t perspective = 0; perspective < delta.perspectives.size(); ++perspective) {
        const auto& change = delta.perspectives[perspective];
        for (std::uint8_t index = 0; index < change.removed_count; ++index) {
            const std::uint16_t feature = change.removed[index];
            add_feature(accumulators_[perspective], model, feature, -1);
            clear_feature(masks_[perspective], feature);
        }
        for (std::uint8_t index = 0; index < change.added_count; ++index) {
            const std::uint16_t feature = change.added[index];
            add_feature(accumulators_[perspective], model, feature, 1);
            set_feature(masks_[perspective], feature);
        }
    }
}

bool NnueAccumulator::valid_for(const Position& position, const NnueModel& model) const noexcept {
    return initialized_ && model_checksum_ == model.metadata().payload_checksum &&
        masks_[0] == nnue_feature_mask(position, Color::White) &&
        masks_[1] == nnue_feature_mask(position, Color::Black);
}

Score NnueAccumulator::evaluate(const Position& position, const NnueModel& model) const noexcept {
    if (!valid_for(position, model)) {
        NnueAccumulator refreshed;
        refreshed.refresh(position, model);
        return refreshed.evaluate(position, model);
    }
    return accumulator_score(accumulators_[perspective_index(position.side_to_move())], model);
}

Score NnueAccumulator::evaluate_assuming_valid(
    const Position& position, const NnueModel& model) const noexcept {
    if (!initialized_ || model_checksum_ != model.metadata().payload_checksum) {
        return evaluate(position, model);
    }
    return accumulator_score(accumulators_[perspective_index(position.side_to_move())], model);
}

const std::array<std::int32_t, kNnueHiddenSize>& NnueAccumulator::values(Color perspective) const noexcept {
    return accumulators_[perspective_index(perspective)];
}

Score evaluate_nnue(const Position& position, const NnueModel& model) noexcept {
    NnueAccumulator accumulator;
    accumulator.refresh(position, model);
    return accumulator.evaluate(position, model);
}

}  // namespace albay
