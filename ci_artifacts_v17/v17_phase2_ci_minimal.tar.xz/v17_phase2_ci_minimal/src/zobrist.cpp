/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/zobrist.hpp"

// The constexpr Zobrist table is defined inline in the public header so hot
// make/unmake code can access it without an out-of-line function call.
