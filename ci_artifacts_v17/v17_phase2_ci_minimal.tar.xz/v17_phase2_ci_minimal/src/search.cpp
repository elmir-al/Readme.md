/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/search.hpp"

#include "albay/movegen.hpp"
#include "albay/geometry.hpp"
#include "albay/quiet_ranking.hpp"
#include "albay/strategic_ordering.hpp"

#include <algorithm>
#include <bit>
#include <cmath>
#include <filesystem>
#include <limits>
#include <memory>
#include <stdexcept>
#include <thread>
#include <utility>

namespace albay {
namespace {

[[nodiscard]] bool uses_default_evaluation(const EvaluationWeights& weights) noexcept {
    const EvaluationWeights defaults{};
    return weights.material == defaults.material &&
        weights.center == defaults.center &&
        weights.advancement == defaults.advancement &&
        weights.promotion_potential == defaults.promotion_potential &&
        weights.back_rank == defaults.back_rank &&
        weights.mobility == defaults.mobility &&
        weights.king_activity == defaults.king_activity &&
        weights.restriction == defaults.restriction &&
        weights.tactical_pressure == defaults.tactical_pressure &&
        weights.phase_adjustment == defaults.phase_adjustment &&
        weights.structure == defaults.structure &&
        weights.support_structure == defaults.support_structure &&
        weights.isolation == defaults.isolation &&
        weights.promotion_lanes == defaults.promotion_lanes &&
        weights.edge_passivity == defaults.edge_passivity &&
        weights.phase_adjustment_repeat == defaults.phase_adjustment_repeat &&
        weights.opening_center_scale == defaults.opening_center_scale &&
        weights.opening_back_rank_scale == defaults.opening_back_rank_scale &&
        weights.middlegame_structure_scale == defaults.middlegame_structure_scale &&
        weights.endgame_king_scale == defaults.endgame_king_scale &&
        weights.endgame_mobility_scale == defaults.endgame_mobility_scale &&
        weights.endgame_restriction_scale == defaults.endgame_restriction_scale &&
        weights.endgame_promotion_scale == defaults.endgame_promotion_scale &&
        weights.king_confinement == defaults.king_confinement &&
        weights.promotion_race == defaults.promotion_race &&
        weights.wing_balance == defaults.wing_balance &&
        weights.rear_support == defaults.rear_support &&
        weights.advanced_exposure == defaults.advanced_exposure &&
        weights.diagonal_control == defaults.diagonal_control &&
        weights.reserve_tempo == defaults.reserve_tempo &&
        weights.space_pressure == defaults.space_pressure &&
        weights.strategic_pst == defaults.strategic_pst &&
        weights.strategic_min_pieces == defaults.strategic_min_pieces &&
        weights.strategic_max_pieces == defaults.strategic_max_pieces &&
        weights.strategic_max_kings == defaults.strategic_max_kings;
}

[[nodiscard]] bool uses_default_move_ordering(const SearchOptions& options) noexcept {
    return options.use_capture_history &&
        !options.use_capture_signature_history &&
        !options.use_capture_continuation_history &&
        !options.use_recapture_ordering &&
        options.use_countermove &&
        options.use_continuation_history &&
        options.use_followup_history &&
        options.followup_history_weight == 15 &&
        !options.use_piece_type_history &&
        !options.use_promotion_threat_ordering &&
        !options.use_positional_quiet_ordering &&
        !options.use_strategic_quiet_ordering &&
        !options.use_endgame_reply_ordering;
}

[[nodiscard]] constexpr int absolute_int(int value) noexcept {
    return value < 0 ? -value : value;
}

[[nodiscard]] consteval auto make_capture_landing_center_bonus() noexcept {
    std::array<int, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        const BoardCoordinate landing = coordinate_of(static_cast<Square>(square));
        const int center_distance =
            absolute_int(landing.file - 3) + absolute_int(landing.rank - 3);
        result[static_cast<std::size_t>(square)] = std::max(0, 8 - center_distance) * 32;
    }
    return result;
}

inline constexpr auto kCaptureLandingCenterBonus = make_capture_landing_center_bonus();

[[nodiscard]] std::size_t color_index(Color color) noexcept {
    return color == Color::White ? 0U : 1U;
}

[[nodiscard]] std::size_t moving_piece_type_index(const Move& move) noexcept {
    return move.moving_piece_was_king() ? 1U : 0U;
}

[[nodiscard]] bool creates_immediate_promotion_threat(
    const Position& position, const Move& move) noexcept {
    if (move.is_capture() || move.is_promotion() || move.moving_piece_was_king() ||
        !is_valid_square(move.from) || !is_valid_square(move.to)) {
        return false;
    }
    const Color mover = position.side_to_move();
    const int target_rank = coordinate_of(move.to).rank;
    if ((mover == Color::White && target_rank != 6) ||
        (mover == Color::Black && target_rank != 1)) {
        return false;
    }
    const Bitboard occupied_after =
        (position.occupied() & ~bit(move.from)) | bit(move.to);
    const std::size_t first_direction = mover == Color::White ? 2U : 0U;
    for (std::size_t offset = 0; offset < 2; ++offset) {
        const Bitboard destination =
            kDiagonalStepBitTable[static_cast<std::size_t>(move.to)]
                [first_direction + offset];
        if (destination != 0 && (occupied_after & destination) == 0) {
            return true;
        }
    }
    return false;
}

[[nodiscard]] constexpr HashKey mix_counter_value(std::uint16_t counter) noexcept {
    HashKey value = static_cast<HashKey>(counter) + 0x9E3779B97F4A7C15ULL;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

[[nodiscard]] constexpr HashKey mix_hash_value(HashKey value) noexcept {
    value += 0x9E3779B97F4A7C15ULL;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

[[nodiscard]] consteval auto make_counter_mix_table() noexcept {
    std::array<HashKey, 31> result{};
    for (std::size_t index = 0; index < result.size(); ++index) {
        result[index] = mix_counter_value(static_cast<std::uint16_t>(index));
    }
    return result;
}

inline constexpr auto kCounterMixTable = make_counter_mix_table();

[[nodiscard]] constexpr HashKey mix_counter(std::uint16_t counter) noexcept {
    return counter < kCounterMixTable.size()
        ? kCounterMixTable[counter]
        : mix_counter_value(counter);
}

inline constexpr std::uint64_t kControlCheckInterval = 128;
inline constexpr std::uint64_t kNodePublishInterval = 256;
inline constexpr int kHistoryLimit = 16'384;

void update_history_value(int& value, int bonus) noexcept {
    bonus = std::clamp(bonus, -2'048, 2'048);
    value += bonus - (value * std::abs(bonus)) / kHistoryLimit;
    value = std::clamp(value, -kHistoryLimit, kHistoryLimit);
}

}  // namespace

Searcher::Searcher()
    : transposition_table_(std::make_shared<TranspositionTable>(32)) {}

Searcher::Searcher(std::shared_ptr<TranspositionTable> shared_table, bool helper_instance)
    : transposition_table_(std::move(shared_table)), helper_instance_(helper_instance) {}

Searcher::~Searcher() {
    stop();
    resume();
}

SearchResult Searcher::search(
    const Position& root,
    const SearchLimits& limits,
    const SearchOptions& options,
    SearchInfoCallback callback,
    std::stop_token external_stop_token,
    const std::atomic<bool>* external_pause_requested) {
    stop_requested_.store(false, std::memory_order_release);
    pause_requested_.store(false, std::memory_order_release);
    paused_active_.store(false, std::memory_order_release);
    bool session_expected = false;
    if (!session_active_.compare_exchange_strong(
            session_expected, true, std::memory_order_acq_rel)) {
        throw std::logic_error("Albay Searcher is already searching");
    }
    struct SessionGuard {
        Searcher& searcher;
        ~SessionGuard() { searcher.session_active_.store(false, std::memory_order_release); }
    } session_guard{*this};

    SearchOptions normalized = options;
    normalized.aspiration_window = std::clamp(normalized.aspiration_window, 8, 5000);
    normalized.aspiration_min_depth = std::clamp(normalized.aspiration_min_depth, 1, kMaxSearchDepth);
    normalized.aspiration_growth_percent = std::clamp(normalized.aspiration_growth_percent, 125, 400);
    normalized.aspiration_side_bias_percent = std::clamp(normalized.aspiration_side_bias_percent, 0, 100);
    normalized.aspiration_volatility_scale_percent = std::clamp(
        normalized.aspiration_volatility_scale_percent, 0, 500);
    normalized.aspiration_max_window = std::clamp(
        normalized.aspiration_max_window, normalized.aspiration_window, 5000);
    normalized.lmr_min_depth = std::clamp(normalized.lmr_min_depth, 2, 20);
    normalized.lmr_move_threshold = std::clamp(normalized.lmr_move_threshold, 1, 32);
    normalized.lmr_history_threshold = std::clamp(normalized.lmr_history_threshold, -kHistoryLimit, kHistoryLimit);
    normalized.lmr_deep_depth = std::clamp(normalized.lmr_deep_depth, normalized.lmr_min_depth, 32);
    normalized.lmr_deep_move_threshold = std::clamp(normalized.lmr_deep_move_threshold, normalized.lmr_move_threshold, 48);
    normalized.lmr_deep_history_threshold = std::clamp(normalized.lmr_deep_history_threshold, -kHistoryLimit, kHistoryLimit);
    normalized.lmr_max_reduction = std::clamp(normalized.lmr_max_reduction, 1, 3);
    normalized.lmr_phase_min_pieces = std::clamp(normalized.lmr_phase_min_pieces, 0, 24);
    normalized.lmr_phase_max_pieces = std::clamp(
        normalized.lmr_phase_max_pieces, normalized.lmr_phase_min_pieces, 24);
    normalized.lmr_phase_max_kings = std::clamp(normalized.lmr_phase_max_kings, 0, 24);
    normalized.lmr_phase_min_depth = std::clamp(normalized.lmr_phase_min_depth, 2, 12);
    normalized.lmr_phase_move_threshold = std::clamp(normalized.lmr_phase_move_threshold, 1, 32);
    normalized.lmr_protected_history_threshold = std::clamp(
        normalized.lmr_protected_history_threshold, -kHistoryLimit, kHistoryLimit);
    normalized.lmr_negative_history_threshold = std::clamp(
        normalized.lmr_negative_history_threshold, -kHistoryLimit, kHistoryLimit);
    normalized.lmr_phase_deep_depth = std::clamp(
        normalized.lmr_phase_deep_depth, normalized.lmr_phase_min_depth, 24);
    normalized.lmr_phase_deep_move_threshold = std::clamp(
        normalized.lmr_phase_deep_move_threshold, normalized.lmr_phase_move_threshold, 48);
    normalized.razor_max_depth = std::clamp(normalized.razor_max_depth, 1, 3);
    normalized.razor_margin_base = std::clamp(normalized.razor_margin_base, 0, 1000);
    normalized.razor_margin_per_depth = std::clamp(normalized.razor_margin_per_depth, 0, 1000);
    normalized.razor_min_pieces = std::clamp(normalized.razor_min_pieces, 0, 24);
    normalized.razor_max_pieces = std::clamp(
        normalized.razor_max_pieces, normalized.razor_min_pieces, 24);
    normalized.razor_max_time_ms = std::clamp(normalized.razor_max_time_ms, 0, 60'000);
    normalized.futility_max_depth = std::clamp(normalized.futility_max_depth, 1, 3);
    normalized.futility_margin_base = std::clamp(normalized.futility_margin_base, 0, 1000);
    normalized.futility_margin_per_depth = std::clamp(normalized.futility_margin_per_depth, 0, 1000);
    normalized.futility_min_pieces = std::clamp(normalized.futility_min_pieces, 0, 24);
    normalized.futility_max_pieces = std::clamp(
        normalized.futility_max_pieces, normalized.futility_min_pieces, 24);
    normalized.late_move_pruning_max_depth = std::clamp(normalized.late_move_pruning_max_depth, 1, 4);
    normalized.late_move_pruning_base_moves = std::clamp(normalized.late_move_pruning_base_moves, 2, 32);
    normalized.late_move_pruning_history_threshold = std::clamp(
        normalized.late_move_pruning_history_threshold, -kHistoryLimit, kHistoryLimit);
    normalized.late_move_pruning_min_pieces = std::clamp(
        normalized.late_move_pruning_min_pieces, 0, 24);
    normalized.late_move_pruning_max_pieces = std::clamp(
        normalized.late_move_pruning_max_pieces, normalized.late_move_pruning_min_pieces, 24);
    normalized.history_pruning_max_depth = std::clamp(normalized.history_pruning_max_depth, 1, 4);
    normalized.history_pruning_move_threshold = std::clamp(normalized.history_pruning_move_threshold, 2, 32);
    normalized.history_pruning_threshold = std::clamp(
        normalized.history_pruning_threshold, -kHistoryLimit, kHistoryLimit);
    normalized.history_pruning_min_pieces = std::clamp(normalized.history_pruning_min_pieces, 0, 24);
    normalized.history_pruning_max_pieces = std::clamp(
        normalized.history_pruning_max_pieces, normalized.history_pruning_min_pieces, 24);
    normalized.iir_min_depth = std::clamp(normalized.iir_min_depth, 4, 20);
    normalized.iir_reduction = std::clamp(normalized.iir_reduction, 1, 2);
    normalized.iir_max_pieces = std::clamp(normalized.iir_max_pieces, 0, 24);
    normalized.capture_continuation_weight = std::clamp(normalized.capture_continuation_weight, 0, 300);
    normalized.recapture_order_bonus = std::clamp(normalized.recapture_order_bonus, 0, 200'000);
    normalized.recapture_extension_max_depth = std::clamp(normalized.recapture_extension_max_depth, 1, 16);
    normalized.forced_line_extension_max_depth = std::clamp(normalized.forced_line_extension_max_depth, 1, 24);
    normalized.quiet_sacrifice_extension_max_depth = std::clamp(
        normalized.quiet_sacrifice_extension_max_depth, 1, 16);
    normalized.endgame_reply_order_max_pieces = std::clamp(
        normalized.endgame_reply_order_max_pieces, 2, 12);
    normalized.endgame_reply_order_weight = std::clamp(
        normalized.endgame_reply_order_weight, 0, 400);
    normalized.endgame_lmr_guard_reply_threshold = std::clamp(
        normalized.endgame_lmr_guard_reply_threshold, 1, 8);
    normalized.tactical_max_extensions = std::clamp(normalized.tactical_max_extensions, 0, 8);
    normalized.promotion_extension_max_depth = std::clamp(normalized.promotion_extension_max_depth, 0, 16);
    normalized.promotion_extension_extra_max_pieces = std::clamp(normalized.promotion_extension_extra_max_pieces, 0, 24);
    normalized.promotion_extension_extra_max_kings = std::clamp(normalized.promotion_extension_extra_max_kings, 0, 24);
    normalized.single_reply_extension_max_depth = std::clamp(normalized.single_reply_extension_max_depth, 0, 16);
    normalized.quiescence_promotion_max_extensions = std::clamp(normalized.quiescence_promotion_max_extensions, 0, 4);
    normalized.tt_age_penalty_per_generation =
        std::clamp(normalized.tt_age_penalty_per_generation, 1, 64);
    normalized.tt_exact_bound_bonus = std::clamp(normalized.tt_exact_bound_bonus, 0, 32);
    normalized.multi_pv = std::clamp(normalized.multi_pv, 1, kMaxMultiPV);
    normalized.hash_size_mb = std::clamp<std::size_t>(normalized.hash_size_mb, 1, 2048);
    if (!is_supported_thread_count(normalized.threads)) {
        throw std::invalid_argument("Albay Threads must be one of 1, 2, 3, 4, 6, or 8");
    }
    {
        std::lock_guard lock(tt_lifecycle_mutex_);
        TTReplacementPolicy tt_policy{};
        tt_policy.use_full_capacity_indexing = normalized.use_full_capacity_tt;
        tt_policy.use_age_aware_replacement = normalized.use_age_aware_tt_replacement;
        tt_policy.use_depth_preferred_updates = normalized.use_depth_preferred_tt_updates;
        tt_policy.age_penalty_per_generation = normalized.tt_age_penalty_per_generation;
        tt_policy.exact_bound_bonus = normalized.tt_exact_bound_bonus;
        transposition_table_->configure(normalized.hash_size_mb, tt_policy);
        transposition_table_->new_search();
    }

    if (normalized.active_threads == 0) {
        normalized.active_threads = normalized.threads;
    }
    normalized.active_threads = std::clamp(normalized.active_threads, 1, normalized.threads);

    auto shared = std::make_shared<SharedSearchState>(normalized.threads);
    shared->active_thread_limit.store(normalized.active_threads, std::memory_order_release);
    std::atomic_store_explicit(&shared_state_owner_, shared, std::memory_order_release);
    std::vector<std::unique_ptr<Searcher>> helpers;
    std::vector<std::jthread> helper_threads;
    helpers.reserve(static_cast<std::size_t>(normalized.threads - 1));
    helper_threads.reserve(static_cast<std::size_t>(normalized.threads - 1));

    for (int worker = 1; worker < normalized.threads; ++worker) {
        helpers.push_back(std::unique_ptr<Searcher>(new Searcher(transposition_table_, true)));
    }
    {
        std::lock_guard lock(helpers_mutex_);
        active_helpers_.clear();
        for (const auto& helper : helpers) {
            active_helpers_.push_back(helper.get());
        }
    }

    // Phase 32: create every helper first, then release them together. This avoids
    // early workers monopolizing the shared TT while later std::jthreads are still
    // being constructed. The master starts immediately after the synchronized release.
    std::mutex launch_mutex;
    std::condition_variable launch_condition;
    int helpers_ready = 0;
    bool launch_released = false;

    for (int worker = 1; worker < normalized.threads; ++worker) {
        Searcher* helper = helpers[static_cast<std::size_t>(worker - 1)].get();
        SearchOptions helper_options = normalized;
        helper_options.threads = 1;
        helper_options.multi_pv = 1;

        // Deterministic helper profiles reduce duplicated work while preserving the
        // authoritative master settings. All profiles remain full legal searches.
        switch (worker % 3) {
            case 1:
                helper_options.use_aspiration_windows = false;
                break;
            case 2:
                helper_options.aspiration_window = std::min(
                    helper_options.aspiration_max_window,
                    helper_options.aspiration_window * 2);
                helper_options.lmr_move_threshold = std::min(
                    32, helper_options.lmr_move_threshold + 1);
                break;
            default:
                helper_options.use_adaptive_aspiration_windows = true;
                break;
        }

        helper_threads.emplace_back(
            [helper, &root, &limits, helper_options, external_stop_token,
             external_pause_requested, shared, worker, &launch_mutex,
             &launch_condition, &helpers_ready, &launch_released](std::stop_token) {
                {
                    std::unique_lock launch_lock(launch_mutex);
                    ++helpers_ready;
                    launch_condition.notify_all();
                    launch_condition.wait(launch_lock, [&] {
                        return launch_released ||
                            shared->stop_requested.load(std::memory_order_acquire);
                    });
                }
                if (shared->stop_requested.load(std::memory_order_acquire)) {
                    return;
                }
                try {
                    (void)helper->search_internal(
                        root, limits, helper_options, {}, external_stop_token,
                        external_pause_requested, shared, worker);
                } catch (...) {
                    // A helper failure must never terminate the authoritative thread.
                }
            });
    }

    if (normalized.threads > 1) {
        std::unique_lock launch_lock(launch_mutex);
        launch_condition.wait(launch_lock, [&] {
            return helpers_ready == normalized.threads - 1;
        });
        launch_released = true;
        shared->synchronized_starts.fetch_add(1, std::memory_order_relaxed);
        launch_lock.unlock();
        launch_condition.notify_all();
    }

    SearchResult result{};
    try {
        result = search_internal(
            root, limits, normalized, std::move(callback), external_stop_token,
            external_pause_requested, shared, 0);
    } catch (...) {
        shared->stop_requested.store(true, std::memory_order_release);
        stop_helpers();
        resume_helpers();
        for (std::jthread& thread : helper_threads) {
            if (thread.joinable()) {
                thread.join();
            }
        }
        {
            std::lock_guard lock(helpers_mutex_);
            active_helpers_.clear();
        }
        throw;
    }

    shared->stop_requested.store(true, std::memory_order_release);
    stop_helpers();
    resume_helpers();
    for (std::jthread& thread : helper_threads) {
        if (thread.joinable()) {
            thread.join();
        }
    }
    {
        std::lock_guard lock(helpers_mutex_);
        active_helpers_.clear();
    }

    // A root exact-tablebase result is authoritative and performs no tree search.
    // Helper workers may have entered the tree before the master publishes the
    // stop request, especially after the V14 hot-path speedup.  Their speculative
    // telemetry must not overwrite the exact root contract (nodes == 0 and the
    // tablebase distance as selective depth).
    const bool exact_root_tablebase_result =
        result.completed_depth == 0 &&
        result.nodes == 0 &&
        result.diagnostics.tablebase_hits != 0;
    if (!exact_root_tablebase_result) {
        result.nodes = shared->nodes.load(std::memory_order_relaxed);
        result.selective_depth = shared->selective_depth.load(std::memory_order_relaxed);
    }
    result.transposition_table = current_tt_statistics();
    result.threads = normalized.threads;
    apply_shared_smp_diagnostics(result.diagnostics);
    {
        std::lock_guard lock(info_mutex_);
        info_.depth = result.completed_depth;
        info_.selective_depth = result.selective_depth;
        info_.score = result.score;
        info_.nodes = result.nodes;
        info_.elapsed = result.elapsed;
        info_.nodes_per_second = result.elapsed.count() > 0
            ? result.nodes * 1000ULL / static_cast<std::uint64_t>(result.elapsed.count())
            : result.nodes;
        info_.principal_variation = result.principal_variation;
        info_.multipv = result.multipv;
        info_.transposition_table = result.transposition_table;
        info_.diagnostics = result.diagnostics;
        info_.threads = result.threads;
    }
    return result;
}

SearchResult Searcher::search_internal(
    const Position& root,
    const SearchLimits& limits,
    const SearchOptions& options,
    SearchInfoCallback callback,
    std::stop_token external_stop_token,
    const std::atomic<bool>* external_pause_requested,
    std::shared_ptr<SharedSearchState> session_state,
    int worker_index) {
    SharedSearchState* const session_raw = session_state.get();
    std::atomic_store_explicit(
        &shared_state_owner_, std::move(session_state), std::memory_order_release);
    session_state_raw_.store(session_raw, std::memory_order_release);
    worker_index_ = worker_index;

    bool expected = false;
    if (!searching_.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) {
        throw std::logic_error("Albay Searcher is already searching");
    }

    struct SearchGuard {
        Searcher& searcher;
        ~SearchGuard() {
            searcher.flush_node_counters();
            if (searcher.paused_active_.exchange(false, std::memory_order_acq_rel) &&
                searcher.shared_state()) {
                searcher.shared_state()->paused_threads.fetch_sub(1, std::memory_order_acq_rel);
            }
            if (searcher.shared_state()) {
                if (searcher.policy_parked_.exchange(false, std::memory_order_acq_rel)) {
                    searcher.shared_state()->parked_threads.fetch_sub(1, std::memory_order_acq_rel);
                } else {
                    searcher.shared_state()->active_threads.fetch_sub(1, std::memory_order_acq_rel);
                }
            }
            searcher.searching_.store(false, std::memory_order_release);
            std::lock_guard lock(searcher.info_mutex_);
            searcher.info_.searching = false;
            searcher.info_.paused = false;
            searcher.info_.active_threads = searcher.shared_state()
                ? searcher.shared_state()->active_threads.load(std::memory_order_acquire)
                : 0;
        }
    } guard{*this};
    shared_state()->active_threads.fetch_add(1, std::memory_order_acq_rel);

    limits_ = limits;
    options_ = options;
    if (helper_instance_ || !options_.use_exact_tablebase ||
        options_.exact_tablebase_path.empty()) {
        exact_tablebase_.clear();
    } else if (!exact_tablebase_.loaded() ||
        exact_tablebase_.path() != std::filesystem::path(options_.exact_tablebase_path)) {
        std::string tablebase_error;
        (void)exact_tablebase_.load(options_.exact_tablebase_path, &tablebase_error);
    }
    if (limits_.move_time.count() > 0 &&
        limits_.move_time.count() < options_.strategic_evaluation_min_time_ms) {
        options_.evaluation_weights.wing_balance = 0;
        options_.evaluation_weights.rear_support = 0;
        options_.evaluation_weights.advanced_exposure = 0;
        options_.evaluation_weights.diagonal_control = 0;
        options_.evaluation_weights.reserve_tempo = 0;
        options_.evaluation_weights.space_pressure = 0;
        options_.evaluation_weights.strategic_pst = 0;
        const EvaluationWeights defaults{};
        options_.evaluation_weights.strategic_min_pieces = defaults.strategic_min_pieces;
        options_.evaluation_weights.strategic_max_pieces = defaults.strategic_max_pieces;
        options_.evaluation_weights.strategic_max_kings = defaults.strategic_max_kings;
    }
    root_piece_count_ = std::popcount(root.occupied());
    root_king_count_ = std::popcount(root.kings());
    root_has_capture_ = has_any_capture(root);
    use_default_evaluation_ = uses_default_evaluation(options_.evaluation_weights);
    use_default_move_ordering_ = uses_default_move_ordering(options_);
    callback_ = std::move(callback);
    external_stop_token_ = external_stop_token;
    external_pause_requested_ = external_pause_requested;
    limits_.depth = std::clamp(limits_.depth, 1, kMaxSearchDepth);
    clear_search_state();

    start_time_ = std::chrono::steady_clock::now();
    deadline_ = limits_.move_time.count() > 0
        ? start_time_ + limits_.move_time
        : std::chrono::steady_clock::time_point::max();

    {
        std::lock_guard lock(info_mutex_);
        info_ = {};
        info_.threads = shared_state() ? shared_state()->configured_threads : 1;
        info_.active_threads = shared_state()
            ? shared_state()->active_threads.load(std::memory_order_acquire)
            : 1;
        info_.searching = true;
    }

    Position position = root;
    initialize_nnue_accumulator(position);
    MoveList root_moves;
    generate_legal_moves(position, root_moves);

    SearchResult final_result{};
    if (root_moves.empty()) {
        final_result.score = -kMateScore;
        final_result.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start_time_);
        return final_result;
    }
    if (root.pieces(opposite(root.side_to_move())) == 0) {
        final_result.score = kMateScore;
        final_result.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start_time_);
        return final_result;
    }
    if (root.is_threefold_repetition() || root.no_progress_plies() >= 30) {
        final_result.best_move = root_moves[0];
        final_result.score = kDrawScore;
        final_result.principal_variation = {root_moves[0]};
        final_result.multipv = {{1, kDrawScore, {root_moves[0]}}};
        final_result.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start_time_);
        return final_result;
    }

    const int root_piece_count = std::popcount(root.occupied());
    if (exact_tablebase_.loaded() && root_piece_count <= options_.exact_tablebase_max_pieces &&
        root_piece_count <= exact_tablebase_.statistics().maximum_pieces) {
        ++diagnostics_.tablebase_probes;
        const ExactTablebaseProbe probe = exact_tablebase_.probe(root);
        if (probe.exact && probe.draw_rule_safe) {
            ++diagnostics_.tablebase_hits;
            final_result.best_move = probe.best_move;
            final_result.score = probe.outcome == EndgameOutcome::Win
                ? kMateScore - static_cast<int>(probe.distance_to_terminal)
                : probe.outcome == EndgameOutcome::Loss
                    ? -kMateScore + static_cast<int>(probe.distance_to_terminal)
                    : kDrawScore;
            final_result.completed_depth = 0;
            final_result.selective_depth = probe.distance_to_terminal;
            final_result.nodes = 0;
            if (probe.best_move.has_value()) {
                Position pv_position = root;
                for (int step = 0; step < static_cast<int>(probe.distance_to_terminal) &&
                     step < kMaxSearchPly; ++step) {
                    const ExactTablebaseProbe pv_probe = exact_tablebase_.probe(pv_position);
                    if (!pv_probe.exact || !pv_probe.draw_rule_safe || !pv_probe.best_move.has_value()) break;
                    final_result.principal_variation.push_back(*pv_probe.best_move);
                    UndoState undo{};
                    pv_position.make_move_unchecked(*pv_probe.best_move, undo);
                    if (pv_probe.outcome == EndgameOutcome::Draw && step >= 15) break;
                }
            }
            final_result.multipv = {{1, final_result.score, final_result.principal_variation}};
            final_result.diagnostics = diagnostics_;
            final_result.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now() - start_time_);
            return final_result;
        }
        if (probe.exact && !probe.draw_rule_safe) ++diagnostics_.tablebase_unsafe;
    }
    const bool endgame_probe_is_promising =
        !options_.exact_endgame_safe_probe_only || root_piece_count <= 2 ||
        root_moves[0].is_capture() || root.no_progress_plies() >= 24;
    if (options_.use_exact_endgame_solver && endgame_probe_is_promising &&
        root_piece_count <= options_.exact_endgame_max_pieces) {
        EndgameSolver solver;
        EndgameSolveOptions endgame_options{};
        endgame_options.maximum_pieces = options_.exact_endgame_max_pieces;
        endgame_options.node_limit = options_.exact_endgame_node_limit;
        endgame_options.should_stop = [this]() { return check_control(); };
        EndgameSolveResult solved = solver.solve(root, endgame_options);
        if (shared_state()) {
            shared_state()->nodes.fetch_add(solved.nodes, std::memory_order_relaxed);
            shared_state()->selective_depth.store(
                std::max(
                    shared_state()->selective_depth.load(std::memory_order_relaxed),
                    solved.distance_to_result),
                std::memory_order_relaxed);
        }
        if (solved.complete && solved.outcome != EndgameOutcome::Unknown) {
            final_result.best_move = solved.best_move;
            final_result.score = solved.outcome == EndgameOutcome::Win
                ? kMateScore - solved.distance_to_result
                : solved.outcome == EndgameOutcome::Loss
                    ? -kMateScore + solved.distance_to_result
                    : kDrawScore;
            final_result.completed_depth = 0;
            final_result.selective_depth = solved.distance_to_result;
            final_result.nodes = solved.nodes;
            final_result.principal_variation = std::move(solved.principal_variation);
            if (final_result.best_move.has_value() && final_result.principal_variation.empty()) {
                final_result.principal_variation.push_back(*final_result.best_move);
            }
            final_result.multipv = {{1, final_result.score, final_result.principal_variation}};
            final_result.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now() - start_time_);
            return final_result;
        }
    }

    Score previous_score = 0;
    Score previous_previous_score = 0;
    bool have_previous_score = false;
    bool have_previous_previous_score = false;
    const int maximum_depth = limits_.infinite ? kMaxSearchDepth : limits_.depth;

    // Helpers begin at staggered depths (2, 3, 1, ...) so the shared TT receives
    // useful information from different horizons instead of N copies of depth one.
    int iterative_depth = worker_index_ > 0 ? 1 + (worker_index_ % 3) : 1;
    while (iterative_depth <= maximum_depth || limits_.infinite) {
        const int depth = std::min(iterative_depth, maximum_depth);
        if (check_control()) {
            break;
        }

        if (worker_index_ == 0) {
            if (const std::optional<Move> hint = shared_root_hint(depth); hint.has_value()) {
                iterative_pv_move_ = *hint;
            }
        }

        std::vector<PrincipalVariationLine> completed_lines;
        if (options_.multi_pv == 1) {
            Score alpha = -kInfiniteScore;
            Score beta = kInfiniteScore;
            int initial_window = options_.aspiration_window;
            if (options_.use_adaptive_aspiration_windows && have_previous_previous_score) {
                const int volatility = std::abs(previous_score - previous_previous_score);
                initial_window = std::clamp(
                    options_.aspiration_window +
                        volatility * options_.aspiration_volatility_scale_percent / 100,
                    options_.aspiration_window,
                    options_.aspiration_max_window);
            }
            if (options_.use_aspiration_windows && depth >= options_.aspiration_min_depth) {
                alpha = std::max(-kInfiniteScore, previous_score - initial_window);
                beta = std::min(kInfiniteScore, previous_score + initial_window);
            }

            RootResult iteration{};
            int window = initial_window;
            while (true) {
                pv_length_.fill(0);
                iteration = search_root(position, depth, alpha, beta);
                if (stop_requested_.load(std::memory_order_acquire)) {
                    break;
                }
                if (iteration.score <= alpha && alpha > -kInfiniteScore) {
                    ++diagnostics_.aspiration_fail_lows;
                    ++diagnostics_.aspiration_researches;
                    window = std::min(
                        std::max(window + 1, window * options_.aspiration_growth_percent / 100),
                        kInfiniteScore / 2);
                    const int biased = window * options_.aspiration_side_bias_percent / 100;
                    alpha = std::max(-kInfiniteScore, iteration.score - window);
                    beta = std::min(kInfiniteScore, iteration.score + biased);
                    continue;
                }
                if (iteration.score >= beta && beta < kInfiniteScore) {
                    ++diagnostics_.aspiration_fail_highs;
                    ++diagnostics_.aspiration_researches;
                    window = std::min(
                        std::max(window + 1, window * options_.aspiration_growth_percent / 100),
                        kInfiniteScore / 2);
                    const int biased = window * options_.aspiration_side_bias_percent / 100;
                    alpha = std::max(-kInfiniteScore, iteration.score - biased);
                    beta = std::min(kInfiniteScore, iteration.score + window);
                    continue;
                }
                break;
            }

            if (stop_requested_.load(std::memory_order_acquire) || !iteration.best_move.has_value()) {
                break;
            }

            std::vector<Move> pv = current_pv();
            if (pv.empty()) {
                pv.push_back(*iteration.best_move);
            }
            completed_lines.push_back({1, iteration.score, std::move(pv)});
        } else {
            pv_length_.fill(0);
            completed_lines = search_root_multipv(position, depth, options_.multi_pv);
            if (stop_requested_.load(std::memory_order_acquire) || completed_lines.empty()) {
                break;
            }
        }

        const PrincipalVariationLine& primary = completed_lines.front();
        if (primary.principal_variation.empty()) {
            break;
        }

        if (have_previous_score) {
            previous_previous_score = previous_score;
            have_previous_previous_score = true;
        }
        previous_score = primary.score;
        have_previous_score = true;
        iterative_pv_move_ = primary.principal_variation.front();
        if (worker_index_ > 0) {
            publish_helper_root_hint(
                depth, primary.score, primary.principal_variation.front());
        }
        final_result.best_move = primary.principal_variation.front();
        final_result.score = primary.score;
        final_result.completed_depth = depth;
        final_result.selective_depth = reported_selective_depth();
        final_result.principal_variation = primary.principal_variation;
        final_result.multipv = completed_lines;
        publish_completed_iteration(
            depth,
            primary.score,
            primary.principal_variation,
            completed_lines);

        if (std::abs(primary.score) >= kMateThreshold && !limits_.infinite) {
            break;
        }
        if (hard_limit_reached()) {
            stop_requested_.store(true, std::memory_order_release);
            break;
        }
        if (iterative_depth < maximum_depth) {
            ++iterative_depth;
        } else if (!limits_.infinite) {
            break;
        }
    }

    flush_node_counters();
    final_result.nodes = reported_nodes();
    final_result.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - start_time_);
    final_result.transposition_table = current_tt_statistics();
    final_result.diagnostics = diagnostics_;
    apply_shared_smp_diagnostics(final_result.diagnostics);
    final_result.threads = shared_state() ? shared_state()->configured_threads : 1;
    final_result.stopped = stop_requested_.load(std::memory_order_acquire);

    if (!final_result.best_move.has_value()) {
        final_result.best_move = root_moves[0];
        final_result.principal_variation = {root_moves[0]};
        final_result.score = evaluate_cached(root, 0);
        final_result.multipv = {{1, final_result.score, final_result.principal_variation}};
    }
    return final_result;
}

Searcher::RootResult Searcher::search_root(Position& position, int depth, Score alpha, Score beta) {
    const Score original_alpha = alpha;
    const HashKey key = transposition_key(position);
    std::optional<MoveIdentity> tt_move_storage;
    if (options_.use_transposition_table && transposition_allowed(position)) {
        TTEntry entry{};
        if (probe_tt(key, entry) && entry.has_move()) {
            tt_move_storage = entry.best_move;
        }
    }

    MoveList moves;
    generate_legal_moves(position, moves);
    const Move* pv_move = iterative_pv_move_.has_value() ? &*iterative_pv_move_ : nullptr;
    const MoveIdentity* tt_move = tt_move_storage.has_value() ? &*tt_move_storage : nullptr;
    order_moves(position, moves, 0, pv_move, tt_move, nullptr, nullptr);

    RootResult result{};
    bool first_move = true;

    for (const Move& move : moves) {
        if (check_control()) {
            break;
        }

        pv_length_[1] = 0;
        int extension = tactical_extension(position, move, moves.size(), depth, 0);
        extension = std::max(extension, forced_line_extension(moves.size(), depth, 0));
        const bool captured_king = move.is_capture() &&
            (move.captured_mask() & position.kings()) != 0;
        UndoState undo{};
        record_nnue_child(position, move, 1);
        position.make_move_unchecked(move, undo);
        extension = std::max(
            extension, forced_reply_extension(position, move, captured_king, depth, 0));
        extension = std::max(
            extension, quiet_sacrifice_extension(position, move, depth, 0, nullptr));
        if (extension > 0) {
            ++diagnostics_.extensions_applied;
            diagnostics_.extension_plies += static_cast<std::uint64_t>(extension);
        }
        const int child_depth = depth - 1 + extension;
        Score score = 0;
        if (first_move || !options_.use_pvs) {
            score = -negamax(position, child_depth, -beta, -alpha, 1, true, &move, nullptr, extension);
        } else {
            score = -negamax(position, child_depth, -alpha - 1, -alpha, 1, false, &move, nullptr, extension);
            if (score > alpha && score < beta) {
                score = -negamax(position, child_depth, -beta, -alpha, 1, true, &move, nullptr, extension);
            }
        }
        position.unmake_move(move, undo);

        if (stop_requested_.load(std::memory_order_acquire)) {
            break;
        }
        first_move = false;

        if (score > result.score) {
            result.score = score;
            result.best_move = move;
        }
        if (score > alpha) {
            alpha = score;
            update_pv(0, move);
        }
        if (alpha >= beta) {
            ++diagnostics_.beta_cutoffs;
            if (move.is_capture()) {
                update_capture_heuristics(position.side_to_move(), move, depth, nullptr, nullptr);
            } else {
                update_quiet_heuristics(position, position.side_to_move(), move, depth, 0, nullptr, nullptr);
            }
            break;
        }
    }

    if (!stop_requested_.load(std::memory_order_acquire) && result.best_move.has_value() &&
        options_.use_transposition_table && transposition_allowed(position)) {
        TTBound bound = TTBound::Exact;
        if (result.score <= original_alpha) {
            bound = TTBound::Upper;
        } else if (result.score >= beta) {
            bound = TTBound::Lower;
        }
        store_tt(key, depth, score_to_tt(result.score, 0), bound, &*result.best_move);
    }

    if (!result.best_move.has_value() && !moves.empty()) {
        result.best_move = moves[0];
        result.score = original_alpha;
    }
    return result;
}

std::vector<PrincipalVariationLine> Searcher::search_root_multipv(
    Position& position,
    int depth,
    int line_count) {
    const HashKey key = transposition_key(position);
    std::optional<MoveIdentity> tt_move_storage;
    if (options_.use_transposition_table && transposition_allowed(position)) {
        TTEntry entry{};
        if (probe_tt(key, entry) && entry.has_move()) {
            tt_move_storage = entry.best_move;
        }
    }

    MoveList moves;
    generate_legal_moves(position, moves);
    const Move* pv_move = iterative_pv_move_.has_value() ? &*iterative_pv_move_ : nullptr;
    const MoveIdentity* tt_move = tt_move_storage.has_value() ? &*tt_move_storage : nullptr;
    order_moves(position, moves, 0, pv_move, tt_move, nullptr, nullptr);

    std::vector<PrincipalVariationLine> lines;
    lines.reserve(moves.size());

    for (const Move& move : moves) {
        if (check_control()) {
            break;
        }

        pv_length_[1] = 0;
        int extension = tactical_extension(position, move, moves.size(), depth, 0);
        extension = std::max(extension, forced_line_extension(moves.size(), depth, 0));
        const bool captured_king = move.is_capture() &&
            (move.captured_mask() & position.kings()) != 0;
        UndoState undo{};
        record_nnue_child(position, move, 1);
        position.make_move_unchecked(move, undo);
        extension = std::max(
            extension, forced_reply_extension(position, move, captured_king, depth, 0));
        extension = std::max(
            extension, quiet_sacrifice_extension(position, move, depth, 0, nullptr));
        if (extension > 0) {
            ++diagnostics_.extensions_applied;
            diagnostics_.extension_plies += static_cast<std::uint64_t>(extension);
        }
        const Score score = -negamax(
            position,
            depth - 1 + extension,
            -kInfiniteScore,
            kInfiniteScore,
            1,
            true,
            &move,
            nullptr,
            extension);
        position.unmake_move(move, undo);

        if (stop_requested_.load(std::memory_order_acquire)) {
            break;
        }

        std::vector<Move> pv;
        pv.push_back(move);
        std::vector<Move> continuation = child_pv(1);
        pv.insert(pv.end(), continuation.begin(), continuation.end());
        lines.push_back({1, score, std::move(pv)});
    }

    if (stop_requested_.load(std::memory_order_acquire)) {
        return {};
    }

    std::stable_sort(lines.begin(), lines.end(), [](const PrincipalVariationLine& first, const PrincipalVariationLine& second) {
        return first.score > second.score;
    });
    if (lines.size() > static_cast<std::size_t>(line_count)) {
        lines.resize(static_cast<std::size_t>(line_count));
    }
    for (std::size_t index = 0; index < lines.size(); ++index) {
        lines[index].rank = static_cast<int>(index + 1U);
    }

    if (!lines.empty() && options_.use_transposition_table && transposition_allowed(position)) {
        const Move& best_move = lines.front().principal_variation.front();
        store_tt(key, depth, score_to_tt(lines.front().score, 0), TTBound::Exact, &best_move);
    }
    return lines;
}

Score Searcher::negamax(
    Position& position,
    int depth,
    Score alpha,
    Score beta,
    int ply,
    bool pv_node,
    const Move* previous_move,
    const Move* previous_previous_move,
    int extensions_used) {
    if (ply >= kMaxSearchPly - 1) {
        return evaluate_cached(position, ply);
    }
    count_node(ply);
    pv_length_[static_cast<std::size_t>(ply)] = 0;

    if (control_check_due() && check_control()) {
        return evaluate_cached(position, ply);
    }
    const int repetition_count = position.repetition_count();
    if (repetition_count >= 3 || position.no_progress_plies() >= 30) {
        return kDrawScore;
    }
    if (depth <= 0) {
        return quiescence(position, alpha, beta, ply, previous_move);
    }

    if (options_.exact_tablebase_probe_search && exact_tablebase_.loaded() &&
        std::popcount(position.occupied()) <= options_.exact_tablebase_max_pieces &&
        std::popcount(position.occupied()) <= exact_tablebase_.statistics().maximum_pieces) {
        ++diagnostics_.tablebase_probes;
        const ExactTablebaseProbe probe = exact_tablebase_.probe(position);
        if (probe.exact && probe.draw_rule_safe) {
            ++diagnostics_.tablebase_hits;
            const Score tablebase_score = probe.outcome == EndgameOutcome::Win
                ? kMateScore - ply - static_cast<int>(probe.distance_to_terminal)
                : probe.outcome == EndgameOutcome::Loss
                    ? -kMateScore + ply + static_cast<int>(probe.distance_to_terminal)
                    : kDrawScore;
            if (options_.use_transposition_table && repetition_count <= 1) {
                const HashKey tablebase_key = transposition_key(position);
                const Move* tablebase_move = probe.best_move.has_value() ? &*probe.best_move : nullptr;
                store_tt(tablebase_key, depth, score_to_tt(tablebase_score, ply), TTBound::Exact, tablebase_move);
            }
            return tablebase_score;
        }
        if (probe.exact && !probe.draw_rule_safe) ++diagnostics_.tablebase_unsafe;
    }

    const Score original_alpha = alpha;
    const HashKey key = transposition_key(position);
    const bool tt_allowed = options_.use_transposition_table && repetition_count <= 1;
    std::optional<MoveIdentity> tt_move_storage;
    if (tt_allowed) {
        TTEntry entry{};
        if (probe_tt(key, entry)) {
            if (entry.has_move()) {
                tt_move_storage = entry.best_move;
            }
            if (!pv_node && entry.depth >= depth) {
                const Score tt_score = score_from_tt(entry.score, ply);
                const bool usable = entry.bound == TTBound::Exact ||
                    (!options_.quiescence_tt_exact_only &&
                     ((entry.bound == TTBound::Lower && tt_score >= beta) ||
                      (entry.bound == TTBound::Upper && tt_score <= alpha)));
                if (usable) {
                    ++tt_cutoffs_;
                    if (SharedSearchState* state = session_state();
                        state != nullptr && state->configured_threads > 1) {
                        state->tt_cutoffs.fetch_add(1, std::memory_order_relaxed);
                    }
                    return tt_score;
                }
            }
        }
    }

    if (options_.use_internal_iterative_reduction && !pv_node &&
        !tt_move_storage.has_value() && depth >= options_.iir_min_depth &&
        root_piece_count_ <= options_.iir_max_pieces &&
        alpha > -kMateThreshold && beta < kMateThreshold &&
        !has_any_capture(position)) {
        depth = std::max(1, depth - options_.iir_reduction);
        ++diagnostics_.iir_reductions;
    }

    const bool razor_piece_count_allows =
        (options_.razor_min_pieces <= 0 || root_piece_count_ >= options_.razor_min_pieces) &&
        root_piece_count_ <= options_.razor_max_pieces;
    const bool razor_time_allows = options_.razor_max_time_ms <= 0 ||
        limits_.move_time.count() <= 0 ||
        limits_.move_time.count() <= options_.razor_max_time_ms;
    if (options_.use_razoring && razor_piece_count_allows && razor_time_allows && !pv_node &&
        depth <= options_.razor_max_depth && alpha > -kMateThreshold &&
        beta < kMateThreshold && !has_any_capture(position)) {
        ++diagnostics_.razor_attempts;
        const Score static_eval = evaluate_cached(position, ply);
        const Score margin = options_.razor_margin_base +
            options_.razor_margin_per_depth * depth;
        if (static_eval + margin <= alpha) {
            const Score razor_score = quiescence(position, alpha, beta, ply, previous_move);
            if (razor_score <= alpha) {
                ++diagnostics_.razor_cutoffs;
                return razor_score;
            }
        }
    }

    MoveList moves;
    generate_legal_moves(position, moves);
    if (moves.empty()) {
        const Score mate_score = -kMateScore + ply;
        if (tt_allowed) {
            store_tt(key, depth, score_to_tt(mate_score, ply), TTBound::Exact, nullptr);
        }
        return mate_score;
    }

    const MoveIdentity* tt_move = tt_move_storage.has_value() ? &*tt_move_storage : nullptr;
    order_moves(position, moves, ply, nullptr, tt_move, previous_move, previous_previous_move);
    const bool quiet_node = !moves[0].is_capture();
    const bool futility_piece_count_allows =
        (options_.futility_min_pieces <= 0 || root_piece_count_ >= options_.futility_min_pieces) &&
        root_piece_count_ <= options_.futility_max_pieces;
    const bool futility_candidate = options_.use_static_futility_pruning &&
        futility_piece_count_allows && !pv_node && quiet_node &&
        depth <= options_.futility_max_depth && alpha > -kMateThreshold &&
        beta < kMateThreshold;
    const Score static_eval = futility_candidate ? evaluate_cached(position, ply) : 0;
    const Score futility_margin = options_.futility_margin_base +
        options_.futility_margin_per_depth * depth;
    bool first_move = true;
    std::optional<Move> best_move;
    Score best_score = -kInfiniteScore;
    std::size_t move_index = 0;
    MoveList searched_moves;

    for (const Move& move : moves) {
        const bool is_tt_move = tt_move != nullptr && same_move_identity(move, *tt_move);
        int quiet_history = 0;
        if (!move.is_capture()) {
            const std::size_t mover_index = color_index(position.side_to_move());
            quiet_history = history_[mover_index][move.from][move.to];
            if (options_.use_continuation_history && previous_move != nullptr &&
                is_valid_square(previous_move->to)) {
                quiet_history += continuation_history_[mover_index][previous_move->to]
                    [move.from][move.to];
            }
            if (options_.use_followup_history && previous_previous_move != nullptr &&
                is_valid_square(previous_previous_move->to)) {
                quiet_history += followup_history_[mover_index][previous_previous_move->to]
                    [move.from][move.to] * options_.followup_history_weight / 100;
            }
            if (options_.use_piece_type_history) {
                quiet_history += piece_type_history_[mover_index]
                    [moving_piece_type_index(move)][move.from][move.to] *
                    options_.piece_type_history_weight / 100;
            }
        }
        const bool quiet_noncritical = quiet_node && !move.is_capture() &&
            !move.is_promotion() && !is_tt_move;
        const bool lmp_history_allows =
            !options_.use_history_guarded_late_move_pruning ||
            quiet_history <= options_.late_move_pruning_history_threshold;
        const bool lmp_piece_count_allows =
            (options_.late_move_pruning_min_pieces <= 0 ||
             root_piece_count_ >= options_.late_move_pruning_min_pieces) &&
            root_piece_count_ <= options_.late_move_pruning_max_pieces;
        if (!first_move && !pv_node && quiet_noncritical) {
            const bool history_piece_count_allows =
                (options_.history_pruning_min_pieces <= 0 ||
                 root_piece_count_ >= options_.history_pruning_min_pieces) &&
                root_piece_count_ <= options_.history_pruning_max_pieces;
            const bool history_killer = ply < kMaxSearchPly &&
                (same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][0]) ||
                 same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][1]));
            bool history_countermove = false;
            if (options_.use_countermove && previous_move != nullptr &&
                is_valid_square(previous_move->from) && is_valid_square(previous_move->to)) {
                const Move& countermove = countermoves_[color_index(position.side_to_move())]
                    [previous_move->from][previous_move->to];
                history_countermove = same_move_identity(move, countermove);
            }
            if (options_.use_history_pruning && history_piece_count_allows &&
                depth <= options_.history_pruning_max_depth &&
                move_index >= static_cast<std::size_t>(options_.history_pruning_move_threshold) &&
                quiet_history <= options_.history_pruning_threshold &&
                !history_killer && !history_countermove) {
                ++diagnostics_.history_pruned_moves;
                searched_moves.push_back(move);
                ++move_index;
                continue;
            }
            if (options_.use_late_move_pruning && lmp_history_allows &&
                lmp_piece_count_allows &&
                depth <= options_.late_move_pruning_max_depth &&
                move_index >= static_cast<std::size_t>(
                    options_.late_move_pruning_base_moves + depth * 2)) {
                ++diagnostics_.late_move_pruning_events;
                diagnostics_.late_move_pruned_moves +=
                    static_cast<std::uint64_t>(moves.size() - move_index);
                break;
            }
            if (futility_candidate && static_eval + futility_margin <= alpha) {
                ++diagnostics_.futility_pruned_moves;
                searched_moves.push_back(move);
                ++move_index;
                continue;
            }
        }

        int extension = tactical_extension(
            position, move, moves.size(), depth, extensions_used);
        extension = std::max(
            extension, forced_line_extension(moves.size(), depth, extensions_used));
        extension = std::max(
            extension, recapture_extension(move, previous_move, depth, extensions_used));
        const bool captured_king = move.is_capture() &&
            (move.captured_mask() & position.kings()) != 0;
        const int provisional_child_depth = depth - 1 + extension;

        const bool russian_lmr_phase = options_.use_russian_lmr_v2 &&
            !root_has_capture_ &&
            root_piece_count_ >= options_.lmr_phase_min_pieces &&
            root_piece_count_ <= options_.lmr_phase_max_pieces &&
            root_king_count_ <= options_.lmr_phase_max_kings;
        const int effective_lmr_min_depth = russian_lmr_phase
            ? options_.lmr_phase_min_depth
            : options_.lmr_min_depth;
        const int effective_lmr_move_threshold = russian_lmr_phase
            ? options_.lmr_phase_move_threshold
            : options_.lmr_move_threshold;
        const bool is_killer_move = ply < kMaxSearchPly &&
            (same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][0]) ||
             same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][1]));
        bool is_countermove_move = false;
        if (options_.use_countermove && previous_move != nullptr &&
            is_valid_square(previous_move->from) && is_valid_square(previous_move->to)) {
            const Move& countermove = countermoves_[color_index(position.side_to_move())]
                [previous_move->from][previous_move->to];
            is_countermove_move = same_move_identity(move, countermove);
        }
        const bool russian_priority_guard =
            (options_.use_lmr_priority_guard || russian_lmr_phase) &&
            (is_killer_move || is_countermove_move ||
             quiet_history >= options_.lmr_protected_history_threshold);

        const bool lmr_base_candidate = options_.use_late_move_reductions &&
            options_.use_pvs && !first_move && !move.is_capture() &&
            !move.is_promotion() && depth >= effective_lmr_min_depth &&
            provisional_child_depth >= 3 &&
            (options_.use_dynamic_lmr
                ? (move_index >= static_cast<std::size_t>(effective_lmr_move_threshold) &&
                   quiet_history < options_.lmr_history_threshold)
                : (move_index >= static_cast<std::size_t>(effective_lmr_move_threshold + 1)));
        if (lmr_base_candidate && russian_priority_guard) {
            ++diagnostics_.lmr_priority_guards;
        }
        bool late_quiet = lmr_base_candidate && !russian_priority_guard;

        UndoState undo{};
        record_nnue_child(position, move, ply + 1);
        position.make_move_unchecked(move, undo);
        if (late_quiet && (options_.use_lmr_forcing_capture_guard || russian_lmr_phase) &&
            has_any_capture(position)) {
            // A quiet move that forces an immediate mandatory capture is tactical in
            // Russian draughts and must not be searched at reduced depth.
            ++diagnostics_.lmr_forcing_capture_guards;
            late_quiet = false;
        }
        extension = std::max(
            extension,
            forced_reply_extension(
                position, move, captured_king, depth, extensions_used));
        bool forcing_quiet_capture = false;
        extension = std::max(
            extension,
            quiet_sacrifice_extension(
                position, move, depth, extensions_used, &forcing_quiet_capture));
        if (options_.use_forcing_quiet_lmr_guard && forcing_quiet_capture) {
            late_quiet = false;
        }
        if (late_quiet && options_.use_endgame_lmr_guard &&
            std::popcount(position.occupied()) <= options_.endgame_reply_order_max_pieces &&
            capped_reply_count(position, options_.endgame_lmr_guard_reply_threshold + 1) <=
                options_.endgame_lmr_guard_reply_threshold) {
            late_quiet = false;
        }
        if (extension > 0) {
            ++diagnostics_.extensions_applied;
            diagnostics_.extension_plies += static_cast<std::uint64_t>(extension);
        }
        const int child_depth = depth - 1 + extension;
        const int child_extensions = extensions_used + extension;

        Score score = 0;
        if (first_move || !options_.use_pvs) {
            score = -negamax(
                position,
                child_depth,
                -beta,
                -alpha,
                ply + 1,
                pv_node && first_move,
                &move,
                previous_move,
                child_extensions);
        } else {
            int reduced_depth = child_depth;
            if (late_quiet) {
                ++diagnostics_.lmr_reductions;
                int reduction = 1;
                if (options_.use_russian_lmr_v2 && russian_lmr_phase && !pv_node &&
                    depth >= options_.lmr_phase_deep_depth &&
                    move_index >= static_cast<std::size_t>(options_.lmr_phase_deep_move_threshold) &&
                    quiet_history <= options_.lmr_negative_history_threshold) {
                    reduction = std::min(2, options_.lmr_max_reduction);
                } else if (options_.use_dynamic_lmr && !pv_node &&
                    depth >= options_.lmr_deep_depth &&
                    move_index >= static_cast<std::size_t>(options_.lmr_deep_move_threshold) &&
                    quiet_history <= options_.lmr_deep_history_threshold) {
                    reduction = std::min(2, options_.lmr_max_reduction);
                    if (options_.lmr_max_reduction >= 3 &&
                        depth >= options_.lmr_deep_depth + 4 &&
                        move_index >= static_cast<std::size_t>(options_.lmr_deep_move_threshold + 6) &&
                        quiet_history <= options_.lmr_deep_history_threshold - 4'000) {
                        reduction = 3;
                    }
                }
                reduced_depth = std::max(1, child_depth - reduction);
            }
            score = -negamax(
                position,
                reduced_depth,
                -alpha - 1,
                -alpha,
                ply + 1,
                false,
                &move,
                previous_move,
                child_extensions);
            if (late_quiet && score > alpha) {
                ++diagnostics_.lmr_researches;
                score = -negamax(
                    position,
                    child_depth,
                    -alpha - 1,
                    -alpha,
                    ply + 1,
                    false,
                    &move,
                    previous_move,
                    child_extensions);
            }
            if (pv_node && score > alpha && score < beta) {
                score = -negamax(
                    position,
                    child_depth,
                    -beta,
                    -alpha,
                    ply + 1,
                    true,
                    &move,
                    previous_move,
                    child_extensions);
            }
        }
        position.unmake_move(move, undo);

        if (stop_requested_.load(std::memory_order_acquire)) {
            return alpha;
        }
        first_move = false;
        ++move_index;

        if (score > best_score) {
            best_score = score;
            best_move = move;
        }
        if (score > alpha) {
            alpha = score;
            update_pv(ply, move);
            if (alpha >= beta) {
                ++diagnostics_.beta_cutoffs;
                const Color mover = position.side_to_move();
                if (move.is_capture()) {
                    update_capture_heuristics(mover, move, depth, previous_move, previous_previous_move);
                } else {
                    update_quiet_heuristics(position, mover, move, depth, ply, previous_move, previous_previous_move);
                }
                if (options_.use_history_malus) {
                    for (const Move& searched_move : searched_moves) {
                        apply_history_malus(position, mover, searched_move, depth, previous_move, previous_previous_move);
                    }
                }
                break;
            }
        }
        searched_moves.push_back(move);
    }

    if (tt_allowed && !stop_requested_.load(std::memory_order_acquire)) {
        TTBound bound = TTBound::Exact;
        if (alpha <= original_alpha) {
            bound = TTBound::Upper;
        } else if (alpha >= beta) {
            bound = TTBound::Lower;
        }
        store_tt(
            key,
            depth,
            score_to_tt(alpha, ply),
            bound,
            best_move.has_value() ? &*best_move : nullptr);
    }
    return alpha;
}

Score Searcher::quiescence(
    Position& position,
    Score alpha,
    Score beta,
    int ply,
    const Move* previous_move,
    int promotion_extensions) {
    if (ply >= kMaxSearchPly - 1) {
        return evaluate_cached(position, ply);
    }
    count_node(ply);
    ++diagnostics_.quiescence_nodes;
    pv_length_[static_cast<std::size_t>(ply)] = 0;

    if (control_check_due() && check_control()) {
        return evaluate_cached(position, ply);
    }
    const int repetition_count = position.repetition_count();
    if (repetition_count >= 3 || position.no_progress_plies() >= 30) {
        return kDrawScore;
    }

    const Score original_alpha = alpha;
    const HashKey key = transposition_key(position);
    const bool tt_allowed = options_.use_transposition_table && options_.use_quiescence_tt &&
        transposition_allowed(position);
    std::optional<MoveIdentity> tt_move_storage;
    if (tt_allowed) {
        TTEntry entry{};
        if (probe_tt(key, entry)) {
            if (entry.has_move()) {
                tt_move_storage = entry.best_move;
            }
            if (entry.depth >= 0) {
                const Score tt_score = score_from_tt(entry.score, ply);
                const bool usable = entry.bound == TTBound::Exact ||
                    (!options_.quiescence_tt_exact_only &&
                     ((entry.bound == TTBound::Lower && tt_score >= beta) ||
                      (entry.bound == TTBound::Upper && tt_score <= alpha)));
                if (usable) {
                    ++tt_cutoffs_;
                    if (SharedSearchState* state = session_state();
                        state != nullptr && state->configured_threads > 1) {
                        state->tt_cutoffs.fetch_add(1, std::memory_order_relaxed);
                    }
                    return tt_score;
                }
            }
        }
    }

    MoveList moves;
    const bool has_capture = generate_capture_moves(position, moves);
    if (has_capture) {
        ++diagnostics_.quiescence_capture_nodes;
    } else {
        ++diagnostics_.quiescence_quiet_nodes;
    }
    if (!has_capture) {
        if (!has_any_quiet_move(position)) {
            const Score mate_score = -kMateScore + ply;
            if (tt_allowed) {
                store_tt(key, 0, score_to_tt(mate_score, ply), TTBound::Exact, nullptr);
            }
            return mate_score;
        }

        const Score stand_pat = evaluate_cached(position, ply);
        if (stand_pat >= beta) {
            ++diagnostics_.beta_cutoffs;
            if (tt_allowed && !options_.quiescence_tt_exact_only) {
                store_tt(key, 0, score_to_tt(stand_pat, ply), TTBound::Lower, nullptr);
            }
            return beta;
        }
        alpha = std::max(alpha, stand_pat);

        if (!options_.use_promotion_quiescence ||
            promotion_extensions >= options_.quiescence_promotion_max_extensions) {
            ++diagnostics_.quiescence_quiet_move_generation_skips;
            if (tt_allowed) {
                const TTBound bound = alpha <= original_alpha ? TTBound::Upper : TTBound::Exact;
                if (!options_.quiescence_tt_exact_only || bound == TTBound::Exact) {
                    store_tt(key, 0, score_to_tt(alpha, ply), bound, nullptr);
                }
            }
            return alpha;
        }

        // Promotion-quiescence is optional. Only this non-default path needs the
        // full quiet move list; ordinary quiet leaves stop after stand-pat.
        generate_legal_moves(position, moves);
        if (moves.empty()) {
            const Score mate_score = -kMateScore + ply;
            if (tt_allowed) {
                store_tt(key, 0, score_to_tt(mate_score, ply), TTBound::Exact, nullptr);
            }
            return mate_score;
        }

        order_moves(
            position, moves, ply, nullptr,
            tt_move_storage.has_value() ? &*tt_move_storage : nullptr,
            previous_move, nullptr);
        std::optional<Move> best_promotion;
        for (const Move& move : moves) {
            if (!move.is_promotion()) {
                continue;
            }
            UndoState undo{};
            record_nnue_child(position, move, ply + 1);
            position.make_move_unchecked(move, undo);
            const Score score = -quiescence(
                position, -beta, -alpha, ply + 1, &move, promotion_extensions + 1);
            position.unmake_move(move, undo);

            if (stop_requested_.load(std::memory_order_acquire)) {
                return alpha;
            }
            if (score >= beta) {
                ++diagnostics_.beta_cutoffs;
                if (tt_allowed && !options_.quiescence_tt_exact_only) {
                    store_tt(key, 0, score_to_tt(score, ply), TTBound::Lower, &move);
                }
                return beta;
            }
            if (score > alpha) {
                alpha = score;
                best_promotion = move;
                update_pv(ply, move);
            }
        }

        if (tt_allowed) {
            const TTBound bound = alpha <= original_alpha ? TTBound::Upper : TTBound::Exact;
            if (!options_.quiescence_tt_exact_only || bound == TTBound::Exact) {
                store_tt(
                    key, 0, score_to_tt(alpha, ply), bound,
                    best_promotion.has_value() ? &*best_promotion : nullptr);
            }
        }
        return alpha;
    }

    const MoveIdentity* tt_move = tt_move_storage.has_value() ? &*tt_move_storage : nullptr;
    order_moves(position, moves, ply, nullptr, tt_move, previous_move, nullptr);
    std::optional<Move> best_move;
    for (const Move& move : moves) {
        const Color mover = position.side_to_move();
        const Score alpha_before = alpha;
        UndoState undo{};
        record_nnue_child(position, move, ply + 1);
        position.make_move_unchecked(move, undo);
        const Score score = -quiescence(
            position, -beta, -alpha, ply + 1, &move, promotion_extensions);
        position.unmake_move(move, undo);

        if (stop_requested_.load(std::memory_order_acquire)) {
            return alpha;
        }
        if (score >= beta) {
            ++diagnostics_.beta_cutoffs;
            update_capture_heuristics(
                position.side_to_move(), move, 1, previous_move, nullptr);
            if (tt_allowed) {
                store_tt(key, 0, score_to_tt(score, ply), TTBound::Lower, &move);
            }
            return beta;
        }
        if (options_.use_quiescence_capture_malus && score <= alpha_before) {
            apply_history_malus(position, mover, move, 1, previous_move, nullptr);
        }
        if (score > alpha) {
            alpha = score;
            best_move = move;
            update_pv(ply, move);
        }
    }

    if (tt_allowed) {
        const TTBound bound = alpha <= original_alpha ? TTBound::Upper : TTBound::Exact;
        if (!options_.quiescence_tt_exact_only || bound == TTBound::Exact) {
            store_tt(
                key,
                0,
                score_to_tt(alpha, ply),
                bound,
                best_move.has_value() ? &*best_move : nullptr);
        }
    }
    return alpha;
}

void Searcher::order_moves(
    const Position& position,
    MoveList& moves,
    int ply,
    const Move* pv_move,
    const MoveIdentity* tt_move,
    const Move* previous_move,
    const Move* previous_previous_move) {
    if (moves.size() < 2) {
        return;
    }

    std::array<int, kMaxMoves> scores;
    for (std::size_t index = 0; index < moves.size(); ++index) {
        scores[index] = move_order_score(
            position, moves[index], ply, pv_move, tt_move, previous_move,
            previous_previous_move);
    }

    // Stable insertion sort is faster than repeatedly recomputing scores from a
    // comparator for the small move lists typical of 8x8 draughts.
    for (std::size_t index = 1; index < moves.size(); ++index) {
        Move move = moves[index];
        const int score = scores[index];
        std::size_t cursor = index;
        while (cursor > 0 && score > scores[cursor - 1]) {
            moves[cursor] = moves[cursor - 1];
            scores[cursor] = scores[cursor - 1];
            --cursor;
        }
        moves[cursor] = move;
        scores[cursor] = score;
    }
}

int Searcher::move_order_score(
    const Position& position,
    const Move& move,
    int ply,
    const Move* pv_move,
    const MoveIdentity* tt_move,
    const Move* previous_move,
    const Move* previous_previous_move) const {
    if (pv_move != nullptr && same_move_identity(move, *pv_move)) {
        return 2'100'000;
    }
    if (tt_move != nullptr && same_move_identity(move, *tt_move)) {
        return 2'000'000;
    }

    if (use_default_move_ordering_) {
        int score = 0;
        const std::size_t mover_index = color_index(position.side_to_move());
        if (move.is_capture()) {
            const Bitboard captured = move.captured_mask();
            const int captured_kings = std::popcount(captured & position.kings());
            score = 1'000'000 + static_cast<int>(move.capture_count) * 20'000 +
                captured_kings * 12'000 +
                capture_history_[mover_index][move.from][move.to] +
                kCaptureLandingCenterBonus[static_cast<std::size_t>(move.to)];
        } else if (ply < kMaxSearchPly) {
            if (same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][0])) {
                score += 60'000;
            } else if (same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][1])) {
                score += 50'000;
            }
            if (previous_move != nullptr &&
                is_valid_square(previous_move->from) && is_valid_square(previous_move->to)) {
                const Move& countermove = countermoves_[mover_index]
                    [previous_move->from][previous_move->to];
                if (same_move_identity(move, countermove)) {
                    score += 55'000;
                }
            }
            score += history_[mover_index][move.from][move.to];
            if (previous_move != nullptr && is_valid_square(previous_move->to)) {
                score += continuation_history_[mover_index][previous_move->to]
                    [move.from][move.to];
            }
            if (previous_previous_move != nullptr &&
                is_valid_square(previous_previous_move->to)) {
                score += followup_history_[mover_index][previous_previous_move->to]
                    [move.from][move.to] * 15 / 100;
            }
        }
        if (move.is_promotion()) {
            score += 90'000;
        }
        if (worker_index_ > 0 && is_valid_square(move.from) && is_valid_square(move.to)) {
            std::uint32_t mix = static_cast<std::uint32_t>(move.from) * 0x9E3779B1U;
            mix ^= static_cast<std::uint32_t>(move.to) * 0x85EBCA77U;
            mix ^= static_cast<std::uint32_t>(move.capture_count) * 0xC2B2AE3DU;
            mix ^= static_cast<std::uint32_t>(worker_index_) * 0x27D4EB2FU;
            mix ^= mix >> 16U;
            score += static_cast<int>(mix & 31U);
        }
        return score;
    }

    int score = 0;
    const std::size_t mover_index = color_index(position.side_to_move());
    if (move.is_capture()) {
        const int captured_kings = std::popcount(move.captured_mask() & position.kings());
        score += 1'000'000 + static_cast<int>(move.capture_count) * 20'000 +
            captured_kings * 12'000;
        if (options_.use_capture_history) {
            score += capture_history_[mover_index][move.from][move.to];
        }
        if (options_.use_capture_signature_history) {
            score += capture_signature_history_[mover_index][capture_signature_index(move)];
        }
        if (options_.use_capture_continuation_history && previous_move != nullptr &&
            is_valid_square(previous_move->to)) {
            score += capture_continuation_history_[mover_index][previous_move->to]
                [move.from][move.to] * options_.capture_continuation_weight / 100;
        }
        if (options_.use_recapture_ordering && is_recapture(move, previous_move)) {
            score += options_.recapture_order_bonus;
        }
        score += kCaptureLandingCenterBonus[static_cast<std::size_t>(move.to)];
    }
    if (move.is_promotion()) {
        score += 90'000;
    }
    if (!move.is_capture() && ply < kMaxSearchPly) {
        if (same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][0])) {
            score += 60'000;
        } else if (same_move_identity(move, killer_moves_[static_cast<std::size_t>(ply)][1])) {
            score += 50'000;
        }
        if (options_.use_countermove && previous_move != nullptr &&
            is_valid_square(previous_move->from) && is_valid_square(previous_move->to)) {
            const Move& countermove = countermoves_[color_index(position.side_to_move())]
                [previous_move->from][previous_move->to];
            if (same_move_identity(move, countermove)) {
                score += 55'000;
            }
        }
        score += history_[mover_index][move.from][move.to];
        if (options_.use_continuation_history && previous_move != nullptr &&
            is_valid_square(previous_move->to)) {
            score += continuation_history_[mover_index][previous_move->to][move.from][move.to];
        }
        if (options_.use_followup_history && previous_previous_move != nullptr &&
            is_valid_square(previous_previous_move->to)) {
            score += followup_history_[mover_index][previous_previous_move->to]
                [move.from][move.to] * options_.followup_history_weight / 100;
        }
        if (options_.use_piece_type_history) {
            score += piece_type_history_[mover_index][moving_piece_type_index(move)]
                [move.from][move.to] * options_.piece_type_history_weight / 100;
        }
        if (options_.use_promotion_threat_ordering &&
            creates_immediate_promotion_threat(position, move)) {
            score += options_.promotion_threat_order_bonus;
        }
        if (options_.use_positional_quiet_ordering && options_.quiet_order_weight > 0 &&
            ply <= options_.positional_quiet_max_ply) {
            score += quiet_positional_order_score(position, move) * options_.quiet_order_weight / 100;
        }
        if (options_.use_strategic_quiet_ordering &&
            options_.strategic_quiet_order_weight > 0 &&
            ply <= options_.strategic_quiet_max_ply) {
            const int prior = options_.strategic_quiet_opening_only
                ? strategic_opening_quiet_move_delta(position, move) * 16
                : strategic_quiet_move_delta(position, move) * 16;
            score += prior * options_.strategic_quiet_order_weight / 100;
        }
        if (options_.use_endgame_reply_ordering &&
            options_.endgame_reply_order_weight > 0 &&
            std::popcount(position.occupied()) <= options_.endgame_reply_order_max_pieces) {
            score += endgame_reply_order_score(position, move) *
                options_.endgame_reply_order_weight / 100;
        }
    }
    if (worker_index_ > 0 && is_valid_square(move.from) && is_valid_square(move.to)) {
        std::uint32_t mix = static_cast<std::uint32_t>(move.from) * 0x9E3779B1U;
        mix ^= static_cast<std::uint32_t>(move.to) * 0x85EBCA77U;
        mix ^= static_cast<std::uint32_t>(move.capture_count) * 0xC2B2AE3DU;
        mix ^= static_cast<std::uint32_t>(worker_index_) * 0x27D4EB2FU;
        mix ^= mix >> 16U;
        score += static_cast<int>(mix & 31U);
    }
    return score;
}

int Searcher::quiet_positional_order_score(
    const Position& position,
    const Move& move) const noexcept {
    return score_quiet_move(position, move, options_.quiet_ordering_weights);
}

int Searcher::capped_reply_count(
    const Position& child_position,
    int cap) const {
    MoveList replies;
    generate_legal_moves(child_position, replies);
    return std::min(static_cast<int>(replies.size()), std::max(1, cap));
}

int Searcher::endgame_reply_order_score(
    const Position& position,
    const Move& move) const {
    if (move.is_capture() || (position.kings() & bit(move.from)) == 0) {
        return 0;
    }
    Position child = position;
    UndoState undo{};
    child.make_move_unchecked(move, undo);
    MoveList replies;
    generate_legal_moves(child, replies);
    if (replies.empty()) {
        return 120'000;
    }
    const int reply_count = static_cast<int>(replies.size());
    int score = std::max(0, 16 - reply_count) * 384;
    if (reply_count == 1) score += 8'000;
    else if (reply_count == 2) score += 4'000;
    if (replies[0].is_capture()) score += 2'000;
    return score;
}

void Searcher::update_quiet_heuristics(
    const Position& position,
    Color mover,
    const Move& move,
    int depth,
    int ply,
    const Move* previous_move,
    const Move* previous_previous_move) noexcept {
    if (ply >= kMaxSearchPly) {
        return;
    }
    auto& killers = killer_moves_[static_cast<std::size_t>(ply)];
    if (!same_move_identity(move, killers[0])) {
        killers[1] = killers[0];
        killers[0] = move;
    }

    const std::size_t mover_index = color_index(mover);
    const int bonus = std::min(2'048, depth * depth * 24);
    update_history_value(history_[mover_index][move.from][move.to], bonus);

    if (options_.use_continuation_history && previous_move != nullptr &&
        is_valid_square(previous_move->to)) {
        int continuation_bonus = bonus / 2;
        if (options_.use_strategic_continuation_bias &&
            options_.strategic_continuation_weight > 0) {
            const int prior = strategic_quiet_continuation_prior(
                position, move, previous_move);
            continuation_bonus += std::clamp(
                prior * options_.strategic_continuation_weight / 100, -384, 384);
        }
        update_history_value(
            continuation_history_[mover_index][previous_move->to][move.from][move.to],
            continuation_bonus);
    }

    if (options_.use_followup_history && previous_previous_move != nullptr &&
        is_valid_square(previous_previous_move->to)) {
        update_history_value(
            followup_history_[mover_index][previous_previous_move->to][move.from][move.to],
            bonus / 2);
    }
    if (options_.use_piece_type_history) {
        update_history_value(
            piece_type_history_[mover_index][moving_piece_type_index(move)]
                [move.from][move.to],
            bonus / 2);
    }

    if (options_.use_countermove && previous_move != nullptr &&
        is_valid_square(previous_move->from) && is_valid_square(previous_move->to)) {
        countermoves_[mover_index][previous_move->from][previous_move->to] = move;
    }
}

void Searcher::update_capture_heuristics(
    Color mover,
    const Move& move,
    int depth,
    const Move* previous_move,
    const Move* previous_previous_move) noexcept {
    (void) previous_previous_move;
    if (!move.is_capture()) {
        return;
    }
    const std::size_t mover_index = color_index(mover);
    const int bonus = std::min(2'048, std::max(1, depth) * std::max(1, depth) * 28);
    if (options_.use_capture_history) {
        update_history_value(capture_history_[mover_index][move.from][move.to], bonus);
    }
    if (options_.use_capture_signature_history) {
        update_history_value(
            capture_signature_history_[mover_index][capture_signature_index(move)], bonus);
    }
    if (options_.use_capture_continuation_history && previous_move != nullptr &&
        is_valid_square(previous_move->to)) {
        update_history_value(
            capture_continuation_history_[mover_index][previous_move->to][move.from][move.to],
            bonus);
    }
}

void Searcher::apply_history_malus(
    const Position& position,
    Color mover,
    const Move& move,
    int depth,
    const Move* previous_move,
    const Move* previous_previous_move) noexcept {
    const std::size_t mover_index = color_index(mover);
    int malus = -std::min(1'024, std::max(1, depth) * std::max(1, depth) * 12);
    if (!move.is_capture() && options_.use_strategic_continuation_bias &&
        options_.strategic_continuation_weight > 0) {
        const int prior = strategic_quiet_continuation_prior(
            position, move, previous_move);
        malus += std::clamp(
            prior * options_.strategic_continuation_weight / 100, -192, 192);
        malus = std::min(-1, malus);
    }
    if (move.is_capture()) {
        if (options_.use_capture_history) {
            update_history_value(capture_history_[mover_index][move.from][move.to], malus);
        }
        if (options_.use_capture_signature_history) {
            update_history_value(
                capture_signature_history_[mover_index][capture_signature_index(move)], malus);
        }
        if (options_.use_capture_continuation_history && previous_move != nullptr &&
            is_valid_square(previous_move->to)) {
            update_history_value(
                capture_continuation_history_[mover_index][previous_move->to][move.from][move.to],
                malus);
        }
        return;
    }

    update_history_value(history_[mover_index][move.from][move.to], malus);
    if (options_.use_continuation_history && previous_move != nullptr &&
        is_valid_square(previous_move->to)) {
        update_history_value(
            continuation_history_[mover_index][previous_move->to][move.from][move.to],
            malus / 2);
    }
    if (options_.use_followup_history && previous_previous_move != nullptr &&
        is_valid_square(previous_previous_move->to)) {
        update_history_value(
            followup_history_[mover_index][previous_previous_move->to][move.from][move.to],
            malus / 4);
    }
    if (options_.use_piece_type_history) {
        update_history_value(
            piece_type_history_[mover_index][moving_piece_type_index(move)]
                [move.from][move.to],
            malus / 4);
    }
}

int Searcher::forced_reply_extension(
    Position& position,
    const Move& move,
    bool captured_king,
    int depth,
    int extensions_used) const {
    if (!options_.use_forced_reply_extensions ||
        extensions_used >= options_.tactical_max_extensions ||
        depth <= 0 || depth > 4) {
        return 0;
    }
    const bool forcing_move = move.is_promotion() || captured_king || move.capture_count >= 2;
    if (!forcing_move) {
        return 0;
    }

    MoveList replies;
    generate_legal_moves(position, replies);
    if (replies.size() != 1) {
        return 0;
    }
    return 1;
}

int Searcher::forced_line_extension(
    std::size_t legal_move_count,
    int depth,
    int extensions_used) const noexcept {
    if (!options_.use_forced_line_extensions ||
        options_.tactical_max_extensions <= 0 ||
        extensions_used >= options_.tactical_max_extensions ||
        depth <= 0 || depth > options_.forced_line_extension_max_depth) {
        return 0;
    }
    return legal_move_count == 1 ? 1 : 0;
}

int Searcher::quiet_sacrifice_extension(
    const Position& child_position,
    const Move& move,
    int depth,
    int extensions_used,
    bool* forces_capture) const {
    if (forces_capture != nullptr) {
        *forces_capture = false;
    }
    if (move.is_capture() ||
        (!options_.use_forcing_quiet_lmr_guard && !options_.use_quiet_sacrifice_extensions)) {
        return 0;
    }

    const bool opponent_must_capture = has_any_capture(child_position);
    if (forces_capture != nullptr) {
        *forces_capture = opponent_must_capture;
    }
    if (!options_.use_quiet_sacrifice_extensions || !opponent_must_capture ||
        options_.tactical_max_extensions <= 0 ||
        extensions_used >= options_.tactical_max_extensions || depth <= 0 ||
        depth > options_.quiet_sacrifice_extension_max_depth) {
        return 0;
    }

    MoveList replies;
    generate_legal_moves(child_position, replies);
    return replies.size() == 1 ? 1 : 0;
}

bool Searcher::is_recapture(
    const Move& move,
    const Move* previous_move) const noexcept {
    return move.is_capture() && previous_move != nullptr && previous_move->is_capture() &&
        is_valid_square(previous_move->to) &&
        (move.captured_mask() & bit(previous_move->to)) != 0;
}

int Searcher::recapture_extension(
    const Move& move,
    const Move* previous_move,
    int depth,
    int extensions_used) const noexcept {
    if (!options_.use_recapture_extensions ||
        options_.tactical_max_extensions <= 0 ||
        extensions_used >= options_.tactical_max_extensions ||
        depth <= 0 || depth > options_.recapture_extension_max_depth) {
        return 0;
    }
    return is_recapture(move, previous_move) ? 1 : 0;
}

int Searcher::tactical_extension(
    const Position& position,
    const Move& move,
    std::size_t legal_move_count,
    int depth,
    int extensions_used) const noexcept {
    if (options_.tactical_max_extensions <= 0 ||
        extensions_used >= options_.tactical_max_extensions || depth <= 0) {
        return 0;
    }
    if (options_.use_phase28_extension_policy) {
        if (options_.use_promotion_extensions && move.is_promotion() &&
            depth <= options_.promotion_extension_max_depth) {
            const bool legacy_depth = depth <= 4;
            const bool phase_extra_allowed = options_.use_phase_aware_promotion_extension &&
                root_piece_count_ <= options_.promotion_extension_extra_max_pieces &&
                root_king_count_ <= options_.promotion_extension_extra_max_kings;
            if (legacy_depth || phase_extra_allowed) {
                return 1;
            }
        }
        if (options_.use_single_reply_extensions && legal_move_count == 1 &&
            depth <= options_.single_reply_extension_max_depth &&
            (!options_.single_reply_quiet_only || !move.is_capture())) {
            return 1;
        }
        return 0;
    }
    if (!options_.use_tactical_extensions) {
        if (move.is_promotion() && depth <= 4) {
            return 1;
        }
        return legal_move_count == 1 && depth <= 2 ? 1 : 0;
    }
    if (move.is_promotion() && depth <= 5) {
        return 1;
    }
    if (legal_move_count == 1 && depth <= 3) {
        return 1;
    }
    if (move.is_capture() && depth <= 2) {
        const bool captures_king = (move.captured_mask() & position.kings()) != 0;
        if (move.capture_count >= 2 || captures_king) {
            return 1;
        }
    }
    return 0;
}

std::size_t Searcher::capture_signature_index(const Move& move) const noexcept {
    std::uint64_t value = static_cast<std::uint64_t>(move.captured_mask());
    value ^= static_cast<std::uint64_t>(move.from) * 0x9E3779B185EBCA87ULL;
    value ^= static_cast<std::uint64_t>(move.to) * 0xC2B2AE3D27D4EB4FULL;
    value ^= static_cast<std::uint64_t>(move.capture_count) * 0x165667B19E3779F9ULL;
    value ^= value >> 29U;
    value *= 0xBF58476D1CE4E5B9ULL;
    value ^= value >> 32U;
    return static_cast<std::size_t>(value) & 4095U;
}

void Searcher::initialize_nnue_accumulator(const Position& root) noexcept {
    nnue_incremental_active_ = options_.use_incremental_nnue && options_.nnue.enabled &&
        options_.nnue.blend_percent > 0 && static_cast<bool>(options_.nnue.model);
    nnue_accumulator_ready_.fill(false);
    if (nnue_incremental_active_) {
        nnue_accumulator_stack_[0].refresh(root, *options_.nnue.model);
        nnue_accumulator_ready_[0] = true;
    }
}

void Searcher::record_nnue_child(
    const Position& parent,
    const Move& move,
    int child_ply) noexcept {
    if (!nnue_incremental_active_ || !options_.nnue.model || child_ply <= 0 ||
        child_ply > kMaxSearchPly) {
        return;
    }
    const std::size_t index = static_cast<std::size_t>(child_ply);
    nnue_move_stack_[index] = move;
    nnue_parent_kings_stack_[index] = parent.kings();
    nnue_mover_stack_[index] = parent.side_to_move();
    nnue_accumulator_ready_[index] = false;
}

const NnueAccumulator* Searcher::ensure_nnue_accumulator(
    const Position& position,
    int ply) noexcept {
    if (!nnue_incremental_active_ || !options_.nnue.model || ply < 0 ||
        ply > kMaxSearchPly) {
        return nullptr;
    }
    const std::size_t target = static_cast<std::size_t>(ply);
    if (nnue_accumulator_ready_[target]) {
        return &nnue_accumulator_stack_[target];
    }
    int ancestor = ply;
    while (ancestor >= 0 &&
        !nnue_accumulator_ready_[static_cast<std::size_t>(ancestor)]) {
        --ancestor;
    }
    if (ancestor < 0) return nullptr;
    for (int current = ancestor + 1; current <= ply; ++current) {
        const std::size_t index = static_cast<std::size_t>(current);
        nnue_accumulator_stack_[index] = nnue_accumulator_stack_[index - 1U];
        const NnueFeatureDelta delta = nnue_move_delta(
            nnue_mover_stack_[index], nnue_parent_kings_stack_[index],
            nnue_move_stack_[index]);
        nnue_accumulator_stack_[index].apply_delta(delta, *options_.nnue.model);
        nnue_accumulator_ready_[index] = true;
        ++diagnostics_.nnue_incremental_updates;
    }
    return &nnue_accumulator_stack_[target];
}

Score Searcher::evaluate_cached(const Position& position, int ply) noexcept {
    ++diagnostics_.evaluation_calls;
    const auto evaluate_uncached = [&]() noexcept {
        const Score hce_score = use_default_evaluation_
            ? evaluate_default(position)
            : evaluate(position, options_.evaluation_weights);
        const NnueAccumulator* accumulator = ensure_nnue_accumulator(position, ply);
        const NnueRuntimeEvaluation runtime =
            evaluate_with_nnue_fallback(position, hce_score, options_.nnue, accumulator);
        diagnostics_.nnue_evaluations += runtime.used_nnue ? 1U : 0U;
        if (runtime.used_nnue) {
            if (accumulator != nullptr) ++diagnostics_.nnue_incremental_evaluations;
            else ++diagnostics_.nnue_full_refresh_evaluations;
        }
        diagnostics_.nnue_fallback_evaluations += runtime.used_fallback ? 1U : 0U;
        return runtime.score;
    };
    if (!options_.use_evaluation_cache) return evaluate_uncached();
    const HashKey key = position.key();
    EvaluationCacheEntry& entry = evaluation_cache_[
        static_cast<std::size_t>(key) & (kEvaluationCacheSize - 1U)];
    if (entry.valid && entry.key == key) {
        ++diagnostics_.evaluation_cache_hits;
        return entry.score;
    }
    const Score score = evaluate_uncached();
    entry.key = key;
    entry.score = score;
    entry.valid = true;
    return score;
}

void Searcher::update_pv(int ply, const Move& move) noexcept {
    if (ply >= kMaxSearchPly - 1) {
        return;
    }
    pv_table_[static_cast<std::size_t>(ply)][static_cast<std::size_t>(ply)] = move;
    const int child_length = pv_length_[static_cast<std::size_t>(ply + 1)];
    for (int index = ply + 1; index < child_length; ++index) {
        pv_table_[static_cast<std::size_t>(ply)][static_cast<std::size_t>(index)] =
            pv_table_[static_cast<std::size_t>(ply + 1)][static_cast<std::size_t>(index)];
    }
    pv_length_[static_cast<std::size_t>(ply)] = std::max(ply + 1, child_length);
}

void Searcher::clear_search_state() noexcept {
    nnue_incremental_active_ = false;
    nodes_.store(0, std::memory_order_relaxed);
    selective_depth_.store(0, std::memory_order_relaxed);
    local_nodes_ = 0;
    published_nodes_ = 0;
    local_selective_depth_ = 0;
    published_selective_depth_ = 0;
    pv_length_.fill(0);
    killer_moves_ = {};
    history_ = {};
    capture_history_ = {};
    capture_signature_history_ = {};
    capture_continuation_history_ = {};
    continuation_history_ = {};
    followup_history_ = {};
    piece_type_history_ = {};
    countermoves_ = {};
    evaluation_cache_ = {};
    iterative_pv_move_.reset();
    tt_probes_ = 0;
    tt_hits_ = 0;
    tt_cutoffs_ = 0;
    tt_stores_ = 0;
    diagnostics_ = {};
}

void Searcher::count_node(int ply) noexcept {
    ++local_nodes_;
    local_selective_depth_ = std::max(local_selective_depth_, ply);

    SharedSearchState* state = session_state();
    if (limits_.nodes > 0 && state != nullptr && state->configured_threads > 1) {
        // Node-limited SMP searches need an exact global counter so all workers
        // observe the limit with only a few in-flight nodes of overshoot.
        state->nodes.fetch_add(1, std::memory_order_relaxed);
        published_nodes_ = local_nodes_;
        nodes_.store(local_nodes_, std::memory_order_relaxed);
    } else if ((local_nodes_ - published_nodes_) >= kNodePublishInterval) {
        flush_node_counters();
    }
}

void Searcher::flush_node_counters() noexcept {
    const std::uint64_t node_delta = local_nodes_ - published_nodes_;
    if (node_delta != 0) {
        nodes_.store(local_nodes_, std::memory_order_relaxed);
        if (SharedSearchState* state = session_state()) {
            state->nodes.fetch_add(node_delta, std::memory_order_relaxed);
        }
        published_nodes_ = local_nodes_;
    }

    if (local_selective_depth_ > published_selective_depth_) {
        selective_depth_.store(local_selective_depth_, std::memory_order_relaxed);
        if (SharedSearchState* state = session_state()) {
            int shared_depth = state->selective_depth.load(std::memory_order_relaxed);
            while (shared_depth < local_selective_depth_ &&
                   !state->selective_depth.compare_exchange_weak(
                       shared_depth,
                       local_selective_depth_,
                       std::memory_order_relaxed,
                       std::memory_order_relaxed)) {}
        }
        published_selective_depth_ = local_selective_depth_;
    }
}

bool Searcher::control_check_due() const noexcept {
    if (limits_.nodes > 0 || (local_nodes_ % kControlCheckInterval) == 0) {
        return true;
    }
    if (stop_requested_.load(std::memory_order_relaxed) ||
        pause_requested_.load(std::memory_order_relaxed) ||
        external_stop_token_.stop_requested()) {
        return true;
    }
    SharedSearchState* state = session_state();
    if (state != nullptr &&
        (state->stop_requested.load(std::memory_order_relaxed) ||
         state->pause_requested.load(std::memory_order_relaxed))) {
        return true;
    }
    return external_pause_requested_ != nullptr &&
        external_pause_requested_->load(std::memory_order_relaxed);
}

std::uint64_t Searcher::reported_nodes() const noexcept {
    return shared_state()
        ? shared_state()->nodes.load(std::memory_order_relaxed)
        : nodes_.load(std::memory_order_relaxed);
}

int Searcher::reported_selective_depth() const noexcept {
    return shared_state()
        ? shared_state()->selective_depth.load(std::memory_order_relaxed)
        : selective_depth_.load(std::memory_order_relaxed);
}

bool Searcher::all_active_threads_paused() const noexcept {
    if (!shared_state()) {
        return paused_active_.load(std::memory_order_acquire);
    }
    const int active = shared_state()->active_threads.load(std::memory_order_acquire);
    const int paused = shared_state()->paused_threads.load(std::memory_order_acquire);
    return active > 0 && paused >= active;
}

void Searcher::publish_helper_root_hint(
    int depth, Score score, const Move& move) noexcept {
    SharedSearchState* state = session_state();
    if (worker_index_ <= 0 || state == nullptr) {
        return;
    }
    state->helper_iterations.fetch_add(1, std::memory_order_relaxed);
    std::lock_guard hint_lock(state->root_hint_mutex);
    const bool replace = !state->root_hint.has_value() || depth > state->root_hint_depth ||
        (depth == state->root_hint_depth && worker_index_ < state->root_hint_worker);
    if (!replace) {
        return;
    }
    state->root_hint = move;
    state->root_hint_score = score;
    state->root_hint_depth = depth;
    state->root_hint_worker = worker_index_;
    state->root_hint_updates.fetch_add(1, std::memory_order_relaxed);
}

std::optional<Move> Searcher::shared_root_hint(int requested_depth) noexcept {
    SharedSearchState* state = session_state();
    if (worker_index_ != 0 || state == nullptr || state->configured_threads <= 1) {
        return std::nullopt;
    }
    std::lock_guard hint_lock(state->root_hint_mutex);
    // Only consume a helper result that has already reached the master's requested
    // depth. Shallower hints would merely displace the master's proven previous PV.
    if (!state->root_hint.has_value() || state->root_hint_depth < requested_depth) {
        return std::nullopt;
    }
    state->root_hint_uses.fetch_add(1, std::memory_order_relaxed);
    return state->root_hint;
}

void Searcher::apply_shared_smp_diagnostics(SearchDiagnostics& diagnostics) const noexcept {
    auto state = shared_state();
    if (state == nullptr) {
        return;
    }
    diagnostics.smp_helpers_started = static_cast<std::uint64_t>(
        std::max(0, state->configured_threads - 1));
    diagnostics.smp_helper_iterations =
        state->helper_iterations.load(std::memory_order_relaxed);
    diagnostics.smp_root_hint_updates =
        state->root_hint_updates.load(std::memory_order_relaxed);
    diagnostics.smp_root_hint_uses =
        state->root_hint_uses.load(std::memory_order_relaxed);
    diagnostics.smp_synchronized_starts =
        state->synchronized_starts.load(std::memory_order_relaxed);
}

void Searcher::publish_completed_iteration(
    int depth,
    Score score,
    const std::vector<Move>& pv,
    const std::vector<PrincipalVariationLine>& multipv) {
    SearchInfo snapshot{};
    snapshot.depth = depth;
    snapshot.selective_depth = reported_selective_depth();
    snapshot.score = score;
    snapshot.nodes = reported_nodes();
    snapshot.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - start_time_);
    snapshot.nodes_per_second = snapshot.elapsed.count() > 0
        ? snapshot.nodes * 1000ULL / static_cast<std::uint64_t>(snapshot.elapsed.count())
        : snapshot.nodes;
    snapshot.principal_variation = pv;
    snapshot.multipv = multipv;
    snapshot.transposition_table = current_tt_statistics();
    snapshot.diagnostics = diagnostics_;
    apply_shared_smp_diagnostics(snapshot.diagnostics);
    snapshot.threads = shared_state() ? shared_state()->configured_threads : 1;
    snapshot.active_threads = shared_state()
        ? shared_state()->active_threads.load(std::memory_order_acquire)
        : 1;
    snapshot.target_threads = shared_state()
        ? shared_state()->active_thread_limit.load(std::memory_order_acquire)
        : 1;
    snapshot.parked_threads = shared_state()
        ? shared_state()->parked_threads.load(std::memory_order_acquire)
        : 0;
    snapshot.searching = true;
    snapshot.paused = all_active_threads_paused();

    {
        std::lock_guard lock(info_mutex_);
        info_ = snapshot;
    }
    if (callback_) {
        callback_(snapshot);
    }
}

bool Searcher::check_control() {
    SharedSearchState* const state = session_state();
    if (external_stop_token_.stop_requested() ||
        (state != nullptr && state->stop_requested.load(std::memory_order_acquire))) {
        stop_requested_.store(true, std::memory_order_release);
    }
    if (hard_limit_reached()) {
        stop_requested_.store(true, std::memory_order_release);
        if (state != nullptr) {
            state->stop_requested.store(true, std::memory_order_release);
        }
    }
    if (stop_requested_.load(std::memory_order_acquire)) {
        return true;
    }

    if (worker_index_ > 0 && state != nullptr) {
        const auto should_park = [&] {
            return worker_index_ >= state->active_thread_limit.load(std::memory_order_acquire);
        };
        if (should_park()) {
            if (!policy_parked_.exchange(true, std::memory_order_acq_rel)) {
                state->active_threads.fetch_sub(1, std::memory_order_acq_rel);
                state->parked_threads.fetch_add(1, std::memory_order_acq_rel);
            }
            std::unique_lock lock(state->thread_policy_mutex);
            state->thread_policy_condition.wait(lock, [&] {
                return !should_park() ||
                    stop_requested_.load(std::memory_order_acquire) ||
                    state->stop_requested.load(std::memory_order_acquire) ||
                    external_stop_token_.stop_requested();
            });
            if (!should_park() && policy_parked_.exchange(false, std::memory_order_acq_rel)) {
                state->parked_threads.fetch_sub(1, std::memory_order_acq_rel);
                state->active_threads.fetch_add(1, std::memory_order_acq_rel);
            }
            if (stop_requested_.load(std::memory_order_acquire) ||
                state->stop_requested.load(std::memory_order_acquire) ||
                external_stop_token_.stop_requested()) {
                return true;
            }
        }
    }

    const auto pause_is_requested = [&] {
        return pause_requested_.load(std::memory_order_acquire) ||
            (state != nullptr && state->pause_requested.load(std::memory_order_acquire)) ||
            (external_pause_requested_ != nullptr &&
             external_pause_requested_->load(std::memory_order_acquire));
    };
    if (pause_is_requested()) {
        const auto pause_started = std::chrono::steady_clock::now();
        if (!paused_active_.exchange(true, std::memory_order_acq_rel) && state != nullptr) {
            state->paused_threads.fetch_add(1, std::memory_order_acq_rel);
        }
        {
            std::lock_guard lock(info_mutex_);
            info_.paused = all_active_threads_paused();
        }
        std::unique_lock lock(control_mutex_);
        control_condition_.wait(lock, [&] {
            return !pause_is_requested() ||
                stop_requested_.load(std::memory_order_acquire) ||
                (state != nullptr && state->stop_requested.load(std::memory_order_acquire)) ||
                external_stop_token_.stop_requested();
        });
        const auto pause_duration = std::chrono::steady_clock::now() - pause_started;
        if (limits_.move_time.count() > 0 && !stop_requested_.load(std::memory_order_acquire)) {
            deadline_ += pause_duration;
        }
        if (paused_active_.exchange(false, std::memory_order_acq_rel) && state != nullptr) {
            state->paused_threads.fetch_sub(1, std::memory_order_acq_rel);
        }
        {
            std::lock_guard info_lock(info_mutex_);
            info_.paused = false;
        }
    }
    if (state != nullptr && state->stop_requested.load(std::memory_order_acquire)) {
        stop_requested_.store(true, std::memory_order_release);
    }
    return stop_requested_.load(std::memory_order_acquire);
}

bool Searcher::hard_limit_reached() const noexcept {
    if (limits_.nodes > 0) {
        const SharedSearchState* state = session_state();
        const std::uint64_t nodes = state != nullptr && state->configured_threads > 1
            ? state->nodes.load(std::memory_order_relaxed)
            : local_nodes_;
        if (nodes >= limits_.nodes) {
            return true;
        }
    }
    return limits_.move_time.count() > 0 && std::chrono::steady_clock::now() >= deadline_;
}

std::vector<Move> Searcher::current_pv() const {
    std::vector<Move> result;
    const int length = std::clamp(pv_length_[0], 0, kMaxSearchPly);
    result.reserve(static_cast<std::size_t>(length));
    for (int index = 0; index < length; ++index) {
        result.push_back(pv_table_[0][static_cast<std::size_t>(index)]);
    }
    return result;
}

std::vector<Move> Searcher::child_pv(int ply) const {
    std::vector<Move> result;
    if (ply < 0 || ply >= kMaxSearchPly) {
        return result;
    }
    const int length = std::clamp(pv_length_[static_cast<std::size_t>(ply)], ply, kMaxSearchPly);
    result.reserve(static_cast<std::size_t>(std::max(0, length - ply)));
    for (int index = ply; index < length; ++index) {
        result.push_back(pv_table_[static_cast<std::size_t>(ply)][static_cast<std::size_t>(index)]);
    }
    return result;
}

HashKey Searcher::transposition_key(const Position& position) const noexcept {
    HashKey key = position.key() ^ mix_counter(position.no_progress_plies());
    if (options_.nnue.enabled && options_.nnue.model && options_.nnue.blend_percent > 0) {
        const HashKey signature = options_.nnue.model->metadata().payload_checksum ^
            (static_cast<HashKey>(options_.nnue.blend_percent) << 48U) ^
            0x4E4E554533370001ULL;
        key ^= mix_hash_value(signature);
    }
    return key;
}

bool Searcher::transposition_allowed(const Position& position) const noexcept {
    return position.repetition_count() <= 1;
}

bool Searcher::probe_tt(HashKey key, TTEntry& entry) noexcept {
    ++tt_probes_;
    SharedSearchState* state = session_state();
    const bool multi_threaded = state != nullptr && state->configured_threads > 1;
    if (multi_threaded) {
        state->tt_probes.fetch_add(1, std::memory_order_relaxed);
    }
    const bool hit = multi_threaded
        ? transposition_table_->probe(key, entry)
        : transposition_table_->probe_single_thread(key, entry);
    if (hit) {
        ++tt_hits_;
        if (multi_threaded) {
            state->tt_hits.fetch_add(1, std::memory_order_relaxed);
        }
        return true;
    }
    return false;
}

void Searcher::store_tt(
    HashKey key,
    int depth,
    Score score,
    TTBound bound,
    const Move* best_move) noexcept {
    SharedSearchState* state = session_state();
    const bool multi_threaded = state != nullptr && state->configured_threads > 1;
    if (multi_threaded) {
        transposition_table_->store(key, depth, score, bound, best_move);
    } else {
        transposition_table_->store_single_thread(key, depth, score, bound, best_move);
    }
    ++tt_stores_;
    if (multi_threaded) {
        state->tt_stores.fetch_add(1, std::memory_order_relaxed);
    }
}

TTStatistics Searcher::current_tt_statistics() const noexcept {
    TTStatistics result{};
    auto state = shared_state();
    if (state != nullptr && state->configured_threads > 1) {
        result.probes = state->tt_probes.load(std::memory_order_relaxed);
        result.hits = state->tt_hits.load(std::memory_order_relaxed);
        result.cutoffs = state->tt_cutoffs.load(std::memory_order_relaxed);
        result.stores = state->tt_stores.load(std::memory_order_relaxed);
    } else {
        result.probes = tt_probes_;
        result.hits = tt_hits_;
        result.cutoffs = tt_cutoffs_;
        result.stores = tt_stores_;
    }
    {
        std::lock_guard lock(tt_lifecycle_mutex_);
        result.hashfull_per_mille = transposition_table_->hashfull_per_mille();
    }
    return result;
}

void Searcher::stop_helpers() noexcept {
    std::lock_guard lock(helpers_mutex_);
    for (Searcher* helper : active_helpers_) {
        if (helper != nullptr) {
            helper->stop();
        }
    }
}

void Searcher::pause_helpers() noexcept {
    std::lock_guard lock(helpers_mutex_);
    for (Searcher* helper : active_helpers_) {
        if (helper != nullptr) {
            helper->pause();
        }
    }
}

void Searcher::resume_helpers() noexcept {
    std::lock_guard lock(helpers_mutex_);
    for (Searcher* helper : active_helpers_) {
        if (helper != nullptr) {
            helper->resume();
        }
    }
}

void Searcher::notify_helpers() noexcept {
    std::lock_guard lock(helpers_mutex_);
    for (Searcher* helper : active_helpers_) {
        if (helper != nullptr) {
            helper->control_condition_.notify_all();
        }
    }
}

void Searcher::stop() noexcept {
    stop_requested_.store(true, std::memory_order_release);
    if (auto state = shared_state()) {
        state->stop_requested.store(true, std::memory_order_release);
        state->thread_policy_condition.notify_all();
    }
    control_condition_.notify_all();
    stop_helpers();
}

void Searcher::pause() noexcept {
    pause_requested_.store(true, std::memory_order_release);
    if (shared_state()) {
        shared_state()->pause_requested.store(true, std::memory_order_release);
    }
    pause_helpers();
}

void Searcher::resume() noexcept {
    pause_requested_.store(false, std::memory_order_release);
    if (shared_state()) {
        shared_state()->pause_requested.store(false, std::memory_order_release);
    }
    control_condition_.notify_all();
    resume_helpers();
}

void Searcher::set_active_thread_limit(int threads) noexcept {
    auto state = shared_state();
    if (state == nullptr) {
        return;
    }
    {
        std::lock_guard lock(state->thread_policy_mutex);
        state->active_thread_limit.store(
            std::clamp(threads, 1, state->configured_threads), std::memory_order_release);
    }
    state->thread_policy_condition.notify_all();
}

void Searcher::clear_hash() noexcept {
    if (!is_searching()) {
        std::lock_guard lock(tt_lifecycle_mutex_);
        transposition_table_->clear();
    }
}

void Searcher::set_hash_size_mb(std::size_t size_mb) {
    if (is_searching()) {
        throw std::logic_error("Cannot resize Albay hash while searching");
    }
    std::lock_guard lock(tt_lifecycle_mutex_);
    transposition_table_->resize(size_mb);
}

bool Searcher::is_searching() const noexcept {
    return helper_instance_
        ? searching_.load(std::memory_order_acquire)
        : session_active_.load(std::memory_order_acquire);
}

bool Searcher::is_paused() const noexcept {
    return all_active_threads_paused();
}

SearchInfo Searcher::info() const {
    std::lock_guard lock(info_mutex_);
    SearchInfo snapshot = info_;
    const bool live_search = is_searching();
    // While a search is running, expose live shared counters. After completion,
    // preserve the authoritative values published into info_ by search(). This
    // matters for exact root tablebase hits: helpers may have visited a node
    // speculatively, but the completed master result is still a zero-node exact
    // lookup and must remain visible through the polling/C API contract.
    if (live_search) {
        snapshot.nodes = reported_nodes();
        snapshot.selective_depth = reported_selective_depth();
        snapshot.threads = shared_state() ? shared_state()->configured_threads : 1;
        snapshot.active_threads = shared_state()
            ? shared_state()->active_threads.load(std::memory_order_acquire)
            : (searching_.load(std::memory_order_acquire) ? 1 : 0);
        snapshot.target_threads = shared_state()
            ? shared_state()->active_thread_limit.load(std::memory_order_acquire)
            : 1;
        snapshot.parked_threads = shared_state()
            ? shared_state()->parked_threads.load(std::memory_order_acquire)
            : 0;
    } else {
        snapshot.active_threads = 0;
        snapshot.parked_threads = 0;
        snapshot.target_threads = std::max(1, snapshot.target_threads);
    }
    snapshot.searching = live_search;
    snapshot.paused = live_search && all_active_threads_paused();
    // TT counters are deliberately plain integers in the single-thread hot path.
    // They are published into `info_` at completed-iteration and final-result
    // boundaries while holding `info_mutex_`. Never inspect the live counters
    // from a polling thread: a new search may be clearing them before
    // `searching_` becomes visible. The cached snapshot is race-free and avoids
    // adding atomics to every TT probe/store.
    // `session_active_` becomes true slightly before the master worker has
    // initialized `start_time_`. Read the live clock only after the internal
    // search loop publishes `searching_`, avoiding an early polling race.
    if (searching_.load(std::memory_order_acquire)) {
        snapshot.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start_time_);
    }
    if (snapshot.elapsed.count() > 0) {
        snapshot.nodes_per_second = snapshot.nodes * 1000ULL /
            static_cast<std::uint64_t>(snapshot.elapsed.count());
    } else {
        snapshot.nodes_per_second = snapshot.nodes;
    }
    return snapshot;
}

std::size_t Searcher::hash_size_mb() const noexcept {
    std::lock_guard lock(tt_lifecycle_mutex_);
    return transposition_table_->size_mb();
}

}  // namespace albay
