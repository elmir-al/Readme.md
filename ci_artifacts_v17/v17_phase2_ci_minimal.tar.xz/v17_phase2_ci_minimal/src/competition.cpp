/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/competition.hpp"

#include "albay/notation.hpp"

#include <algorithm>
#include <charconv>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <set>
#include <sstream>
#include <string_view>

namespace albay {
namespace {

[[nodiscard]] std::string trim(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

[[nodiscard]] std::vector<std::string> split_tabs(const std::string& line) {
    std::vector<std::string> fields;
    std::size_t start = 0;
    while (start <= line.size()) {
        const std::size_t end = line.find('\t', start);
        fields.push_back(trim(line.substr(
            start, end == std::string::npos ? line.size() - start : end - start)));
        if (end == std::string::npos) break;
        start = end + 1;
    }
    return fields;
}

template <typename Integer>
[[nodiscard]] bool parse_integer(std::string_view text, Integer& value) {
    const auto [pointer, error] = std::from_chars(text.data(), text.data() + text.size(), value);
    return error == std::errc{} && pointer == text.data() + text.size();
}

[[nodiscard]] bool parse_double_value(const std::string& text, double& value) {
    try {
        std::size_t consumed = 0;
        value = std::stod(text, &consumed);
        return consumed == text.size() && std::isfinite(value);
    } catch (...) {
        return false;
    }
}

[[nodiscard]] bool set_error(std::string* error, std::string message) {
    if (error != nullptr) *error = std::move(message);
    return false;
}

}  // namespace

bool load_opening_suite(
    std::istream& input,
    std::vector<OpeningPosition>& openings,
    std::string* error) {
    openings.clear();
    std::set<std::string> ids;
    std::string line;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned.front() == '#') continue;
        const auto fields = split_tabs(cleaned);
        if (fields.size() < 2 || fields.size() > 3) {
            return set_error(error, "line " + std::to_string(line_number) +
                ": expected id, APF and optional move sequence");
        }
        if (fields[0].empty() || !ids.insert(fields[0]).second) {
            return set_error(error, "line " + std::to_string(line_number) +
                ": opening id is empty or duplicated");
        }
        std::string parse_error;
        const auto position = parse_apf(fields[1], &parse_error);
        if (!position.has_value()) {
            return set_error(error, "line " + std::to_string(line_number) + ": " + parse_error);
        }
        if (position->game_result() != GameResult::Ongoing) {
            return set_error(error, "line " + std::to_string(line_number) +
                ": opening position is already terminal");
        }
        OpeningPosition opening{};
        opening.id = fields[0];
        opening.position = *position;
        if (fields.size() == 3) opening.move_sequence = fields[2];
        openings.push_back(std::move(opening));
    }
    if (openings.empty()) return set_error(error, "opening suite contains no positions");
    return true;
}

bool load_opening_suite_file(
    const std::string& path,
    std::vector<OpeningPosition>& openings,
    std::string* error) {
    std::ifstream input(path);
    if (!input) return set_error(error, "cannot open opening suite: " + path);
    return load_opening_suite(input, openings, error);
}

bool validate_sprt_config(const SprtConfig& config) noexcept {
    return std::isfinite(config.elo0) && std::isfinite(config.elo1) &&
        config.elo0 < config.elo1 && config.alpha > 0.0 && config.alpha < 1.0 &&
        config.beta > 0.0 && config.beta < 1.0;
}

double elo_expected_score(double elo) noexcept {
    return 1.0 / (1.0 + std::pow(10.0, -elo / 400.0));
}

double sprt_lower_boundary(const SprtConfig& config) noexcept {
    return std::log(config.beta / (1.0 - config.alpha));
}

double sprt_upper_boundary(const SprtConfig& config) noexcept {
    return std::log((1.0 - config.beta) / config.alpha);
}

double sprt_score_increment(double score, const SprtConfig& config) noexcept {
    const double bounded_score = std::clamp(score, 0.0, 1.0);
    constexpr double epsilon = 1.0e-12;
    const double p0 = std::clamp(elo_expected_score(config.elo0), epsilon, 1.0 - epsilon);
    const double p1 = std::clamp(elo_expected_score(config.elo1), epsilon, 1.0 - epsilon);
    return bounded_score * std::log(p1 / p0) +
        (1.0 - bounded_score) * std::log((1.0 - p1) / (1.0 - p0));
}

void update_sprt(SprtState& state, double score, const SprtConfig& config) noexcept {
    const double bounded_score = std::clamp(score, 0.0, 1.0);
    if (bounded_score >= 0.75) ++state.wins;
    else if (bounded_score <= 0.25) ++state.losses;
    else ++state.draws;
    state.points += bounded_score;
    state.llr += sprt_score_increment(bounded_score, config);
}

SprtDecision sprt_decision(const SprtState& state, const SprtConfig& config) noexcept {
    if (state.llr <= sprt_lower_boundary(config)) return SprtDecision::AcceptNull;
    if (state.llr >= sprt_upper_boundary(config)) return SprtDecision::AcceptAlternative;
    return SprtDecision::Continue;
}

const char* sprt_decision_name(SprtDecision decision) noexcept {
    switch (decision) {
        case SprtDecision::Continue: return "continue";
        case SprtDecision::AcceptNull: return "accept_h0";
        case SprtDecision::AcceptAlternative: return "accept_h1";
    }
    return "continue";
}

namespace {

[[nodiscard]] double score_to_elo(double score) noexcept {
    constexpr double epsilon = 1.0e-9;
    const double bounded = std::clamp(score, epsilon, 1.0 - epsilon);
    return 400.0 * std::log10(bounded / (1.0 - bounded));
}

}  // namespace

void PairedScoreStatistics::add(double pair_score) noexcept {
    const double bounded = std::clamp(pair_score, 0.0, 2.0);
    const auto index = static_cast<std::size_t>(std::llround(bounded * 2.0));
    ++bins[std::min<std::size_t>(index, bins.size() - 1)];
}

std::uint64_t PairedScoreStatistics::pairs() const noexcept {
    std::uint64_t total = 0;
    for (const std::uint64_t count : bins) total += count;
    return total;
}

double PairedScoreStatistics::total_points() const noexcept {
    double total = 0.0;
    for (std::size_t index = 0; index < bins.size(); ++index) {
        total += static_cast<double>(bins[index]) * (static_cast<double>(index) * 0.5);
    }
    return total;
}

double PairedScoreStatistics::mean_game_score() const noexcept {
    const std::uint64_t count = pairs();
    return count == 0 ? 0.5 : total_points() / (2.0 * static_cast<double>(count));
}

double PairedScoreStatistics::standard_error_game_score() const noexcept {
    const std::uint64_t count = pairs();
    if (count < 2) return 0.0;
    const double mean_pair = total_points() / static_cast<double>(count);
    double sum_squared = 0.0;
    for (std::size_t index = 0; index < bins.size(); ++index) {
        const double value = static_cast<double>(index) * 0.5;
        const double delta = value - mean_pair;
        sum_squared += static_cast<double>(bins[index]) * delta * delta;
    }
    const double sample_variance = sum_squared / static_cast<double>(count - 1);
    return std::sqrt(sample_variance / static_cast<double>(count)) / 2.0;
}

double PairedScoreStatistics::elo_estimate() const noexcept {
    return score_to_elo(mean_game_score());
}

double PairedScoreStatistics::elo_lower_95() const noexcept {
    const double score = mean_game_score() - 1.959963984540054 * standard_error_game_score();
    return score_to_elo(std::clamp(score, 0.0, 1.0));
}

double PairedScoreStatistics::elo_upper_95() const noexcept {
    const double score = mean_game_score() + 1.959963984540054 * standard_error_game_score();
    return score_to_elo(std::clamp(score, 0.0, 1.0));
}

bool save_match_checkpoint_atomic(
    const std::string& path,
    const MatchCheckpoint& checkpoint,
    std::string* error) {
    namespace fs = std::filesystem;
    const fs::path target(path);
    const fs::path temporary = target.string() + ".tmp";
    std::ofstream output(temporary, std::ios::trunc);
    if (!output) return set_error(error, "cannot write checkpoint temporary file: " + temporary.string());
    output << "format_version=" << checkpoint.format_version << '\n'
           << "run_fingerprint=" << checkpoint.run_fingerprint << '\n'
           << "completed_pairs=" << checkpoint.completed_pairs << '\n'
           << "wins=" << checkpoint.sprt.wins << '\n'
           << "draws=" << checkpoint.sprt.draws << '\n'
           << "losses=" << checkpoint.sprt.losses << '\n'
           << std::setprecision(17)
           << "points=" << checkpoint.sprt.points << '\n'
           << "llr=" << checkpoint.sprt.llr << '\n'
           << "max_ply_adjudications=" << checkpoint.max_ply_adjudications << '\n'
           << "nodes_a=" << checkpoint.nodes_a << '\n'
           << "nodes_b=" << checkpoint.nodes_b << '\n'
           << "pair_score_0=" << checkpoint.paired.bins[0] << '\n'
           << "pair_score_0_5=" << checkpoint.paired.bins[1] << '\n'
           << "pair_score_1=" << checkpoint.paired.bins[2] << '\n'
           << "pair_score_1_5=" << checkpoint.paired.bins[3] << '\n'
           << "pair_score_2=" << checkpoint.paired.bins[4] << '\n';
    output.flush();
    if (!output) return set_error(error, "failed while writing checkpoint");
    output.close();
    std::error_code rename_error;
    fs::rename(temporary, target, rename_error);
    if (rename_error) {
        std::error_code remove_error;
        fs::remove(target, remove_error);
        rename_error.clear();
        fs::rename(temporary, target, rename_error);
    }
    if (rename_error) {
        fs::remove(temporary);
        return set_error(error, "cannot atomically replace checkpoint: " + rename_error.message());
    }
    return true;
}

bool load_match_checkpoint(
    const std::string& path,
    MatchCheckpoint& checkpoint,
    std::string* error) {
    std::ifstream input(path);
    if (!input) return set_error(error, "cannot open checkpoint: " + path);
    MatchCheckpoint loaded{};
    std::set<std::string> seen;
    std::string line;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const auto separator = line.find('=');
        if (separator == std::string::npos) {
            return set_error(error, "checkpoint line " + std::to_string(line_number) + " has no '='");
        }
        const std::string key = trim(line.substr(0, separator));
        const std::string value = trim(line.substr(separator + 1));
        if (!seen.insert(key).second) return set_error(error, "duplicate checkpoint key: " + key);
        if (key == "format_version") {
            if (!parse_integer(value, loaded.format_version)) return set_error(error, "invalid format_version");
        } else if (key == "run_fingerprint") {
            loaded.run_fingerprint = value;
        } else if (key == "completed_pairs") {
            if (!parse_integer(value, loaded.completed_pairs)) return set_error(error, "invalid completed_pairs");
        } else if (key == "wins") {
            if (!parse_integer(value, loaded.sprt.wins)) return set_error(error, "invalid wins");
        } else if (key == "draws") {
            if (!parse_integer(value, loaded.sprt.draws)) return set_error(error, "invalid draws");
        } else if (key == "losses") {
            if (!parse_integer(value, loaded.sprt.losses)) return set_error(error, "invalid losses");
        } else if (key == "points") {
            if (!parse_double_value(value, loaded.sprt.points)) return set_error(error, "invalid points");
        } else if (key == "llr") {
            if (!parse_double_value(value, loaded.sprt.llr)) return set_error(error, "invalid llr");
        } else if (key == "max_ply_adjudications") {
            if (!parse_integer(value, loaded.max_ply_adjudications)) return set_error(error, "invalid adjudications");
        } else if (key == "nodes_a") {
            if (!parse_integer(value, loaded.nodes_a)) return set_error(error, "invalid nodes_a");
        } else if (key == "nodes_b") {
            if (!parse_integer(value, loaded.nodes_b)) return set_error(error, "invalid nodes_b");
        } else if (key == "pair_score_0") {
            if (!parse_integer(value, loaded.paired.bins[0])) return set_error(error, "invalid pair_score_0");
        } else if (key == "pair_score_0_5") {
            if (!parse_integer(value, loaded.paired.bins[1])) return set_error(error, "invalid pair_score_0_5");
        } else if (key == "pair_score_1") {
            if (!parse_integer(value, loaded.paired.bins[2])) return set_error(error, "invalid pair_score_1");
        } else if (key == "pair_score_1_5") {
            if (!parse_integer(value, loaded.paired.bins[3])) return set_error(error, "invalid pair_score_1_5");
        } else if (key == "pair_score_2") {
            if (!parse_integer(value, loaded.paired.bins[4])) return set_error(error, "invalid pair_score_2");
        } else {
            return set_error(error, "unknown checkpoint key: " + key);
        }
    }
    const bool supported_version = loaded.format_version == 1 || loaded.format_version == 2;
    const bool paired_consistent = loaded.format_version == 1 ||
        loaded.paired.pairs() == static_cast<std::uint64_t>(loaded.completed_pairs);
    if (!supported_version || loaded.run_fingerprint.empty() || loaded.completed_pairs < 0 ||
        loaded.sprt.wins < 0 || loaded.sprt.draws < 0 || loaded.sprt.losses < 0 ||
        loaded.sprt.games() != loaded.completed_pairs * 2 || loaded.max_ply_adjudications < 0 ||
        !paired_consistent) {
        return set_error(error, "checkpoint consistency validation failed");
    }
    checkpoint = std::move(loaded);
    return true;
}

}  // namespace albay
