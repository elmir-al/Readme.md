/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 36 — stable NNUE teacher corpus and real training audit.
*/
#include "albay/nnue_teacher.hpp"

#include "albay/movegen.hpp"
#include "albay/search.hpp"

#include <algorithm>
#include <atomic>
#include <bit>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <limits>
#include <mutex>
#include <optional>
#include <thread>
#include <unordered_set>

namespace albay {
namespace {

struct PositionKey {
    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    std::uint8_t side = 0;
    [[nodiscard]] bool operator==(const PositionKey&) const noexcept = default;
};

[[nodiscard]] constexpr std::uint64_t mix64(std::uint64_t value) noexcept {
    value ^= value >> 30U;
    value *= 0xBF58476D1CE4E5B9ULL;
    value ^= value >> 27U;
    value *= 0x94D049BB133111EBULL;
    value ^= value >> 31U;
    return value;
}

struct PositionKeyHash {
    [[nodiscard]] std::size_t operator()(const PositionKey& key) const noexcept {
        std::uint64_t value = static_cast<std::uint64_t>(key.white) |
            (static_cast<std::uint64_t>(key.black) << 32U);
        value ^= mix64(static_cast<std::uint64_t>(key.kings) |
            (static_cast<std::uint64_t>(key.side) << 40U));
        return static_cast<std::size_t>(mix64(value));
    }
};

struct CandidateResult {
    bool processed = false;
    bool accepted = false;
    enum class Reject : std::uint8_t {
        None,
        Illegal,
        Tactical,
        Search,
        Drift,
        Sign,
        BestMove,
    } reject = Reject::None;
    NnueDatasetRecord record{};
    std::optional<NnueDatasetRecord> symmetry{};
    std::uint64_t shallow_nodes = 0;
    std::uint64_t deep_nodes = 0;
    std::uint64_t tablebase_hits = 0;
    bool exact = false;
};

[[nodiscard]] bool fail(std::string* error, std::string message) {
    if (error != nullptr) *error = std::move(message);
    return false;
}

[[nodiscard]] int score_sign(int score, int draw_band) noexcept {
    if (std::abs(score) <= draw_band) return 0;
    return score > 0 ? 1 : -1;
}

[[nodiscard]] std::int16_t clamp_score(int score, int maximum_absolute_score) noexcept {
    const int limit = std::clamp(maximum_absolute_score, 1, 30'000);
    return static_cast<std::int16_t>(std::clamp(score, -limit, limit));
}

[[nodiscard]] PositionKey key_of(const Position& position) noexcept {
    return PositionKey{
        position.white(), position.black(), position.kings(),
        static_cast<std::uint8_t>(position.side_to_move() == Color::White ? 0 : 1)};
}

[[nodiscard]] NnueDatasetRecord make_teacher_record(
    const HceRecord& input,
    const Position& position,
    int score,
    int depth,
    bool exact,
    bool symmetry) {
    NnueDatasetRecord record{};
    record.white = position.white();
    record.black = position.black();
    record.kings = position.kings();
    record.group_id = input.group_id;
    record.target_score_stm = clamp_score(score, 30'000);
    record.ply = input.ply;
    record.no_progress_plies = position.no_progress_plies();
    record.flags = NnueDatasetTargetScoreKnown;
    MoveList legal;
    generate_legal_moves(position, legal);
    if (!legal.empty() && !legal[0].is_capture()) {
        record.flags = static_cast<std::uint16_t>(record.flags | NnueDatasetQuietPosition);
    }
    if ((input.flags & HceGameResultKnown) != 0 && input.game_result_white >= -1 && input.game_result_white <= 1) {
        const int white_result = input.game_result_white;
        record.game_result_stm = static_cast<std::int8_t>(
            position.side_to_move() == Color::White ? white_result : -white_result);
        record.flags = static_cast<std::uint16_t>(record.flags | NnueDatasetGameResultKnown);
    }
    if (exact) record.flags = static_cast<std::uint16_t>(record.flags | NnueDatasetExactTeacher);
    if (symmetry) record.flags = static_cast<std::uint16_t>(record.flags | NnueDatasetSymmetryDerived);
    record.side_to_move = position.side_to_move();
    record.phase = classify_hce_phase(position);
    record.split = input.split;
    record.source = exact ? HceSource::ExactEndgame : input.source;
    record.teacher_depth = static_cast<std::uint8_t>(std::clamp(depth, 0, 255));
    return record;
}

[[nodiscard]] Phase35LossMetrics subset_metrics(
    const std::vector<NnueDatasetRecord>& records,
    const NnueModel& model,
    HceSplit split,
    std::optional<HcePhase> phase,
    bool exact_only,
    double score_scale) {
    Phase35LossMetrics metrics{};
    double squared = 0.0;
    double absolute = 0.0;
    std::uint64_t sign_matches = 0;
    for (const auto& record : records) {
        if (record.split != split || (record.flags & NnueDatasetTargetScoreKnown) == 0) continue;
        if (phase.has_value() && record.phase != *phase) continue;
        if (exact_only && (record.flags & NnueDatasetExactTeacher) == 0) continue;
        const Position position = nnue_dataset_position(record);
        const double predicted = static_cast<double>(evaluate_nnue(position, model));
        const double target = static_cast<double>(record.target_score_stm);
        const double diff = predicted - target;
        squared += diff * diff;
        absolute += std::abs(diff);
        const int predicted_sign = score_sign(static_cast<int>(std::llround(predicted)), 30);
        const int target_sign = score_sign(static_cast<int>(record.target_score_stm), 30);
        if (predicted_sign == target_sign) ++sign_matches;
        ++metrics.samples;
    }
    if (metrics.samples != 0) {
        metrics.mean_squared_error = squared / static_cast<double>(metrics.samples) /
            (score_scale * score_scale);
        metrics.mean_absolute_error_cp = absolute / static_cast<double>(metrics.samples);
        metrics.root_mean_squared_error_cp = std::sqrt(squared / static_cast<double>(metrics.samples));
        metrics.sign_accuracy = static_cast<double>(sign_matches) / static_cast<double>(metrics.samples);
    }
    return metrics;
}

[[nodiscard]] double improvement_percent(double before, double after) noexcept {
    if (before <= 0.0) return 0.0;
    return (before - after) * 100.0 / before;
}

void write_metrics(std::ofstream& out, const char* name, const Phase35LossMetrics& metrics, bool comma) {
    out << "    \"" << name << "\": {\"samples\": " << metrics.samples
        << ", \"mse\": " << metrics.mean_squared_error
        << ", \"mae_cp\": " << metrics.mean_absolute_error_cp
        << ", \"rmse_cp\": " << metrics.root_mean_squared_error_cp
        << ", \"sign_accuracy\": " << metrics.sign_accuracy << "}";
    if (comma) out << ',';
    out << '\n';
}

}  // namespace

bool phase36_build_teacher_corpus(
    const std::vector<HceRecord>& input,
    const Phase36TeacherOptions& options,
    std::vector<NnueDatasetRecord>& output,
    Phase36TeacherReport& report,
    std::string* error) {
    report = {};
    output.clear();
    report.input_records = input.size();
    if (options.shallow_depth < 1 || options.deep_depth <= options.shallow_depth ||
        options.deep_depth > kMaxSearchDepth) {
        return fail(error, "Phase 36 teacher depths are invalid");
    }
    if (options.workers < 1 || options.workers > 32 || options.maximum_score_drift < 0 ||
        options.draw_band < 0 || options.maximum_absolute_score < 1) {
        return fail(error, "Phase 36 teacher options are invalid");
    }

    const std::size_t selected_count = options.maximum_input_records == 0
        ? input.size() : std::min(options.maximum_input_records, input.size());
    report.selected_records = selected_count;
    if (selected_count == 0) return fail(error, "Phase 36 input corpus is empty");

    std::vector<CandidateResult> results(selected_count);
    std::atomic<std::size_t> next{0};
    const auto started = std::chrono::steady_clock::now();
    std::vector<std::jthread> workers;
    workers.reserve(static_cast<std::size_t>(options.workers));

    for (int worker = 0; worker < options.workers; ++worker) {
        workers.emplace_back([&]() {
            Searcher searcher;
            SearchOptions search_options{};
            search_options.threads = 1;
            search_options.active_threads = 1;
            search_options.hash_size_mb = 16;
            if (!options.exact_tablebase_path.empty()) {
                search_options.use_exact_tablebase = true;
                search_options.exact_tablebase_probe_search = true;
                search_options.exact_tablebase_max_pieces = 4;
                search_options.exact_tablebase_path = options.exact_tablebase_path.string();
            }
            SearchLimits shallow_limits{};
            shallow_limits.depth = options.shallow_depth;
            SearchLimits deep_limits{};
            deep_limits.depth = options.deep_depth;

            while (true) {
                const std::size_t index = next.fetch_add(1, std::memory_order_relaxed);
                if (index >= selected_count) break;
                CandidateResult candidate{};
                candidate.processed = true;
                Position position;
                try {
                    position = hce_record_position(input[index]);
                } catch (...) {
                    candidate.reject = CandidateResult::Reject::Illegal;
                    results[index] = std::move(candidate);
                    continue;
                }
                if (position.game_result() != GameResult::Ongoing) {
                    candidate.reject = CandidateResult::Reject::Illegal;
                    results[index] = std::move(candidate);
                    continue;
                }
                MoveList legal;
                generate_legal_moves(position, legal);
                if (legal.empty() || (options.require_quiet && legal[0].is_capture())) {
                    candidate.reject = CandidateResult::Reject::Tactical;
                    results[index] = std::move(candidate);
                    continue;
                }

                searcher.clear_hash();
                const SearchResult shallow = searcher.search(position, shallow_limits, search_options);
                searcher.clear_hash();
                const SearchResult deep = searcher.search(position, deep_limits, search_options);
                candidate.shallow_nodes = shallow.nodes;
                candidate.deep_nodes = deep.nodes;
                candidate.tablebase_hits = shallow.diagnostics.tablebase_hits + deep.diagnostics.tablebase_hits;

                if (!shallow.best_move.has_value() || !deep.best_move.has_value() ||
                    shallow.completed_depth < options.shallow_depth || deep.completed_depth < options.deep_depth) {
                    candidate.reject = CandidateResult::Reject::Search;
                    results[index] = std::move(candidate);
                    continue;
                }
                if (std::abs(deep.score - shallow.score) > options.maximum_score_drift) {
                    candidate.reject = CandidateResult::Reject::Drift;
                    results[index] = std::move(candidate);
                    continue;
                }
                if (score_sign(deep.score, options.draw_band) != score_sign(shallow.score, options.draw_band)) {
                    candidate.reject = CandidateResult::Reject::Sign;
                    results[index] = std::move(candidate);
                    continue;
                }
                if (options.require_best_move_match && *deep.best_move != *shallow.best_move) {
                    candidate.reject = CandidateResult::Reject::BestMove;
                    results[index] = std::move(candidate);
                    continue;
                }

                const int pieces = std::popcount(position.occupied());
                candidate.exact = pieces <= 4 && deep.diagnostics.tablebase_hits != 0;
                candidate.record = make_teacher_record(
                    input[index], position,
                    std::clamp<int>(deep.score, -options.maximum_absolute_score, options.maximum_absolute_score),
                    options.deep_depth, candidate.exact, false);
                if (options.augment_color_symmetry) {
                    const Position mirrored = color_swap_rotate_hce_position(position);
                    candidate.symmetry = make_teacher_record(
                        input[index], mirrored,
                        candidate.record.target_score_stm,
                        options.deep_depth, candidate.exact, true);
                }
                candidate.accepted = true;
                candidate.reject = CandidateResult::Reject::None;
                results[index] = std::move(candidate);
            }
        });
    }
    workers.clear();

    std::unordered_set<PositionKey, PositionKeyHash> seen;
    seen.reserve(selected_count * (options.augment_color_symmetry ? 2U : 1U));
    std::unordered_set<std::uint64_t> groups;
    output.reserve(selected_count * (options.augment_color_symmetry ? 2U : 1U));

    for (const auto& candidate : results) {
        report.shallow_nodes += candidate.shallow_nodes;
        report.deep_nodes += candidate.deep_nodes;
        report.tablebase_hits += candidate.tablebase_hits;
        if (!candidate.accepted) {
            switch (candidate.reject) {
                case CandidateResult::Reject::Illegal: ++report.rejected_illegal; break;
                case CandidateResult::Reject::Tactical: ++report.rejected_forced_or_tactical; break;
                case CandidateResult::Reject::Search: ++report.rejected_search; break;
                case CandidateResult::Reject::Drift: ++report.rejected_score_drift; break;
                case CandidateResult::Reject::Sign: ++report.rejected_score_sign; break;
                case CandidateResult::Reject::BestMove: ++report.rejected_best_move; break;
                case CandidateResult::Reject::None: break;
            }
            continue;
        }
        auto append = [&](const NnueDatasetRecord& record, bool symmetry) {
            const Position position = nnue_dataset_position(record);
            if (!seen.insert(key_of(position)).second) {
                ++report.duplicate_rejections;
                return;
            }
            output.push_back(record);
            groups.insert(record.group_id);
            ++report.phase_counts[static_cast<std::size_t>(record.phase)];
            ++report.split_counts[static_cast<std::size_t>(record.split)];
            if ((record.flags & NnueDatasetExactTeacher) != 0) ++report.exact_teacher_records;
            if (symmetry) ++report.accepted_symmetry;
            else ++report.accepted_primary;
        };
        append(candidate.record, false);
        if (candidate.symmetry.has_value()) append(*candidate.symmetry, true);
    }
    report.unique_groups = groups.size();
    report.seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
    if (output.empty()) return fail(error, "Phase 36 stability filter rejected every position");
    return true;
}

Phase36AuditReport phase36_audit_model(
    const std::vector<NnueDatasetRecord>& records,
    const NnueModel& model,
    double score_scale) {
    Phase36AuditReport report{};
    const NnueModel zero = NnueModel::zero_model();
    report.validation_zero = subset_metrics(records, zero, HceSplit::Validation, std::nullopt, false, score_scale);
    report.validation_model = subset_metrics(records, model, HceSplit::Validation, std::nullopt, false, score_scale);
    report.holdout_zero = subset_metrics(records, zero, HceSplit::Holdout, std::nullopt, false, score_scale);
    report.holdout_model = subset_metrics(records, model, HceSplit::Holdout, std::nullopt, false, score_scale);
    for (std::size_t phase = 0; phase < report.holdout_by_phase.size(); ++phase) {
        report.holdout_by_phase[phase] = subset_metrics(
            records, model, HceSplit::Holdout, static_cast<HcePhase>(phase), false, score_scale);
    }
    report.holdout_exact = subset_metrics(records, model, HceSplit::Holdout, std::nullopt, true, score_scale);
    report.validation_mse_improvement_percent = improvement_percent(
        report.validation_zero.mean_squared_error, report.validation_model.mean_squared_error);
    report.holdout_mse_improvement_percent = improvement_percent(
        report.holdout_zero.mean_squared_error, report.holdout_model.mean_squared_error);
    report.validation_improved = report.validation_model.samples != 0 &&
        report.validation_model.mean_squared_error < report.validation_zero.mean_squared_error;
    report.holdout_improved = report.holdout_model.samples != 0 &&
        report.holdout_model.mean_squared_error < report.holdout_zero.mean_squared_error;
    report.research_gate_passed = report.validation_improved && report.holdout_improved &&
        report.validation_mse_improvement_percent >= 1.0 &&
        report.holdout_mse_improvement_percent >= 0.5;
    report.production_accepted = false;
    return report;
}

void write_phase36_teacher_report(
    const std::filesystem::path& path,
    const Phase36TeacherOptions& options,
    const Phase36TeacherReport& report,
    const NnueDatasetHeader* dataset_header) {
    std::ofstream out(path);
    if (!out) return;
    out << std::fixed << std::setprecision(6)
        << "{\n"
        << "  \"phase\": 36,\n"
        << "  \"teacher\": \"Albay dual-depth stable teacher\",\n"
        << "  \"shallow_depth\": " << options.shallow_depth << ",\n"
        << "  \"deep_depth\": " << options.deep_depth << ",\n"
        << "  \"maximum_score_drift\": " << options.maximum_score_drift << ",\n"
        << "  \"draw_band\": " << options.draw_band << ",\n"
        << "  \"require_best_move_match\": " << (options.require_best_move_match ? "true" : "false") << ",\n"
        << "  \"symmetry_augmentation\": " << (options.augment_color_symmetry ? "true" : "false") << ",\n"
        << "  \"input_records\": " << report.input_records << ",\n"
        << "  \"selected_records\": " << report.selected_records << ",\n"
        << "  \"accepted_primary\": " << report.accepted_primary << ",\n"
        << "  \"accepted_symmetry\": " << report.accepted_symmetry << ",\n"
        << "  \"rejected\": {\n"
        << "    \"illegal\": " << report.rejected_illegal << ",\n"
        << "    \"forced_or_tactical\": " << report.rejected_forced_or_tactical << ",\n"
        << "    \"search\": " << report.rejected_search << ",\n"
        << "    \"score_drift\": " << report.rejected_score_drift << ",\n"
        << "    \"score_sign\": " << report.rejected_score_sign << ",\n"
        << "    \"best_move\": " << report.rejected_best_move << ",\n"
        << "    \"duplicates\": " << report.duplicate_rejections << "\n  },\n"
        << "  \"shallow_nodes\": " << report.shallow_nodes << ",\n"
        << "  \"deep_nodes\": " << report.deep_nodes << ",\n"
        << "  \"tablebase_hits\": " << report.tablebase_hits << ",\n"
        << "  \"exact_teacher_records\": " << report.exact_teacher_records << ",\n"
        << "  \"unique_groups\": " << report.unique_groups << ",\n"
        << "  \"phase_counts\": [" << report.phase_counts[0] << ", " << report.phase_counts[1]
        << ", " << report.phase_counts[2] << ", " << report.phase_counts[3] << "],\n"
        << "  \"split_counts\": [" << report.split_counts[0] << ", " << report.split_counts[1]
        << ", " << report.split_counts[2] << "],\n"
        << "  \"seconds\": " << report.seconds;
    if (dataset_header != nullptr) {
        out << ",\n  \"dataset_records\": " << dataset_header->record_count
            << ",\n  \"dataset_checksum\": " << dataset_header->payload_fnv1a64;
    }
    out << "\n}\n";
}

void write_phase36_audit_report(
    const std::filesystem::path& path,
    const Phase36AuditReport& report,
    std::uint64_t dataset_checksum,
    std::uint64_t model_checksum) {
    std::ofstream out(path);
    if (!out) return;
    out << std::fixed << std::setprecision(8)
        << "{\n"
        << "  \"phase\": 36,\n"
        << "  \"dataset_checksum\": " << dataset_checksum << ",\n"
        << "  \"model_checksum\": " << model_checksum << ",\n"
        << "  \"metrics\": {\n";
    write_metrics(out, "validation_zero", report.validation_zero, true);
    write_metrics(out, "validation_model", report.validation_model, true);
    write_metrics(out, "holdout_zero", report.holdout_zero, true);
    write_metrics(out, "holdout_model", report.holdout_model, true);
    write_metrics(out, "holdout_opening", report.holdout_by_phase[0], true);
    write_metrics(out, "holdout_middlegame", report.holdout_by_phase[1], true);
    write_metrics(out, "holdout_man_endgame", report.holdout_by_phase[2], true);
    write_metrics(out, "holdout_king_endgame", report.holdout_by_phase[3], true);
    write_metrics(out, "holdout_exact", report.holdout_exact, false);
    out << "  },\n"
        << "  \"validation_mse_improvement_percent\": " << report.validation_mse_improvement_percent << ",\n"
        << "  \"holdout_mse_improvement_percent\": " << report.holdout_mse_improvement_percent << ",\n"
        << "  \"validation_improved\": " << (report.validation_improved ? "true" : "false") << ",\n"
        << "  \"holdout_improved\": " << (report.holdout_improved ? "true" : "false") << ",\n"
        << "  \"research_gate_passed\": " << (report.research_gate_passed ? "true" : "false") << ",\n"
        << "  \"production_accepted\": false\n"
        << "}\n";
}

}  // namespace albay
