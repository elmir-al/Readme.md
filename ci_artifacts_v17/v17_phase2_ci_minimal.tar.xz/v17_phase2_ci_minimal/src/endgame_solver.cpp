/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/endgame_solver.hpp"

#include "albay/movegen.hpp"

#include <algorithm>
#include <bit>
#include <limits>

namespace albay {
namespace {

[[nodiscard]] std::uint64_t mix64(std::uint64_t value) noexcept {
    value ^= value >> 30U;
    value *= 0xBF58476D1CE4E5B9ULL;
    value ^= value >> 27U;
    value *= 0x94D049BB133111EBULL;
    value ^= value >> 31U;
    return value;
}

}  // namespace

std::size_t EndgameSolver::MemoKeyHash::operator()(const MemoKey& key) const noexcept {
    std::uint64_t hash = mix64(key.position_key);
    hash ^= mix64(key.history_fingerprint + 0x9E3779B97F4A7C15ULL);
    hash ^= mix64(
        (static_cast<std::uint64_t>(key.no_progress_plies) << 16U) |
        static_cast<std::uint64_t>(key.history_size));
    return static_cast<std::size_t>(hash);
}

EndgameSolveResult EndgameSolver::solve(
    const Position& root,
    const EndgameSolveOptions& options) {
    options_ = options;
    options_.maximum_pieces = std::clamp(options_.maximum_pieces, 2, 6);
    options_.maximum_ply = std::clamp(options_.maximum_ply, 1, 512);
    nodes_ = 0;
    aborted_ = false;
    memo_.clear();

    EndgameSolveResult result{};
    if (std::popcount(root.occupied()) > options_.maximum_pieces) {
        return result;
    }

    Position position = root;
    NodeResult node = solve_node(position, 0);
    result.outcome = node.outcome;
    result.distance_to_result = node.distance;
    result.distance_is_exact = node.distance_is_exact;
    result.best_move = node.best_move;
    result.principal_variation = std::move(node.pv);
    result.nodes = nodes_;
    result.complete = node.complete && !aborted_;
    if (!result.complete) {
        result.outcome = EndgameOutcome::Unknown;
        result.distance_to_result = 0;
        result.best_move.reset();
        result.principal_variation.clear();
    }
    return result;
}

EndgameSolver::NodeResult EndgameSolver::solve_node(Position& position, int ply) {
    if (control_requested() || ply >= options_.maximum_ply) {
        aborted_ = true;
        return {};
    }
    ++nodes_;

    const EndgameOutcome terminal = terminal_outcome(position);
    if (terminal != EndgameOutcome::Unknown) {
        return {terminal, 0, true, std::nullopt, {}, true};
    }
    if (std::popcount(position.occupied()) > options_.maximum_pieces) {
        return {};
    }

    const MemoKey key{
        position.key(),
        position.history_fingerprint(),
        position.no_progress_plies(),
        position.history_size(),
    };
    if (const auto found = memo_.find(key); found != memo_.end()) {
        return found->second;
    }

    MoveList moves;
    generate_legal_moves(position, moves);
    if (moves.empty()) {
        return {EndgameOutcome::Loss, 0, true, std::nullopt, {}, true};
    }

    NodeResult best_loss{};
    best_loss.outcome = EndgameOutcome::Loss;
    best_loss.distance = -1;
    bool all_loss = true;
    bool has_draw = false;
    bool has_unknown = false;
    bool all_loss_distances_exact = true;
    std::optional<Move> draw_move;
    std::vector<Move> draw_pv;

    for (const Move& move : moves) {
        if (control_requested()) {
            aborted_ = true;
            return {};
        }
        UndoState undo{};
        position.make_move_unchecked(move, undo);
        NodeResult child = solve_node(position, ply + 1);
        position.unmake_move(move, undo);

        if (!child.complete) {
            has_unknown = true;
            all_loss = false;
            continue;
        }

        const EndgameOutcome current_outcome = invert(child.outcome);
        const int distance = child.distance + 1;
        std::vector<Move> pv;
        pv.reserve(child.pv.size() + 1U);
        pv.push_back(move);
        pv.insert(pv.end(), child.pv.begin(), child.pv.end());

        if (current_outcome == EndgameOutcome::Win) {
            // A single proven move to an opponent loss is sufficient to prove
            // the current node as a win. Returning immediately keeps the
            // forward solver practical under mobile node budgets. The reported
            // distance is the length of the proven principal variation; it is
            // not claimed to be globally minimal unless every winning branch
            // was searched.
            const bool distance_exact = moves.size() == 1U && child.distance_is_exact;
            NodeResult win{EndgameOutcome::Win, distance, distance_exact, move, std::move(pv), true};
            memo_.emplace(key, win);
            return win;
        } else if (current_outcome == EndgameOutcome::Draw) {
            all_loss = false;
            has_draw = true;
            if (!draw_move.has_value()) {
                draw_move = move;
                draw_pv = std::move(pv);
            }
        } else if (current_outcome == EndgameOutcome::Loss) {
            all_loss_distances_exact = all_loss_distances_exact && child.distance_is_exact;
            if (distance > best_loss.distance) {
                best_loss = {EndgameOutcome::Loss, distance, child.distance_is_exact, move, std::move(pv), true};
            }
        } else {
            has_unknown = true;
            all_loss = false;
        }
    }

    NodeResult result{};
    if (has_unknown) {
        return {};
    } else if (has_draw) {
        result = {EndgameOutcome::Draw, 0, false, draw_move, std::move(draw_pv), true};
    } else if (all_loss && best_loss.distance >= 0) {
        best_loss.distance_is_exact = all_loss_distances_exact;
        result = std::move(best_loss);
    } else {
        return {};
    }

    memo_.emplace(key, result);
    return result;
}

bool EndgameSolver::control_requested() const {
    if (options_.node_limit != 0 && nodes_ >= options_.node_limit) {
        return true;
    }
    return options_.should_stop && options_.should_stop();
}

EndgameOutcome EndgameSolver::terminal_outcome(const Position& position) {
    const GameResult result = position.game_result();
    switch (result) {
        case GameResult::WhiteWin:
            return position.side_to_move() == Color::White
                ? EndgameOutcome::Win : EndgameOutcome::Loss;
        case GameResult::BlackWin:
            return position.side_to_move() == Color::Black
                ? EndgameOutcome::Win : EndgameOutcome::Loss;
        case GameResult::DrawByRepetition:
        case GameResult::DrawByNoProgress:
            return EndgameOutcome::Draw;
        case GameResult::Ongoing:
            return EndgameOutcome::Unknown;
    }
    return EndgameOutcome::Unknown;
}

EndgameOutcome EndgameSolver::invert(EndgameOutcome outcome) noexcept {
    if (outcome == EndgameOutcome::Win) {
        return EndgameOutcome::Loss;
    }
    if (outcome == EndgameOutcome::Loss) {
        return EndgameOutcome::Win;
    }
    return outcome;
}

}  // namespace albay
