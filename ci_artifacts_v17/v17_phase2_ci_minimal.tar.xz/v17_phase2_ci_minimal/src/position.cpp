/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/position.hpp"

#include "albay/geometry.hpp"
#include "albay/movegen.hpp"
#include "albay/zobrist.hpp"

#include <algorithm>
#include <bit>
#include <cassert>
#include <stdexcept>

namespace albay {
namespace {

[[nodiscard]] std::size_t color_index(Color color) noexcept {
    return color == Color::White ? 0 : 1;
}

[[nodiscard]] std::size_t piece_type_index(bool king) noexcept {
    return king ? 1 : 0;
}

}  // namespace

Position::Position() {
    reset_to_initial();
}

Position::Position(const Position& other) noexcept
    : white_(other.white_), black_(other.black_), kings_(other.kings_),
      side_to_move_(other.side_to_move_), key_(other.key_),
      no_progress_plies_(other.no_progress_plies_), history_size_(other.history_size_) {
    std::copy_n(other.key_history_.begin(), history_size_, key_history_.begin());
}

Position& Position::operator=(const Position& other) noexcept {
    if (this == &other) return *this;
    white_ = other.white_;
    black_ = other.black_;
    kings_ = other.kings_;
    side_to_move_ = other.side_to_move_;
    key_ = other.key_;
    no_progress_plies_ = other.no_progress_plies_;
    history_size_ = other.history_size_;
    std::copy_n(other.key_history_.begin(), history_size_, key_history_.begin());
    return *this;
}

Position Position::initial() {
    Position position;
    position.reset_to_initial();
    return position;
}

Position Position::from_bitboards(
    Bitboard white,
    Bitboard black,
    Bitboard kings,
    Color side_to_move,
    std::uint16_t no_progress_plies) {
    Position position;
    position.white_ = white;
    position.black_ = black;
    position.kings_ = kings;
    position.side_to_move_ = side_to_move;
    position.no_progress_plies_ = no_progress_plies;
    position.key_ = position.recompute_key();
    position.initialize_history();

    std::string error;
    if (!position.validate(&error)) {
        throw std::invalid_argument("Invalid Albay position: " + error);
    }
    return position;
}

void Position::reset_to_initial() {
    white_ = 0x00000FFFU;
    black_ = 0xFFF00000U;
    kings_ = 0;
    side_to_move_ = Color::White;
    no_progress_plies_ = 0;
    key_ = recompute_key();
    initialize_history();
}

bool Position::validate(std::string* error) const {
    auto fail = [error](const char* message) {
        if (error != nullptr) {
            *error = message;
        }
        return false;
    };

    if ((white_ & black_) != 0) {
        return fail("white and black bitboards overlap");
    }
    if ((kings_ & ~occupied()) != 0) {
        return fail("king bitboard contains an empty square");
    }
    if (std::popcount(white_) > 12 || std::popcount(black_) > 12) {
        return fail("a side contains more than 12 pieces");
    }
    if (key_ != recompute_key()) {
        return fail("incremental Zobrist key does not match recomputed key");
    }
    if (history_size_ == 0 || history_size_ > kMaxHistoryPly) {
        return fail("invalid repetition history size");
    }
    if (key_history_[history_size_ - 1] != key_) {
        return fail("repetition history tail does not match position key");
    }
    return true;
}

HashKey Position::recompute_key() const noexcept {
    const auto& keys = zobrist::tables();
    HashKey result = 0;

    for (std::size_t color_value = 0; color_value < 2; ++color_value) {
        const Color color = color_value == 0 ? Color::White : Color::Black;
        Bitboard pieces_left = pieces(color);
        while (pieces_left != 0) {
            const Square square = static_cast<Square>(std::countr_zero(pieces_left));
            pieces_left &= pieces_left - 1U;
            const bool king = is_king(square);
            result ^= keys.piece[color_value][piece_type_index(king)][square];
        }
    }

    if (side_to_move_ == Color::Black) {
        result ^= keys.side_to_move;
    }
    return result;
}

void Position::make_move(const Move& move, UndoState& undo) {
    if (!is_valid_square(move.from) || !is_valid_square(move.to)) {
        throw std::invalid_argument("Albay make_move received an invalid square");
    }

    const Color mover = side_to_move_;
    const Bitboard mover_pieces = pieces(mover);
    const Bitboard opponent_pieces = pieces(opposite(mover));
    const Bitboard from_bit = bit(move.from);
    const Bitboard to_bit = bit(move.to);
    const Bitboard captured_mask = move.captured_mask();

    if ((mover_pieces & from_bit) == 0 ||
        (move.to != move.from && (occupied() & to_bit) != 0) ||
        (move.to == move.from && !move.is_capture())) {
        throw std::invalid_argument("Albay make_move received a structurally invalid move");
    }
    if ((captured_mask & ~opponent_pieces) != 0) {
        throw std::invalid_argument("Albay move captures a non-opponent square");
    }
    if (history_size_ >= kMaxHistoryPly) {
        throw std::overflow_error("Albay repetition history capacity exceeded");
    }

    make_move_unchecked(move, undo);
}

void Position::make_move_unchecked(const Move& move, UndoState& undo) {
    const Color mover = side_to_move_;
    const Color opponent = opposite(mover);
    Bitboard& mover_pieces = mover == Color::White ? white_ : black_;
    const Bitboard from_bit = bit(move.from);
    const Bitboard to_bit = bit(move.to);

    undo.previous_no_progress_plies = no_progress_plies_;
    undo.moving_piece_was_king = (kings_ & from_bit) != 0;
    undo.captured_mask = 0;
    undo.captured_kings = 0;

    const auto& keys = zobrist::tables();
    const std::size_t mover_index = color_index(mover);
    key_ ^= keys.piece[mover_index][piece_type_index(undo.moving_piece_was_king)][move.from];

    if (move.capture_count != 0) {
        Bitboard& opponent_pieces = opponent == Color::White ? white_ : black_;
        const std::size_t opponent_index = color_index(opponent);
        for (std::uint8_t index = 0; index < move.capture_count; ++index) {
            const Square captured_square = move.captures[index];
            const Bitboard captured_bit = bit(captured_square);
            undo.captured_mask |= captured_bit;
            const bool captured_was_king = (kings_ & captured_bit) != 0;
            if (captured_was_king) undo.captured_kings |= captured_bit;
            key_ ^= keys.piece[opponent_index][piece_type_index(captured_was_king)][captured_square];
        }
        opponent_pieces &= ~undo.captured_mask;
    }

    const bool final_is_king = undo.moving_piece_was_king || move.is_promotion();
    key_ ^= keys.piece[mover_index][piece_type_index(final_is_king)][move.to];
    key_ ^= keys.side_to_move;

    if (move.from != move.to) mover_pieces ^= from_bit | to_bit;

    kings_ &= ~(from_bit | undo.captured_mask);
    if (final_is_king) kings_ |= to_bit;
    else kings_ &= ~to_bit;

    if (move.capture_count != 0 || !undo.moving_piece_was_king || move.is_promotion()) {
        no_progress_plies_ = 0;
    } else if (no_progress_plies_ < UINT16_MAX) {
        ++no_progress_plies_;
    }

    side_to_move_ = opponent;
    assert(history_size_ < kMaxHistoryPly);
    key_history_[history_size_++] = key_;
}

void Position::unmake_move(const Move& move, const UndoState& undo) noexcept {
    assert(history_size_ > 1);
    --history_size_;
    key_ = key_history_[history_size_ - 1];

    side_to_move_ = opposite(side_to_move_);
    const Color mover = side_to_move_;
    Bitboard& mover_pieces = mover == Color::White ? white_ : black_;
    const Bitboard from_bit = bit(move.from);
    const Bitboard to_bit = bit(move.to);

    if (move.from != move.to) mover_pieces ^= from_bit | to_bit;
    if (undo.captured_mask != 0) {
        Bitboard& opponent_pieces = mover == Color::White ? black_ : white_;
        opponent_pieces |= undo.captured_mask;
    }

    kings_ &= ~to_bit;
    kings_ |= undo.captured_kings;
    if (undo.moving_piece_was_king) kings_ |= from_bit;
    else kings_ &= ~from_bit;

    no_progress_plies_ = undo.previous_no_progress_plies;
}

HashKey Position::history_fingerprint() const noexcept {
    HashKey fingerprint = 0xCBF29CE484222325ULL;
    for (std::uint16_t index = 0; index < history_size_; ++index) {
        HashKey value = key_history_[index] +
            0x9E3779B97F4A7C15ULL + static_cast<HashKey>(index);
        value ^= value >> 30U;
        value *= 0xBF58476D1CE4E5B9ULL;
        value ^= value >> 27U;
        value *= 0x94D049BB133111EBULL;
        value ^= value >> 31U;
        fingerprint ^= value;
        fingerprint *= 0x100000001B3ULL;
    }
    fingerprint ^= static_cast<HashKey>(history_size_) << 48U;
    return fingerprint;
}

int Position::repetition_count() const noexcept {
    // The current position is always the history tail. Because side-to-move is
    // part of the Zobrist key, only entries with the same ply parity can match.
    // An irreversible move resets no_progress_plies_, so positions older than
    // that window cannot be part of the current repetition sequence.
    int count = 1;
    if (history_size_ < 3 || no_progress_plies_ < 2) {
        return count;
    }

    const int tail = static_cast<int>(history_size_) - 1;
    const int earliest = std::max(0, tail - static_cast<int>(no_progress_plies_));
    for (int index = tail - 2; index >= earliest; index -= 2) {
        if (key_history_[static_cast<std::size_t>(index)] == key_) {
            ++count;
        }
    }
    return count;
}

GameResult Position::game_result() const {
    if (pieces(side_to_move_) == 0) {
        return side_to_move_ == Color::White ? GameResult::BlackWin : GameResult::WhiteWin;
    }
    if (pieces(opposite(side_to_move_)) == 0) {
        return side_to_move_ == Color::White ? GameResult::WhiteWin : GameResult::BlackWin;
    }

    MoveList legal_moves;
    generate_legal_moves(*this, legal_moves);
    if (legal_moves.empty()) {
        return side_to_move_ == Color::White ? GameResult::BlackWin : GameResult::WhiteWin;
    }

    if (is_threefold_repetition()) {
        return GameResult::DrawByRepetition;
    }
    if (no_progress_plies_ >= 30) {
        return GameResult::DrawByNoProgress;
    }
    return GameResult::Ongoing;
}

void Position::initialize_history() noexcept {
    history_size_ = 1;
    key_history_[0] = key_;
}


}  // namespace albay
