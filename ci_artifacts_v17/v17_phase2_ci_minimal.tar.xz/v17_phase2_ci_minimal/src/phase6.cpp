/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/phase6.hpp"

#include "albay/movegen.hpp"
#include "albay/notation.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <fstream>
#include <limits>
#include <optional>
#include <sstream>
#include <stdexcept>

namespace albay {
namespace {

[[nodiscard]] std::string trim(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

[[nodiscard]] std::vector<std::string> split(std::string_view text, char separator) {
    std::vector<std::string> result;
    std::size_t start = 0;
    while (start <= text.size()) {
        const std::size_t end = text.find(separator, start);
        result.push_back(trim(std::string(text.substr(
            start, end == std::string_view::npos ? text.size() - start : end - start))));
        if (end == std::string_view::npos) break;
        start = end + 1;
    }
    return result;
}

[[nodiscard]] bool parse_score(std::string_view text, Score& score) {
    const auto [end, error] = std::from_chars(text.data(), text.data() + text.size(), score);
    return error == std::errc{} && end == text.data() + text.size();
}

using WeightMember = int QuietOrderingWeights::*;
constexpr std::array<WeightMember, 8> kMembers{{
    &QuietOrderingWeights::center,
    &QuietOrderingWeights::support,
    &QuietOrderingWeights::forward_lanes,
    &QuietOrderingWeights::king_mobility,
    &QuietOrderingWeights::edge_entry,
    &QuietOrderingWeights::home_rank_departure,
    &QuietOrderingWeights::advancement,
    &QuietOrderingWeights::promotion,
}};

[[nodiscard]] long long objective(const QuietRankingMetrics& metrics) noexcept {
    if (metrics.cases == 0) return 0;
    return static_cast<long long>(metrics.top1_matches) * 1'000'000LL +
        static_cast<long long>(metrics.pairwise_correct) * 1'000LL + metrics.margin_sum;
}

}  // namespace

double QuietRankingMetrics::top1_rate() const noexcept {
    return cases == 0 ? 0.0 : static_cast<double>(top1_matches) / static_cast<double>(cases);
}

double QuietRankingMetrics::pairwise_rate() const noexcept {
    return pairwise_total == 0 ? 0.0 :
        static_cast<double>(pairwise_correct) / static_cast<double>(pairwise_total);
}

bool load_phase6_ranking_dataset(
    std::istream& input,
    std::vector<Phase6RankingCase>& cases,
    std::string* error) {
    cases.clear();
    std::string line;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned.front() == '#') continue;
        const std::vector<std::string> fields = split(cleaned, '\t');
        if (fields.size() != 6) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": expected 6 columns";
            return false;
        }
        std::string parse_error;
        const auto position = parse_apf(fields[5], &parse_error);
        if (!position.has_value()) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": " + parse_error;
            return false;
        }
        const auto teacher = parse_legal_move(*position, fields[3]);
        Score teacher_score = 0;
        if (!teacher.has_value() || teacher->is_capture() || !parse_score(fields[4], teacher_score)) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": invalid quiet teacher";
            return false;
        }
        cases.push_back(Phase6RankingCase{
            fields[0], fields[1], fields[2], *position, *teacher, teacher_score});
    }
    if (cases.empty()) {
        if (error != nullptr) *error = "phase6 ranking dataset contains no cases";
        return false;
    }
    return true;
}

bool load_phase6_ranking_dataset_file(
    const std::string& path,
    std::vector<Phase6RankingCase>& cases,
    std::string* error) {
    std::ifstream input(path);
    if (!input) {
        if (error != nullptr) *error = "cannot open phase6 dataset: " + path;
        return false;
    }
    return load_phase6_ranking_dataset(input, cases, error);
}

QuietRankingMetrics evaluate_quiet_ranking(
    const std::vector<Phase6RankingCase>& cases,
    const QuietOrderingWeights& weights) {
    QuietRankingMetrics metrics{};
    for (const Phase6RankingCase& item : cases) {
        MoveList legal;
        generate_legal_moves(item.position, legal);
        if (legal.size() < 2 || legal[0].is_capture()) continue;
        int best_score = std::numeric_limits<int>::min();
        std::optional<Move> top_move;
        int teacher_score = 0;
        bool found_teacher = false;
        for (const Move& move : legal) {
            const int score = score_quiet_move(item.position, move, weights);
            if (!top_move.has_value() || score > best_score) {
                top_move = move;
                best_score = score;
            }
            if (same_move_identity(move, item.teacher_move)) {
                teacher_score = score;
                found_teacher = true;
            }
        }
        if (!found_teacher || !top_move.has_value()) continue;
        ++metrics.cases;
        if (same_move_identity(*top_move, item.teacher_move)) ++metrics.top1_matches;
        for (const Move& move : legal) {
            if (same_move_identity(move, item.teacher_move)) continue;
            const int alternative = score_quiet_move(item.position, move, weights);
            const int margin = teacher_score - alternative;
            if (margin > 0) ++metrics.pairwise_correct;
            ++metrics.pairwise_total;
            metrics.margin_sum += std::clamp(margin, -500, 500);
        }
    }
    return metrics;
}

QuietRankingTrainingReport train_quiet_ranking(
    const std::vector<Phase6RankingCase>& training,
    const std::vector<Phase6RankingCase>& validation,
    QuietOrderingWeights initial,
    int passes,
    int initial_step) {
    QuietRankingTrainingReport report{};
    report.initial = initial;
    report.trained = initial;
    report.training_before = evaluate_quiet_ranking(training, initial);
    report.validation_before = evaluate_quiet_ranking(validation, initial);
    int step = std::max(initial_step, 1);
    QuietRankingMetrics current_metrics = report.training_before;
    long long current_objective = objective(current_metrics);
    QuietOrderingWeights best_validation_weights = initial;
    QuietRankingMetrics best_validation_metrics = report.validation_before;
    long long best_validation_objective = objective(best_validation_metrics);
    for (int pass = 0; pass < std::max(passes, 0); ++pass) {
        bool changed = false;
        for (const WeightMember member : kMembers) {
            QuietOrderingWeights local = report.trained;
            QuietRankingMetrics local_metrics = current_metrics;
            long long local_objective = current_objective;
            for (const int direction : {-1, 1}) {
                QuietOrderingWeights candidate = report.trained;
                candidate.*member = std::clamp(candidate.*member + direction * step, 0, 300);
                const QuietRankingMetrics metrics = evaluate_quiet_ranking(training, candidate);
                const long long candidate_objective = objective(metrics);
                if (candidate_objective > local_objective) {
                    local = candidate;
                    local_metrics = metrics;
                    local_objective = candidate_objective;
                }
            }
            if (local_objective > current_objective) {
                report.trained = local;
                current_metrics = local_metrics;
                current_objective = local_objective;
                ++report.accepted_changes;
                changed = true;
                const QuietRankingMetrics validation_metrics =
                    evaluate_quiet_ranking(validation, report.trained);
                const long long validation_objective = objective(validation_metrics);
                if (validation_objective > best_validation_objective) {
                    best_validation_objective = validation_objective;
                    best_validation_weights = report.trained;
                    best_validation_metrics = validation_metrics;
                }
            }
        }
        ++report.passes;
        if (!changed) step = std::max(step / 2, 1);
    }
    report.trained = best_validation_weights;
    report.training_after = evaluate_quiet_ranking(training, report.trained);
    report.validation_after = best_validation_metrics;
    return report;
}

void write_quiet_ordering_weights(
    std::ostream& output,
    const QuietOrderingWeights& weights) {
    output << "PositionalQuietOrdering=true\n"
           << "QuietOrderWeight=100\n"
           << "QuietCenter=" << weights.center << '\n'
           << "QuietSupport=" << weights.support << '\n'
           << "QuietForwardLanes=" << weights.forward_lanes << '\n'
           << "QuietKingMobility=" << weights.king_mobility << '\n'
           << "QuietEdgePenalty=" << weights.edge_entry << '\n'
           << "QuietHomePenalty=" << weights.home_rank_departure << '\n'
           << "QuietAdvancement=" << weights.advancement << '\n'
           << "QuietPromotion=" << weights.promotion << '\n';
}


bool load_phase6_search_config(
    std::istream& input,
    SearchOptions& options,
    std::string* error) {
    SearchOptions parsed = options;
    std::string line;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned.front() == '#') continue;
        const std::size_t equals = cleaned.find('=');
        if (equals == std::string::npos) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": expected key=value";
            return false;
        }
        const std::string key = trim(cleaned.substr(0, equals));
        const std::string value = trim(cleaned.substr(equals + 1));
        auto parse_int_range = [&](int& target, int minimum, int maximum) -> bool {
            int number = 0;
            const auto [end, code] = std::from_chars(value.data(), value.data() + value.size(), number);
            if (code != std::errc{} || end != value.data() + value.size() ||
                number < minimum || number > maximum) {
                return false;
            }
            target = number;
            return true;
        };
        auto parse_int_value = [&](int& target) -> bool {
            return parse_int_range(target, 0, 300);
        };
        if (key == "ExactTablebasePath") {
            parsed.exact_tablebase_path = value;
            continue;
        }
        if (key == "PositionalQuietOrdering" || key == "StrategicQuietOrdering" ||
            key == "StrategicQuietOpeningOnly" || key == "StrategicContinuationBias" ||
            key == "ExactTablebase" || key == "ExactTablebaseProbeSearch" ||
            key == "ExactEndgameSolver" || key == "ExactEndgameSafeProbeOnly" ||
            key == "Aspiration" || key == "LMR" || key == "DynamicLMR" ||
            key == "RussianLMRv2" || key == "LMRPriorityGuard" ||
            key == "LMRForcingCaptureGuard" ||
            key == "FullCapacityTT" || key == "AgeAwareTTReplacement" ||
            key == "DepthPreferredTTUpdates" ||
            key == "QuiescenceTT" || key == "QuiescenceTTExactOnly" ||
            key == "QuiescenceCaptureMalus" || key == "PromotionQuiescence" ||
            key == "TacticalExtensions" || key == "ForcedReplyExtensions" ||
            key == "Phase28ExtensionPolicy" || key == "PromotionExtensions" ||
            key == "PhaseAwarePromotionExtension" ||
            key == "SingleReplyExtensions" || key == "SingleReplyQuietOnly" ||
            key == "CaptureSignatureHistory" || key == "CaptureContinuationHistory" ||
            key == "FollowupHistory" || key == "PieceTypeHistory" ||
            key == "PromotionThreatOrdering" || key == "RecaptureOrdering" ||
            key == "RecaptureExtensions" || key == "ForcedLineExtensions" ||
            key == "ForcingQuietLMRGuard" || key == "QuietSacrificeExtensions" ||
            key == "EndgameReplyOrdering" || key == "EndgameLMRGuard" ||
            key == "Razoring" || key == "StaticFutilityPruning" ||
            key == "LateMovePruning" || key == "HistoryGuardedLateMovePruning" ||
            key == "HistoryPruning" || key == "InternalIterativeReduction" ||
            key == "AdaptiveAspiration") {
            bool enabled = false;
            if (value == "true" || value == "1" || value == "on") enabled = true;
            else if (value == "false" || value == "0" || value == "off") enabled = false;
            else {
                if (error != nullptr) *error = "line " + std::to_string(line_number) + ": invalid boolean";
                return false;
            }
            if (key == "PositionalQuietOrdering") parsed.use_positional_quiet_ordering = enabled;
            else if (key == "StrategicQuietOrdering") parsed.use_strategic_quiet_ordering = enabled;
            else if (key == "StrategicQuietOpeningOnly") parsed.strategic_quiet_opening_only = enabled;
            else if (key == "StrategicContinuationBias") parsed.use_strategic_continuation_bias = enabled;
            else if (key == "ExactTablebase") parsed.use_exact_tablebase = enabled;
            else if (key == "ExactTablebaseProbeSearch") parsed.exact_tablebase_probe_search = enabled;
            else if (key == "ExactEndgameSolver") parsed.use_exact_endgame_solver = enabled;
            else if (key == "ExactEndgameSafeProbeOnly") parsed.exact_endgame_safe_probe_only = enabled;
            else if (key == "Aspiration") parsed.use_aspiration_windows = enabled;
            else if (key == "FullCapacityTT") parsed.use_full_capacity_tt = enabled;
            else if (key == "AgeAwareTTReplacement") parsed.use_age_aware_tt_replacement = enabled;
            else if (key == "DepthPreferredTTUpdates") parsed.use_depth_preferred_tt_updates = enabled;
            else if (key == "LMR") parsed.use_late_move_reductions = enabled;
            else if (key == "DynamicLMR") parsed.use_dynamic_lmr = enabled;
            else if (key == "RussianLMRv2") parsed.use_russian_lmr_v2 = enabled;
            else if (key == "LMRPriorityGuard") parsed.use_lmr_priority_guard = enabled;
            else if (key == "LMRForcingCaptureGuard") parsed.use_lmr_forcing_capture_guard = enabled;
            else if (key == "QuiescenceTT") parsed.use_quiescence_tt = enabled;
            else if (key == "QuiescenceTTExactOnly") parsed.quiescence_tt_exact_only = enabled;
            else if (key == "QuiescenceCaptureMalus") parsed.use_quiescence_capture_malus = enabled;
            else if (key == "PromotionQuiescence") parsed.use_promotion_quiescence = enabled;
            else if (key == "TacticalExtensions") parsed.use_tactical_extensions = enabled;
            else if (key == "ForcedReplyExtensions") parsed.use_forced_reply_extensions = enabled;
            else if (key == "Phase28ExtensionPolicy") parsed.use_phase28_extension_policy = enabled;
            else if (key == "PromotionExtensions") parsed.use_promotion_extensions = enabled;
            else if (key == "PhaseAwarePromotionExtension") parsed.use_phase_aware_promotion_extension = enabled;
            else if (key == "SingleReplyExtensions") parsed.use_single_reply_extensions = enabled;
            else if (key == "SingleReplyQuietOnly") parsed.single_reply_quiet_only = enabled;
            else if (key == "CaptureSignatureHistory") parsed.use_capture_signature_history = enabled;
            else if (key == "CaptureContinuationHistory") parsed.use_capture_continuation_history = enabled;
            else if (key == "FollowupHistory") parsed.use_followup_history = enabled;
            else if (key == "PieceTypeHistory") parsed.use_piece_type_history = enabled;
            else if (key == "PromotionThreatOrdering") parsed.use_promotion_threat_ordering = enabled;
            else if (key == "RecaptureOrdering") parsed.use_recapture_ordering = enabled;
            else if (key == "RecaptureExtensions") parsed.use_recapture_extensions = enabled;
            else if (key == "ForcedLineExtensions") parsed.use_forced_line_extensions = enabled;
            else if (key == "ForcingQuietLMRGuard") parsed.use_forcing_quiet_lmr_guard = enabled;
            else if (key == "QuietSacrificeExtensions") parsed.use_quiet_sacrifice_extensions = enabled;
            else if (key == "EndgameReplyOrdering") parsed.use_endgame_reply_ordering = enabled;
            else if (key == "EndgameLMRGuard") parsed.use_endgame_lmr_guard = enabled;
            else if (key == "Razoring") parsed.use_razoring = enabled;
            else if (key == "StaticFutilityPruning") parsed.use_static_futility_pruning = enabled;
            else if (key == "HistoryGuardedLateMovePruning") parsed.use_history_guarded_late_move_pruning = enabled;
            else if (key == "HistoryPruning") parsed.use_history_pruning = enabled;
            else if (key == "InternalIterativeReduction") parsed.use_internal_iterative_reduction = enabled;
            else if (key == "AdaptiveAspiration") parsed.use_adaptive_aspiration_windows = enabled;
            else parsed.use_late_move_pruning = enabled;
            continue;
        }
        auto set_search_integer = [&](const char* option, int& target, int minimum, int maximum) -> bool {
            if (key != option) return false;
            if (!parse_int_range(target, minimum, maximum)) {
                if (error != nullptr) {
                    *error = "line " + std::to_string(line_number) + ": invalid range for " + key;
                }
                throw std::runtime_error("phase6-range");
            }
            return true;
        };
        try {
            if (set_search_integer("TTAgePenaltyPerGeneration", parsed.tt_age_penalty_per_generation, 1, 64) ||
                set_search_integer("TTExactBoundBonus", parsed.tt_exact_bound_bonus, 0, 32) ||
                set_search_integer("AspirationWindow", parsed.aspiration_window, 8, 5000) ||
                set_search_integer("AspirationMinDepth", parsed.aspiration_min_depth, 1, 64) ||
                set_search_integer("AspirationGrowthPercent", parsed.aspiration_growth_percent, 125, 400) ||
                set_search_integer("AspirationSideBiasPercent", parsed.aspiration_side_bias_percent, 0, 100) ||
                set_search_integer("AspirationVolatilityScalePercent", parsed.aspiration_volatility_scale_percent, 0, 500) ||
                set_search_integer("AspirationMaxWindow", parsed.aspiration_max_window, 8, 5000) ||
                set_search_integer("LMRMinDepth", parsed.lmr_min_depth, 2, 20) ||
                set_search_integer("LMRMoveThreshold", parsed.lmr_move_threshold, 1, 32) ||
                set_search_integer("LMRHistoryThreshold", parsed.lmr_history_threshold, -16384, 16384) ||
                set_search_integer("LMRDeepDepth", parsed.lmr_deep_depth, 2, 32) ||
                set_search_integer("LMRDeepMoveThreshold", parsed.lmr_deep_move_threshold, 1, 48) ||
                set_search_integer("LMRDeepHistoryThreshold", parsed.lmr_deep_history_threshold, -16384, 16384) ||
                set_search_integer("LMRMaxReduction", parsed.lmr_max_reduction, 1, 3) ||
                set_search_integer("LMRPhaseMinPieces", parsed.lmr_phase_min_pieces, 0, 24) ||
                set_search_integer("LMRPhaseMaxPieces", parsed.lmr_phase_max_pieces, 0, 24) ||
                set_search_integer("LMRPhaseMaxKings", parsed.lmr_phase_max_kings, 0, 24) ||
                set_search_integer("LMRPhaseMinDepth", parsed.lmr_phase_min_depth, 2, 12) ||
                set_search_integer("LMRPhaseMoveThreshold", parsed.lmr_phase_move_threshold, 1, 32) ||
                set_search_integer("LMRProtectedHistoryThreshold", parsed.lmr_protected_history_threshold, -16384, 16384) ||
                set_search_integer("LMRNegativeHistoryThreshold", parsed.lmr_negative_history_threshold, -16384, 16384) ||
                set_search_integer("LMRPhaseDeepDepth", parsed.lmr_phase_deep_depth, 2, 24) ||
                set_search_integer("LMRPhaseDeepMoveThreshold", parsed.lmr_phase_deep_move_threshold, 1, 48) ||
                set_search_integer("RazorMaxDepth", parsed.razor_max_depth, 1, 3) ||
                set_search_integer("RazorMarginBase", parsed.razor_margin_base, 0, 1000) ||
                set_search_integer("RazorMarginPerDepth", parsed.razor_margin_per_depth, 0, 1000) ||
                set_search_integer("RazorMinPieces", parsed.razor_min_pieces, 0, 24) ||
                set_search_integer("RazorMaxPieces", parsed.razor_max_pieces, 0, 24) ||
                set_search_integer("RazorMaxTimeMs", parsed.razor_max_time_ms, 0, 60'000) ||
                set_search_integer("FutilityMaxDepth", parsed.futility_max_depth, 1, 3) ||
                set_search_integer("FutilityMarginBase", parsed.futility_margin_base, 0, 1000) ||
                set_search_integer("FutilityMarginPerDepth", parsed.futility_margin_per_depth, 0, 1000) ||
                set_search_integer("FutilityMinPieces", parsed.futility_min_pieces, 0, 24) ||
                set_search_integer("FutilityMaxPieces", parsed.futility_max_pieces, 0, 24) ||
                set_search_integer("LateMovePruningMaxDepth", parsed.late_move_pruning_max_depth, 1, 4) ||
                set_search_integer("LateMovePruningBaseMoves", parsed.late_move_pruning_base_moves, 2, 32) ||
                set_search_integer("LateMovePruningHistoryThreshold", parsed.late_move_pruning_history_threshold, -16384, 16384) ||
                set_search_integer("LateMovePruningMinPieces", parsed.late_move_pruning_min_pieces, 0, 24) ||
                set_search_integer("LateMovePruningMaxPieces", parsed.late_move_pruning_max_pieces, 0, 24) ||
                set_search_integer("HistoryPruningMaxDepth", parsed.history_pruning_max_depth, 1, 4) ||
                set_search_integer("HistoryPruningMoveThreshold", parsed.history_pruning_move_threshold, 2, 32) ||
                set_search_integer("HistoryPruningThreshold", parsed.history_pruning_threshold, -16384, 16384) ||
                set_search_integer("HistoryPruningMinPieces", parsed.history_pruning_min_pieces, 0, 24) ||
                set_search_integer("HistoryPruningMaxPieces", parsed.history_pruning_max_pieces, 0, 24) ||
                set_search_integer("IIRMinDepth", parsed.iir_min_depth, 4, 20) ||
                set_search_integer("IIRReduction", parsed.iir_reduction, 1, 2) ||
                set_search_integer("IIRMaxPieces", parsed.iir_max_pieces, 0, 24) ||
                set_search_integer("FollowupHistoryWeight", parsed.followup_history_weight, 0, 300) ||
                set_search_integer("PieceTypeHistoryWeight", parsed.piece_type_history_weight, 0, 300) ||
                set_search_integer("PromotionThreatOrderBonus", parsed.promotion_threat_order_bonus, 0, 200000) ||
                set_search_integer("RecaptureOrderBonus", parsed.recapture_order_bonus, 0, 200000) ||
                set_search_integer("RecaptureExtensionMaxDepth", parsed.recapture_extension_max_depth, 1, 16) ||
                set_search_integer("ForcedLineExtensionMaxDepth", parsed.forced_line_extension_max_depth, 1, 24) ||
                set_search_integer("QuietSacrificeExtensionMaxDepth", parsed.quiet_sacrifice_extension_max_depth, 1, 16) ||
                set_search_integer("EndgameReplyOrderMaxPieces", parsed.endgame_reply_order_max_pieces, 2, 12) ||
                set_search_integer("EndgameReplyOrderWeight", parsed.endgame_reply_order_weight, 0, 400) ||
                set_search_integer("EndgameLMRGuardReplyThreshold", parsed.endgame_lmr_guard_reply_threshold, 1, 8) ||
                set_search_integer("TacticalMaxExtensions", parsed.tactical_max_extensions, 0, 8) ||
                set_search_integer("PromotionExtensionMaxDepth", parsed.promotion_extension_max_depth, 0, 16) ||
                set_search_integer("PromotionExtensionExtraMaxPieces", parsed.promotion_extension_extra_max_pieces, 0, 24) ||
                set_search_integer("PromotionExtensionExtraMaxKings", parsed.promotion_extension_extra_max_kings, 0, 24) ||
                set_search_integer("SingleReplyExtensionMaxDepth", parsed.single_reply_extension_max_depth, 0, 16) ||
                set_search_integer("QuiescencePromotionMaxExtensions", parsed.quiescence_promotion_max_extensions, 0, 4) ||
                set_search_integer("EvalStrategicMinPieces", parsed.evaluation_weights.strategic_min_pieces, 0, 24) ||
                set_search_integer("EvalStrategicMaxPieces", parsed.evaluation_weights.strategic_max_pieces, 0, 24) ||
                set_search_integer("EvalStrategicMaxKings", parsed.evaluation_weights.strategic_max_kings, 0, 24) ||
                set_search_integer("StrategicEvaluationMinTimeMs", parsed.strategic_evaluation_min_time_ms, 0, 10000)) {
                if (parsed.lmr_phase_min_pieces > parsed.lmr_phase_max_pieces ||
                    parsed.razor_min_pieces > parsed.razor_max_pieces ||
                    parsed.futility_min_pieces > parsed.futility_max_pieces) {
                    if (error != nullptr) *error = "line " + std::to_string(line_number) + ": pruning piece range is invalid";
                    return false;
                }
                if (parsed.evaluation_weights.strategic_min_pieces > parsed.evaluation_weights.strategic_max_pieces) {
                    if (error != nullptr) *error = "line " + std::to_string(line_number) + ": strategic piece range is invalid";
                    return false;
                }
                continue;
            }
        } catch (const std::runtime_error&) {
            return false;
        }

        int* target = nullptr;
        if (key == "ExactTablebaseMaxPieces") target = &parsed.exact_tablebase_max_pieces;
        else if (key == "ExactEndgameMaxPieces") target = &parsed.exact_endgame_max_pieces;
        else if (key == "QuietOrderWeight") target = &parsed.quiet_order_weight;
        else if (key == "PositionalQuietMaxPly") target = &parsed.positional_quiet_max_ply;
        else if (key == "StrategicQuietOrderWeight") target = &parsed.strategic_quiet_order_weight;
        else if (key == "StrategicQuietMaxPly") target = &parsed.strategic_quiet_max_ply;
        else if (key == "StrategicContinuationWeight") target = &parsed.strategic_continuation_weight;
        else if (key == "CaptureContinuationWeight") target = &parsed.capture_continuation_weight;
        else if (key == "QuietCenter") target = &parsed.quiet_ordering_weights.center;
        else if (key == "QuietSupport") target = &parsed.quiet_ordering_weights.support;
        else if (key == "QuietForwardLanes") target = &parsed.quiet_ordering_weights.forward_lanes;
        else if (key == "QuietKingMobility") target = &parsed.quiet_ordering_weights.king_mobility;
        else if (key == "QuietEdgePenalty") target = &parsed.quiet_ordering_weights.edge_entry;
        else if (key == "QuietHomePenalty") target = &parsed.quiet_ordering_weights.home_rank_departure;
        else if (key == "QuietAdvancement") target = &parsed.quiet_ordering_weights.advancement;
        else if (key == "QuietPromotion") target = &parsed.quiet_ordering_weights.promotion;
        else if (key == "EvalMaterial") target = &parsed.evaluation_weights.material;
        else if (key == "EvalCenter") target = &parsed.evaluation_weights.center;
        else if (key == "EvalAdvancement") target = &parsed.evaluation_weights.advancement;
        else if (key == "EvalPromotion") target = &parsed.evaluation_weights.promotion_potential;
        else if (key == "EvalBackRank") target = &parsed.evaluation_weights.back_rank;
        else if (key == "EvalMobility") target = &parsed.evaluation_weights.mobility;
        else if (key == "EvalKingActivity") target = &parsed.evaluation_weights.king_activity;
        else if (key == "EvalRestriction") target = &parsed.evaluation_weights.restriction;
        else if (key == "EvalTactical") target = &parsed.evaluation_weights.tactical_pressure;
        else if (key == "EvalPhase") target = &parsed.evaluation_weights.phase_adjustment;
        else if (key == "EvalStructure") target = &parsed.evaluation_weights.structure;
        else if (key == "EvalSupportStructure") target = &parsed.evaluation_weights.support_structure;
        else if (key == "EvalIsolation") target = &parsed.evaluation_weights.isolation;
        else if (key == "EvalPromotionLanes") target = &parsed.evaluation_weights.promotion_lanes;
        else if (key == "EvalEdgePassivity") target = &parsed.evaluation_weights.edge_passivity;
        else if (key == "EvalPhaseRepeat") target = &parsed.evaluation_weights.phase_adjustment_repeat;
        else if (key == "EvalOpeningCenterScale") target = &parsed.evaluation_weights.opening_center_scale;
        else if (key == "EvalOpeningBackRankScale") target = &parsed.evaluation_weights.opening_back_rank_scale;
        else if (key == "EvalMiddlegameStructureScale") target = &parsed.evaluation_weights.middlegame_structure_scale;
        else if (key == "EvalEndgameKingScale") target = &parsed.evaluation_weights.endgame_king_scale;
        else if (key == "EvalEndgameMobilityScale") target = &parsed.evaluation_weights.endgame_mobility_scale;
        else if (key == "EvalEndgameRestrictionScale") target = &parsed.evaluation_weights.endgame_restriction_scale;
        else if (key == "EvalEndgamePromotionScale") target = &parsed.evaluation_weights.endgame_promotion_scale;
        else if (key == "EvalKingConfinement") target = &parsed.evaluation_weights.king_confinement;
        else if (key == "EvalPromotionRace") target = &parsed.evaluation_weights.promotion_race;
        else if (key == "EvalWingBalance") target = &parsed.evaluation_weights.wing_balance;
        else if (key == "EvalRearSupport") target = &parsed.evaluation_weights.rear_support;
        else if (key == "EvalAdvancedExposure") target = &parsed.evaluation_weights.advanced_exposure;
        else if (key == "EvalDiagonalControl") target = &parsed.evaluation_weights.diagonal_control;
        else if (key == "EvalReserveTempo") target = &parsed.evaluation_weights.reserve_tempo;
        else if (key == "EvalSpacePressure") target = &parsed.evaluation_weights.space_pressure;
        else if (key == "EvalStrategicPST") target = &parsed.evaluation_weights.strategic_pst;
        else {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": unknown option " + key;
            return false;
        }
        if (!parse_int_value(*target)) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": value must be 0..300";
            return false;
        }
        if (key == "PositionalQuietMaxPly" && parsed.positional_quiet_max_ply > kMaxSearchPly) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": PositionalQuietMaxPly must be 0..96";
            return false;
        }
        if (key == "StrategicQuietMaxPly" && parsed.strategic_quiet_max_ply > kMaxSearchPly) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": StrategicQuietMaxPly must be 0..96";
            return false;
        }
        if (key == "ExactTablebaseMaxPieces" &&
            (parsed.exact_tablebase_max_pieces < 1 || parsed.exact_tablebase_max_pieces > 6)) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": ExactTablebaseMaxPieces must be 1..6";
            return false;
        }
        if (key == "ExactEndgameMaxPieces" &&
            (parsed.exact_endgame_max_pieces < 2 || parsed.exact_endgame_max_pieces > 6)) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": ExactEndgameMaxPieces must be 2..6";
            return false;
        }
    }
    options = parsed;
    return true;
}

bool load_phase6_search_config_file(
    const std::string& path,
    SearchOptions& options,
    std::string* error) {
    if (path.empty() || path == "-") return true;
    std::ifstream input(path);
    if (!input) {
        if (error != nullptr) *error = "cannot open phase6 config: " + path;
        return false;
    }
    return load_phase6_search_config(input, options, error);
}

}  // namespace albay
