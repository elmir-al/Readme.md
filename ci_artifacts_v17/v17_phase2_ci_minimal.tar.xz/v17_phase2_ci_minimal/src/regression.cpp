/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/regression.hpp"

#include "albay/notation.hpp"

#include <algorithm>
#include <cstdlib>
#include <charconv>
#include <fstream>
#include <sstream>

namespace albay {
namespace {

[[nodiscard]] std::string trim(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
        return {};
    }
    const auto last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

[[nodiscard]] bool parse_int(std::string_view text, int& value) {
    const auto [pointer, error] = std::from_chars(text.data(), text.data() + text.size(), value);
    return error == std::errc{} && pointer == text.data() + text.size();
}

[[nodiscard]] std::vector<std::string> split(std::string_view text, char separator) {
    std::vector<std::string> result;
    std::size_t start = 0;
    while (start <= text.size()) {
        const std::size_t end = text.find(separator, start);
        result.push_back(trim(std::string(text.substr(
            start, end == std::string_view::npos ? text.size() - start : end - start))));
        if (end == std::string_view::npos) {
            break;
        }
        start = end + 1;
    }
    return result;
}

}  // namespace

bool load_regression_suite(
    std::istream& input,
    std::vector<RegressionCase>& cases,
    std::string* error) {
    cases.clear();
    std::string line;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned.front() == '#') {
            continue;
        }
        const std::vector<std::string> fields = split(cleaned, '\t');
        if (fields.size() != 7) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": expected 7 tab-separated fields";
            }
            return false;
        }

        RegressionCase test_case{};
        test_case.id = fields[0];
        if (fields[1] == "objective") {
            test_case.kind = RegressionCaseKind::Objective;
        } else if (fields[1] == "baseline") {
            test_case.kind = RegressionCaseKind::SearchBaseline;
        } else {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": kind must be objective or baseline";
            }
            return false;
        }
        if (!parse_int(fields[2], test_case.depth) || test_case.depth < 1 ||
            test_case.depth > kMaxSearchDepth) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": invalid depth";
            }
            return false;
        }
        test_case.apf = fields[3];
        test_case.accepted_moves = split(fields[4], ';');
        test_case.accepted_moves.erase(
            std::remove_if(test_case.accepted_moves.begin(), test_case.accepted_moves.end(),
                [](const std::string& value) { return value.empty() || value == "*"; }),
            test_case.accepted_moves.end());
        if (!parse_int(fields[5], test_case.minimum_score) ||
            !parse_int(fields[6], test_case.maximum_score) ||
            test_case.minimum_score > test_case.maximum_score) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": invalid score range";
            }
            return false;
        }
        std::string parse_error;
        if (!parse_apf(test_case.apf, &parse_error).has_value()) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": " + parse_error;
            }
            return false;
        }
        cases.push_back(std::move(test_case));
    }
    if (cases.empty()) {
        if (error != nullptr) {
            *error = "regression suite contains no cases";
        }
        return false;
    }
    return true;
}

bool load_regression_suite_file(
    const std::string& path,
    std::vector<RegressionCase>& cases,
    std::string* error) {
    std::ifstream input(path);
    if (!input) {
        if (error != nullptr) {
            *error = "cannot open regression suite: " + path;
        }
        return false;
    }
    return load_regression_suite(input, cases, error);
}

RegressionCaseResult run_regression_case(
    const RegressionCase& test_case,
    const SearchOptions& options) {
    RegressionCaseResult result{};
    result.id = test_case.id;
    std::string parse_error;
    const auto parsed = parse_apf(test_case.apf, &parse_error);
    if (!parsed.has_value()) {
        result.message = parse_error;
        return result;
    }

    SearchLimits limits{};
    limits.depth = test_case.depth;
    Searcher searcher;
    const SearchResult search_result = searcher.search(*parsed, limits, options);
    result.score = search_result.score;
    result.completed_depth = search_result.completed_depth;
    result.nodes = search_result.nodes;
    if (search_result.best_move.has_value()) {
        result.best_move = move_to_string(*search_result.best_move);
    }

    const bool move_ok = test_case.accepted_moves.empty() ||
        std::find(test_case.accepted_moves.begin(), test_case.accepted_moves.end(), result.best_move) !=
            test_case.accepted_moves.end();
    const bool score_ok = result.score >= test_case.minimum_score &&
        result.score <= test_case.maximum_score;
    const bool depth_ok = result.completed_depth == test_case.depth ||
        std::abs(result.score) >= kMateThreshold;
    result.passed = move_ok && score_ok && depth_ok;
    if (!move_ok) {
        result.message = "unexpected move";
    } else if (!score_ok) {
        result.message = "score outside expected range";
    } else if (!depth_ok) {
        result.message = "requested depth was not completed";
    } else {
        result.message = "ok";
    }
    return result;
}

}  // namespace albay
