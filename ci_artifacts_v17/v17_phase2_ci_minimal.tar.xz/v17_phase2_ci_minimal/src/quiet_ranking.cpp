/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/quiet_ranking.hpp"

#include "albay/geometry.hpp"

#include <algorithm>
#include <array>
#include <bit>

namespace albay {
namespace {

[[nodiscard]] int center_value(Square square) noexcept {
    const BoardCoordinate coordinate = coordinate_of(square);
    const int edge_distance = std::min(
        std::min(coordinate.file, 7 - coordinate.file),
        std::min(coordinate.rank, 7 - coordinate.rank));
    if (edge_distance >= 2) return 3;
    if (edge_distance == 1) return 1;
    return -1;
}

[[nodiscard]] bool empty_after_move(
    const Position& position, const Move& move, Square square) noexcept {
    if (square == move.from) return true;
    if (square == move.to) return false;
    return position.is_empty(square);
}

[[nodiscard]] int support_after_move(
    const Position& position, Color color, const Move& move) noexcept {
    Bitboard friendly = position.pieces(color);
    friendly &= ~bit(move.from);
    friendly |= bit(move.to);
    int count = 0;
    constexpr std::array<std::pair<int, int>, 4> directions{{
        {-1, -1}, {1, -1}, {-1, 1}, {1, 1},
    }};
    for (const auto& [file_delta, rank_delta] : directions) {
        const Square target = step(move.to, file_delta, rank_delta);
        if (is_valid_square(target) && (friendly & bit(target)) != 0) ++count;
    }
    return count;
}

}  // namespace

QuietMoveFeatures extract_quiet_move_features(
    const Position& position, const Move& move) noexcept {
    QuietMoveFeatures result{};
    if (move.is_capture() || !is_valid_square(move.from) || !is_valid_square(move.to)) {
        return result;
    }

    const Color mover = position.side_to_move();
    const BoardCoordinate from = coordinate_of(move.from);
    const BoardCoordinate to = coordinate_of(move.to);
    result.center_delta = center_value(move.to) - center_value(move.from);
    result.friendly_support = support_after_move(position, mover, move);
    result.promotion = move.is_promotion() ? 1 : 0;

    if (move.moving_piece_was_king()) {
        constexpr std::array<std::pair<int, int>, 4> directions{{
            {-1, -1}, {1, -1}, {-1, 1}, {1, 1},
        }};
        for (const auto& [file_delta, rank_delta] : directions) {
            Square cursor = step(move.to, file_delta, rank_delta);
            while (is_valid_square(cursor) && empty_after_move(position, move, cursor)) {
                ++result.king_mobility;
                cursor = step(cursor, file_delta, rank_delta);
            }
        }
        return result;
    }

    const int forward = mover == Color::White ? 1 : -1;
    for (const int file_delta : {-1, 1}) {
        const Square target = step(move.to, file_delta, forward);
        if (is_valid_square(target) && empty_after_move(position, move, target)) {
            ++result.forward_lanes;
        }
    }
    const bool target_edge = to.file == 0 || to.file == 7;
    const bool source_edge = from.file == 0 || from.file == 7;
    if (target_edge && !source_edge && to.rank >= 2 && to.rank <= 5) {
        result.edge_entry = 1;
    }

    const int total_pieces = std::popcount(position.occupied());
    const bool leaving_home_rank = mover == Color::White ? from.rank == 0 : from.rank == 7;
    if (total_pieces >= 20 && leaving_home_rank && !move.is_promotion()) {
        result.home_rank_departure = 1;
    }
    const int from_advance = mover == Color::White ? from.rank : 7 - from.rank;
    const int to_advance = mover == Color::White ? to.rank : 7 - to.rank;
    result.advancement_delta = to_advance - from_advance;
    return result;
}

int score_quiet_move(
    const QuietMoveFeatures& features, const QuietOrderingWeights& weights) noexcept {
    return features.center_delta * weights.center +
        features.friendly_support * weights.support +
        features.forward_lanes * weights.forward_lanes +
        features.king_mobility * weights.king_mobility -
        features.edge_entry * weights.edge_entry -
        features.home_rank_departure * weights.home_rank_departure +
        features.advancement_delta * weights.advancement +
        features.promotion * weights.promotion;
}

int score_quiet_move(
    const Position& position,
    const Move& move,
    const QuietOrderingWeights& weights) noexcept {
    return score_quiet_move(extract_quiet_move_features(position, move), weights);
}

}  // namespace albay
