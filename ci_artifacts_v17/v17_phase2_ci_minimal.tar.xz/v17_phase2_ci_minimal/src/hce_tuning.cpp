/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/hce_tuning.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <limits>
#include <numeric>

namespace albay {
namespace {

using WeightMember = int EvaluationWeights::*;
constexpr std::array<WeightMember, kPhase30FeatureCount> kWeightMembers{{
    &EvaluationWeights::material,
    &EvaluationWeights::center,
    &EvaluationWeights::advancement,
    &EvaluationWeights::promotion_potential,
    &EvaluationWeights::back_rank,
    &EvaluationWeights::mobility,
    &EvaluationWeights::king_activity,
    &EvaluationWeights::restriction,
    &EvaluationWeights::tactical_pressure,
    &EvaluationWeights::phase_adjustment,
}};

[[nodiscard]] double sigmoid(double value) noexcept {
    if (value >= 0.0) {
        const double e = std::exp(-value);
        return 1.0 / (1.0 + e);
    }
    const double e = std::exp(value);
    return e / (1.0 + e);
}

[[nodiscard]] int score_sign(int score, int neutral_band = 20) noexcept {
    if (score > neutral_band) return 1;
    if (score < -neutral_band) return -1;
    return 0;
}

[[nodiscard]] std::int16_t clamp_feature(Score value) noexcept {
    return static_cast<std::int16_t>(std::clamp<int>(value, -32767, 32767));
}

void write_metrics(std::ostream& out, const char* name, const Phase30LossMetrics& metrics) {
    out << '"' << name << "\":{\"samples\":" << metrics.samples
        << ",\"cross_entropy\":" << metrics.cross_entropy
        << ",\"mean_absolute_error\":" << metrics.mean_absolute_error
        << ",\"root_mean_square_error\":" << metrics.root_mean_square_error
        << ",\"sign_accuracy\":" << metrics.sign_accuracy << '}';
}

}  // namespace

std::array<std::int16_t, kPhase30FeatureCount> phase30_extract_features(
    const Position& position) {
    const EvaluationBreakdown b = evaluate_breakdown(position, false, false, false);
    return {{
        clamp_feature(b.material),
        clamp_feature(b.center),
        clamp_feature(b.advancement),
        clamp_feature(b.promotion_potential),
        clamp_feature(b.back_rank),
        clamp_feature(b.mobility),
        clamp_feature(b.king_activity),
        clamp_feature(b.restriction),
        clamp_feature(b.tactical_pressure),
        clamp_feature(b.phase_adjustment),
    }};
}

int phase30_model_score(
    const std::array<std::int16_t, kPhase30FeatureCount>& features,
    const EvaluationWeights& weights) noexcept {
    int result = 0;
    for (std::size_t index = 0; index < kPhase30FeatureCount; ++index) {
        result += static_cast<int>((static_cast<long long>(features[index]) *
            (weights.*kWeightMembers[index])) / 100LL);
    }
    return result;
}

bool phase30_record_is_stable(
    const HceRecord& record,
    const Phase30FilterOptions& options,
    int* static_score_white,
    std::string* reason) {
    auto reject = [reason](const char* text) {
        if (reason != nullptr) *reason = text;
        return false;
    };
    if ((record.flags & HceTeacherScoreKnown) == 0 ||
        record.teacher_score_white == kHceUnknownTeacherScore) {
        return reject("missing_teacher");
    }
    if ((record.flags & HceLegalPosition) == 0 ||
        (options.require_quiet && (record.flags & HceQuietPosition) == 0) ||
        (options.require_non_forced && (record.flags & HceNonForcedPosition) == 0)) {
        return reject("flags");
    }
    if (record.teacher_depth < options.minimum_teacher_depth) return reject("depth");
    if (std::abs(static_cast<int>(record.teacher_score_white)) >
        options.maximum_absolute_teacher_score) return reject("score");
    if (record.no_progress_plies > options.maximum_no_progress_plies) return reject("no_progress");

    const Position position = hce_record_position(record);
    const int static_score = evaluate_default(position) *
        (position.side_to_move() == Color::White ? 1 : -1);
    if (static_score_white != nullptr) *static_score_white = static_score;
    const int teacher = static_cast<int>(record.teacher_score_white);
    if (std::abs(static_score - teacher) > options.maximum_static_residual) {
        return reject("residual");
    }
    if (options.require_sign_agreement && std::abs(teacher) > options.neutral_teacher_band &&
        score_sign(static_score, options.neutral_teacher_band) != score_sign(teacher, options.neutral_teacher_band)) {
        return reject("sign");
    }
    if (reason != nullptr) reason->clear();
    return true;
}

bool phase30_filter_dataset(
    const std::vector<HceRecord>& input,
    const Phase30FilterOptions& options,
    std::vector<HceRecord>& output,
    Phase30FilterReport& report,
    std::string* error) {
    output.clear();
    output.reserve(input.size());
    report = {};
    report.input_records = input.size();
    for (const HceRecord& record : input) {
        std::string reason;
        if (!phase30_record_is_stable(record, options, nullptr, &reason)) {
            if (reason == "missing_teacher") ++report.rejected_missing_teacher;
            else if (reason == "flags") ++report.rejected_flags;
            else if (reason == "depth") ++report.rejected_depth;
            else if (reason == "score") ++report.rejected_score;
            else if (reason == "residual") ++report.rejected_residual;
            else if (reason == "sign") ++report.rejected_sign;
            else if (reason == "no_progress") ++report.rejected_no_progress;
            continue;
        }
        output.push_back(record);
        ++report.accepted_records;
        ++report.phase_counts[static_cast<std::size_t>(record.phase)];
        ++report.split_counts[static_cast<std::size_t>(record.split)];
    }
    if (output.empty()) {
        if (error != nullptr) *error = "Phase 30 stability filter rejected every record";
        return false;
    }
    return true;
}

std::vector<Phase30FeatureSample> phase30_build_feature_samples(
    const std::vector<HceRecord>& records) {
    std::vector<Phase30FeatureSample> samples;
    samples.reserve(records.size());
    for (const HceRecord& record : records) {
        if ((record.flags & HceTeacherScoreKnown) == 0 ||
            record.teacher_score_white == kHceUnknownTeacherScore) continue;
        const Position position = hce_record_position(record);
        samples.push_back(Phase30FeatureSample{
            phase30_extract_features(position), record.teacher_score_white,
            record.split, record.phase, record.group_id});
    }
    return samples;
}

Phase30LossMetrics phase30_loss_metrics(
    const std::vector<Phase30FeatureSample>& samples,
    HceSplit split,
    const EvaluationWeights& weights,
    double score_scale,
    std::size_t maximum_samples) {
    Phase30LossMetrics metrics{};
    if (score_scale <= 0.0) return metrics;
    long double cross_entropy = 0.0;
    long double absolute_error = 0.0;
    long double square_error = 0.0;
    std::uint64_t sign_matches = 0;
    constexpr double epsilon = 1.0e-12;
    for (const Phase30FeatureSample& sample : samples) {
        if (sample.split != split) continue;
        if (maximum_samples != 0 && metrics.samples >= maximum_samples) break;
        const int prediction_score = phase30_model_score(sample.features, weights);
        const int teacher_score = sample.teacher_score_white;
        const double target = std::clamp(sigmoid(static_cast<double>(teacher_score) / score_scale),
                                         epsilon, 1.0 - epsilon);
        const double prediction = std::clamp(sigmoid(static_cast<double>(prediction_score) / score_scale),
                                             epsilon, 1.0 - epsilon);
        cross_entropy -= target * std::log(prediction) + (1.0 - target) * std::log(1.0 - prediction);
        const long double error_value = static_cast<long double>(prediction_score - teacher_score);
        absolute_error += std::abs(error_value);
        square_error += error_value * error_value;
        sign_matches += score_sign(prediction_score) == score_sign(teacher_score);
        ++metrics.samples;
    }
    if (metrics.samples == 0) return metrics;
    const long double count = static_cast<long double>(metrics.samples);
    metrics.cross_entropy = static_cast<double>(cross_entropy / count);
    metrics.mean_absolute_error = static_cast<double>(absolute_error / count);
    metrics.root_mean_square_error = static_cast<double>(std::sqrt(square_error / count));
    metrics.sign_accuracy = static_cast<double>(sign_matches) / static_cast<double>(metrics.samples);
    return metrics;
}

Phase30TuneReport phase30_coordinate_tune(
    const std::vector<Phase30FeatureSample>& samples,
    const Phase30TuneOptions& options,
    EvaluationWeights initial) {
    Phase30TuneReport report{};
    report.baseline = initial;
    report.candidate = initial;
    report.train_before = phase30_loss_metrics(samples, HceSplit::Train, initial,
        options.score_scale, options.maximum_training_samples);
    report.validation_before = phase30_loss_metrics(samples, HceSplit::Validation, initial,
        options.score_scale);
    report.holdout_before = phase30_loss_metrics(samples, HceSplit::Holdout, initial,
        options.score_scale);

    int step = std::max(options.initial_step, 1);
    double best_train = report.train_before.cross_entropy;
    double best_validation = report.validation_before.cross_entropy;
    for (int pass = 0; pass < std::max(options.passes, 0); ++pass) {
        bool changed = false;
        for (const WeightMember member : kWeightMembers) {
            EvaluationWeights local_best = report.candidate;
            double local_train = best_train;
            double local_validation = best_validation;
            for (const int direction : {-1, 1}) {
                EvaluationWeights trial = report.candidate;
                trial.*member = std::clamp(trial.*member + direction * step,
                    options.minimum_weight, options.maximum_weight);
                if (trial.*member == report.candidate.*member) continue;
                const auto train = phase30_loss_metrics(samples, HceSplit::Train, trial,
                    options.score_scale, options.maximum_training_samples);
                if (train.samples == 0 || train.cross_entropy > best_train + 1.0e-8) continue;
                const auto validation = phase30_loss_metrics(samples, HceSplit::Validation, trial,
                    options.score_scale);
                if (validation.samples != 0 &&
                    validation.cross_entropy + options.validation_epsilon < local_validation) {
                    local_best = trial;
                    local_train = train.cross_entropy;
                    local_validation = validation.cross_entropy;
                }
            }
            if (local_validation + options.validation_epsilon < best_validation) {
                report.candidate = local_best;
                best_train = local_train;
                best_validation = local_validation;
                changed = true;
                ++report.accepted_changes;
            }
        }
        ++report.passes_completed;
        if (!changed) step = std::max(step / 2, 1);
    }
    report.train_after = phase30_loss_metrics(samples, HceSplit::Train, report.candidate,
        options.score_scale, options.maximum_training_samples);
    report.validation_after = phase30_loss_metrics(samples, HceSplit::Validation, report.candidate,
        options.score_scale);
    report.holdout_after = phase30_loss_metrics(samples, HceSplit::Holdout, report.candidate,
        options.score_scale);
    return report;
}

void write_phase30_json_report(
    const std::string& path,
    const Phase30FilterReport* filter,
    const Phase30TuneReport* tuning) {
    std::ofstream out(path, std::ios::trunc);
    if (!out) return;
    out.precision(12);
    out << "{\n";
    bool comma = false;
    if (filter != nullptr) {
        out << "\"filter\":{\"input_records\":" << filter->input_records
            << ",\"accepted_records\":" << filter->accepted_records
            << ",\"rejected_missing_teacher\":" << filter->rejected_missing_teacher
            << ",\"rejected_flags\":" << filter->rejected_flags
            << ",\"rejected_depth\":" << filter->rejected_depth
            << ",\"rejected_score\":" << filter->rejected_score
            << ",\"rejected_residual\":" << filter->rejected_residual
            << ",\"rejected_sign\":" << filter->rejected_sign
            << ",\"rejected_no_progress\":" << filter->rejected_no_progress << '}';
        comma = true;
    }
    if (tuning != nullptr) {
        if (comma) out << ",\n";
        out << "\"tuning\":{";
        write_metrics(out, "train_before", tuning->train_before); out << ',';
        write_metrics(out, "train_after", tuning->train_after); out << ',';
        write_metrics(out, "validation_before", tuning->validation_before); out << ',';
        write_metrics(out, "validation_after", tuning->validation_after); out << ',';
        write_metrics(out, "holdout_before", tuning->holdout_before); out << ',';
        write_metrics(out, "holdout_after", tuning->holdout_after);
        out << ",\"passes_completed\":" << tuning->passes_completed
            << ",\"accepted_changes\":" << tuning->accepted_changes << '}';
    }
    out << "\n}\n";
}

}  // namespace albay
