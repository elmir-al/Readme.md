/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/release.hpp"

#include "albay/c_api.h"
#include "albay/competition.hpp"
#include "albay/movegen.hpp"
#include "albay/perft.hpp"
#include "albay/regression.hpp"
#include "albay/runtime_policy.hpp"
#include "albay/search.hpp"
#include "albay/types.hpp"

#include <array>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <iomanip>
#include <sstream>
#include <string_view>
#include <thread>

namespace albay {
namespace {

void add(ReleaseReport& report, std::string name, bool passed, std::string details) {
    report.checks.push_back({std::move(name), passed, std::move(details)});
}

[[nodiscard]] std::string escape_json(std::string_view text) {
    std::string result;
    for (const char c : text) {
        switch (c) {
            case '\\': result += "\\\\"; break;
            case '"': result += "\\\""; break;
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            default: result += c; break;
        }
    }
    return result;
}

[[nodiscard]] bool wait_for_search(albay_engine* engine) {
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
    while (albay_engine_is_searching(engine) != 0 && std::chrono::steady_clock::now() < deadline) {
        std::this_thread::yield();
    }
    return albay_engine_is_searching(engine) == 0;
}

}  // namespace

int ReleaseReport::passed_count() const noexcept {
    int count = 0;
    for (const auto& check : checks) count += check.passed ? 1 : 0;
    return count;
}

int ReleaseReport::failed_count() const noexcept {
    return static_cast<int>(checks.size()) - passed_count();
}

bool ReleaseReport::passed() const noexcept {
    return failed_count() == 0;
}

ReleaseReport run_release_gate(const ReleaseGateConfig& config) {
    ReleaseReport report{};

    const bool metadata_ok = kEngineName == "Albay Russian Draughts Engine" &&
        kEngineAuthor == "Elmir Hajizada" && !kEngineVersion.empty() &&
        std::string_view(albay_engine_get_name()) == kEngineName &&
        std::string_view(albay_engine_get_author()) == kEngineAuthor &&
        std::string_view(albay_engine_get_version()) == kEngineVersion;
    add(report, "engine_metadata", metadata_ok, metadata_ok ? "name/author/version match" : "metadata mismatch");

    Position initial = Position::initial();
    std::string validation_error;
    const MoveList root_moves = generate_legal_moves(initial);
    const bool core_ok = initial.validate(&validation_error) && root_moves.size() == 7 &&
        initial.key() == initial.recompute_key();
    add(report, "initial_position", core_ok,
        core_ok ? "valid, 7 legal moves, Zobrist consistent" : validation_error);

    bool roundtrip_ok = true;
    for (const Move& move : root_moves) {
        Position copy = initial;
        const auto white = copy.white();
        const auto black = copy.black();
        const auto kings = copy.kings();
        const auto side = copy.side_to_move();
        const auto key = copy.key();
        const auto no_progress = copy.no_progress_plies();
        const auto history = copy.history_size();
        UndoState undo{};
        copy.make_move(move, undo);
        copy.unmake_move(move, undo);
        roundtrip_ok = roundtrip_ok && copy.white() == white && copy.black() == black &&
            copy.kings() == kings && copy.side_to_move() == side && copy.key() == key &&
            copy.no_progress_plies() == no_progress && copy.history_size() == history;
    }
    add(report, "make_unmake_roundtrip", roundtrip_ok,
        roundtrip_ok ? "all initial legal moves restored exactly" : "roundtrip mismatch");

    constexpr std::array<std::uint64_t, 9> expected{
        1, 7, 49, 302, 1469, 7482, 37986, 190146, 929905};
    bool perft_ok = config.perft_depth >= 1 && config.perft_depth <= 8;
    std::ostringstream perft_details;
    if (perft_ok) {
        for (int depth = 1; depth <= config.perft_depth; ++depth) {
            Position position = Position::initial();
            const std::uint64_t nodes = perft(position, depth);
            if (nodes != expected[static_cast<std::size_t>(depth)]) perft_ok = false;
            if (depth > 1) perft_details << ',';
            perft_details << depth << ':' << nodes;
        }
    }
    add(report, "perft_reference", perft_ok, perft_details.str());

    std::vector<RegressionCase> cases;
    std::string error;
    const std::filesystem::path regression_path =
        std::filesystem::path(config.source_root) / "data/tactical_regression.tsv";
    bool regression_ok = load_regression_suite_file(regression_path.string(), cases, &error);
    int regression_passed = 0;
    if (regression_ok) {
        SearchOptions options{};
        options.threads = 1;
        options.active_threads = 1;
        for (const auto& test_case : cases) {
            const auto result = run_regression_case(test_case, options);
            regression_passed += result.passed ? 1 : 0;
            regression_ok = regression_ok && result.passed;
        }
    }
    add(report, "tactical_regression", regression_ok,
        regression_ok ? std::to_string(regression_passed) + "/" + std::to_string(cases.size()) : error);

    std::vector<OpeningPosition> openings;
    const std::filesystem::path opening_path =
        std::filesystem::path(config.source_root) / "data/opening_suite.tsv";
    const bool openings_ok = load_opening_suite_file(opening_path.string(), openings, &error) && openings.size() == 30;
    add(report, "opening_suite", openings_ok,
        openings_ok ? "30 validated APF openings" : error);

    bool smp_ok = true;
    std::ostringstream smp_details;
    for (const int threads : kSupportedThreadCounts) {
        Searcher searcher;
        SearchLimits limits{};
        limits.depth = config.search_depth;
        SearchOptions options{};
        options.threads = threads;
        options.active_threads = threads;
        const SearchResult result = searcher.search(initial, limits, options);
        const bool legal = result.best_move.has_value() && is_legal_move(initial, *result.best_move) &&
            result.completed_depth == config.search_depth;
        smp_ok = smp_ok && legal;
        if (!smp_details.str().empty()) smp_details << ',';
        smp_details << threads << ':' << result.nodes;
    }
    add(report, "supported_thread_counts", smp_ok, smp_details.str());

    RuntimeEnvironment environment{};
    environment.logical_cpu_count = 8;
    const auto normal = select_thread_policy(PerformanceProfile::Analysis, true, 8, environment);
    environment.thermal_status = ThermalStatus::Light;
    const auto light = select_thread_policy(PerformanceProfile::Analysis, true, 8, environment);
    environment.thermal_status = ThermalStatus::Moderate;
    const auto moderate = select_thread_policy(PerformanceProfile::Analysis, true, 8, environment);
    environment.thermal_status = ThermalStatus::Severe;
    const auto severe = select_thread_policy(PerformanceProfile::Analysis, true, 8, environment);
    environment.thermal_status = ThermalStatus::Critical;
    const auto critical = select_thread_policy(PerformanceProfile::Analysis, true, 8, environment);
    const bool runtime_ok = normal.target_threads == 8 && light.target_threads == 6 &&
        moderate.target_threads == 4 && severe.target_threads == 2 && critical.target_threads == 1;
    add(report, "runtime_thread_policy", runtime_ok, "8->6->4->2->1");

    bool lifecycle_ok = true;
    for (int iteration = 0; iteration < config.lifecycle_iterations; ++iteration) {
        albay_engine* engine = albay_engine_create();
        if (engine == nullptr) { lifecycle_ok = false; break; }
        const int threads = kSupportedThreadCounts[static_cast<std::size_t>(iteration) % kSupportedThreadCounts.size()];
        const std::string thread_text = std::to_string(threads);
        lifecycle_ok = lifecycle_ok &&
            albay_engine_set_option(engine, "Threads", thread_text.c_str()) == ALBAY_STATUS_OK;
        albay_search_limits limits{};
        limits.struct_size = sizeof(limits);
        limits.depth = 4;
        lifecycle_ok = lifecycle_ok && albay_engine_start_search(engine, &limits) == ALBAY_STATUS_OK &&
            wait_for_search(engine);
        char move[64]{};
        std::size_t required = 0;
        lifecycle_ok = lifecycle_ok &&
            albay_engine_get_best_move(engine, move, sizeof(move), &required) == ALBAY_STATUS_OK &&
            albay_engine_is_legal_move(engine, move) != 0;
        albay_engine_destroy(engine);
        if (!lifecycle_ok) break;
    }
    add(report, "c_api_lifecycle", lifecycle_ok,
        std::to_string(config.lifecycle_iterations) + " create/search/destroy cycles");

    PairedScoreStatistics paired{};
    paired.add(2.0);
    paired.add(1.5);
    paired.add(1.0);
    paired.add(0.5);
    paired.add(0.0);
    const bool paired_ok = paired.pairs() == 5 && paired.total_points() == 5.0 &&
        paired.mean_game_score() == 0.5 && paired.standard_error_game_score() > 0.0 &&
        paired.elo_lower_95() < 0.0 && paired.elo_upper_95() > 0.0;
    add(report, "paired_statistics", paired_ok, "five-bin paired score accounting and 95% interval");

    return report;
}

void write_release_report_json(const ReleaseReport& report, std::ostream& output) {
    output << "{\n  \"engine\": \"Albay Russian Draughts Engine\",\n"
           << "  \"version\": \"" << kEngineVersion << "\",\n"
           << "  \"passed\": " << (report.passed() ? "true" : "false") << ",\n"
           << "  \"passed_count\": " << report.passed_count() << ",\n"
           << "  \"failed_count\": " << report.failed_count() << ",\n"
           << "  \"checks\": [\n";
    for (std::size_t index = 0; index < report.checks.size(); ++index) {
        const auto& check = report.checks[index];
        output << "    {\"name\": \"" << escape_json(check.name)
               << "\", \"passed\": " << (check.passed ? "true" : "false")
               << ", \"details\": \"" << escape_json(check.details) << "\"}"
               << (index + 1 == report.checks.size() ? "\n" : ",\n");
    }
    output << "  ]\n}\n";
}

}  // namespace albay
