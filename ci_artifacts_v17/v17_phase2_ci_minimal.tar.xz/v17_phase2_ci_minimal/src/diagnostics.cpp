/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/diagnostics.hpp"

#include "albay/geometry.hpp"
#include "albay/movegen.hpp"
#include "albay/notation.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <charconv>
#include <fstream>
#include <sstream>
#include <unordered_map>

namespace albay {
namespace {

constexpr std::array<std::pair<int, int>, 4> kDirections{{
    {-1, -1}, {1, -1}, {-1, 1}, {1, 1},
}};

[[nodiscard]] std::string trim(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

[[nodiscard]] std::vector<std::string> split(std::string_view text, char separator) {
    std::vector<std::string> result;
    std::size_t start = 0;
    while (start <= text.size()) {
        const std::size_t end = text.find(separator, start);
        result.push_back(trim(std::string(text.substr(
            start, end == std::string_view::npos ? text.size() - start : end - start))));
        if (end == std::string_view::npos) break;
        start = end + 1;
    }
    return result;
}

[[nodiscard]] bool parse_score(std::string_view text, Score& value) {
    const auto [pointer, error] = std::from_chars(text.data(), text.data() + text.size(), value);
    return error == std::errc{} && pointer == text.data() + text.size();
}

[[nodiscard]] int friendly_neighbours(const Position& position, Color color, Square square) noexcept {
    int count = 0;
    const Bitboard friendly = position.pieces(color);
    for (const auto& [file_delta, rank_delta] : kDirections) {
        const Square target = step(square, file_delta, rank_delta);
        if (is_valid_square(target) && (friendly & bit(target)) != 0) ++count;
    }
    return count;
}

[[nodiscard]] int man_forward_lanes(const Position& position, Color color, Square square) noexcept {
    const int rank_delta = color == Color::White ? 1 : -1;
    int count = 0;
    for (const int file_delta : {-1, 1}) {
        const Square target = step(square, file_delta, rank_delta);
        if (is_valid_square(target) && position.is_empty(target)) ++count;
    }
    return count;
}

[[nodiscard]] int king_mobility(const Position& position, Square square) noexcept {
    int count = 0;
    for (const auto& [file_delta, rank_delta] : kDirections) {
        Square cursor = step(square, file_delta, rank_delta);
        while (is_valid_square(cursor) && position.is_empty(cursor)) {
            ++count;
            cursor = step(cursor, file_delta, rank_delta);
        }
    }
    return count;
}

[[nodiscard]] std::string classify_result(
    std::string_view shallow,
    std::string_view deep,
    std::string_view external) {
    if (!external.empty() && shallow == deep && deep == external) return "triple_stable";
    if (!external.empty() && shallow != deep && deep == external) return "horizon_error";
    if (!external.empty() && shallow == deep && deep != external) return "engine_disagreement";
    if (shallow != deep) return "depth_unstable";
    return "stable_no_consensus";
}

}  // namespace

PositionFeatureSummary extract_position_features(const Position& position) {
    PositionFeatureSummary result{};
    result.total_pieces = std::popcount(position.occupied());
    result.total_kings = std::popcount(position.kings());
    result.white_men = std::popcount(position.men(Color::White));
    result.black_men = std::popcount(position.men(Color::Black));
    result.white_kings = std::popcount(position.kings(Color::White));
    result.black_kings = std::popcount(position.kings(Color::Black));

    MoveList legal_moves;
    generate_legal_moves(position, legal_moves);
    result.legal_moves = static_cast<int>(legal_moves.size());
    result.mandatory_capture = !legal_moves.empty() && legal_moves[0].is_capture();

    if (result.total_pieces <= 8) {
        result.phase = result.total_kings > 0 ? DiagnosticPhase::KingEndgame : DiagnosticPhase::ManEndgame;
    } else if (result.total_pieces >= 20) {
        result.phase = DiagnosticPhase::Opening;
    } else {
        result.phase = DiagnosticPhase::Middlegame;
    }

    for (const Color color : {Color::White, Color::Black}) {
        Bitboard men = position.men(color);
        while (men != 0) {
            const Square square = static_cast<Square>(std::countr_zero(men));
            men &= men - 1U;
            const int neighbours = friendly_neighbours(position, color, square);
            const int lanes = man_forward_lanes(position, color, square);
            const BoardCoordinate coordinate = coordinate_of(square);
            const int advance = color == Color::White ? coordinate.rank : 7 - coordinate.rank;
            int& isolated = color == Color::White ? result.white_isolated_men : result.black_isolated_men;
            int& blocked = color == Color::White ? result.white_blocked_men : result.black_blocked_men;
            int& supported = color == Color::White ? result.white_supported_men : result.black_supported_men;
            int& promotion = color == Color::White ? result.white_promotion_lanes : result.black_promotion_lanes;
            if (neighbours == 0 && coordinate.rank >= 2 && coordinate.rank <= 5) ++isolated;
            if (lanes == 0) ++blocked;
            if (neighbours > 0) ++supported;
            if (advance >= 4) promotion += lanes;
        }

        Bitboard kings = position.kings(color);
        while (kings != 0) {
            const Square square = static_cast<Square>(std::countr_zero(kings));
            kings &= kings - 1U;
            int& mobility = color == Color::White ? result.white_king_mobility : result.black_king_mobility;
            mobility += king_mobility(position, square);
        }
    }
    result.evaluation = evaluate_breakdown(position, true);
    return result;
}

std::string_view diagnostic_phase_name(DiagnosticPhase phase) noexcept {
    switch (phase) {
        case DiagnosticPhase::Opening: return "opening";
        case DiagnosticPhase::Middlegame: return "middlegame";
        case DiagnosticPhase::ManEndgame: return "man_endgame";
        case DiagnosticPhase::KingEndgame: return "king_endgame";
    }
    return "unknown";
}

bool load_diagnostic_suite(
    std::istream& input,
    std::vector<DiagnosticCase>& cases,
    std::string* error) {
    cases.clear();
    std::string line;
    std::vector<std::string> header;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned.front() == '#') continue;
        if (header.empty()) {
            header = split(cleaned, '\t');
            continue;
        }
        const std::vector<std::string> fields = split(cleaned, '\t');
        if (fields.size() != header.size()) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": field count mismatch";
            return false;
        }
        std::unordered_map<std::string, std::string> values;
        for (std::size_t index = 0; index < header.size(); ++index) values.emplace(header[index], fields[index]);
        const std::array<std::string_view, 9> required{{
            "id", "category", "classification", "game_label", "shallow_move",
            "shallow_score", "deep_move", "deep_score", "apf",
        }};
        for (const std::string_view name : required) {
            if (!values.contains(std::string(name))) {
                if (error != nullptr) *error = "missing required column: " + std::string(name);
                return false;
            }
        }
        DiagnosticCase item{};
        item.id = values["id"];
        item.category = values["category"];
        item.recorded_classification = values["classification"];
        item.game_label = values["game_label"];
        item.baseline_shallow_move = values["shallow_move"];
        item.baseline_deep_move = values["deep_move"];
        const auto reference_move = values.find("reference_move");
        if (reference_move != values.end()) item.external_reference_move = reference_move->second;
        item.apf = values["apf"];
        if (!parse_score(values["shallow_score"], item.baseline_shallow_score) ||
            !parse_score(values["deep_score"], item.baseline_deep_score)) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": invalid Albay score";
            return false;
        }
        const auto external_score = values.find("reference_score");
        if (external_score != values.end() && !external_score->second.empty() &&
            !parse_score(external_score->second, item.external_reference_score)) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": invalid external score";
            return false;
        }
        std::string parse_error;
        if (!parse_apf(item.apf, &parse_error).has_value()) {
            if (error != nullptr) *error = "line " + std::to_string(line_number) + ": " + parse_error;
            return false;
        }
        cases.push_back(std::move(item));
    }
    if (header.empty() || cases.empty()) {
        if (error != nullptr) *error = "diagnostic suite contains no cases";
        return false;
    }
    return true;
}

bool load_diagnostic_suite_file(
    const std::string& path,
    std::vector<DiagnosticCase>& cases,
    std::string* error) {
    std::ifstream input(path);
    if (!input) {
        if (error != nullptr) *error = "cannot open diagnostic suite: " + path;
        return false;
    }
    return load_diagnostic_suite(input, cases, error);
}

DiagnosticCaseResult run_diagnostic_case(
    const DiagnosticCase& diagnostic_case,
    int shallow_depth,
    int deep_depth,
    const SearchOptions& options) {
    DiagnosticCaseResult result{};
    result.id = diagnostic_case.id;
    result.category = diagnostic_case.category;
    result.recorded_classification = diagnostic_case.recorded_classification;
    std::string parse_error;
    const auto position = parse_apf(diagnostic_case.apf, &parse_error);
    if (!position.has_value()) return result;
    result.features = extract_position_features(*position);
    SearchLimits shallow_limits{};
    shallow_limits.depth = std::clamp(shallow_depth, 1, kMaxSearchDepth);
    SearchLimits deep_limits{};
    deep_limits.depth = std::clamp(std::max(deep_depth, shallow_limits.depth), 1, kMaxSearchDepth);
    Searcher shallow_searcher;
    Searcher deep_searcher;
    const SearchResult shallow = shallow_searcher.search(*position, shallow_limits, options);
    const SearchResult deep = deep_searcher.search(*position, deep_limits, options);
    if (shallow.best_move.has_value()) result.shallow_move = move_to_string(*shallow.best_move);
    if (deep.best_move.has_value()) result.deep_move = move_to_string(*deep.best_move);
    result.shallow_score = shallow.score;
    result.deep_score = deep.score;
    result.shallow_nodes = shallow.nodes;
    result.deep_nodes = deep.nodes;
    result.shallow_matches_deep = !result.shallow_move.empty() && result.shallow_move == result.deep_move;
    result.deep_matches_baseline = !result.deep_move.empty() && result.deep_move == diagnostic_case.baseline_deep_move;
    result.deep_matches_external = !diagnostic_case.external_reference_move.empty() &&
        result.deep_move == diagnostic_case.external_reference_move;
    result.current_classification = classify_result(
        result.shallow_move, result.deep_move, diagnostic_case.external_reference_move);
    result.legal = deep.best_move.has_value() && is_legal_move(*position, *deep.best_move);
    return result;
}

DiagnosticSummary summarize_diagnostics(
    const std::vector<DiagnosticCaseResult>& results) noexcept {
    DiagnosticSummary summary{};
    summary.total = results.size();
    for (const DiagnosticCaseResult& result : results) {
        if (result.legal) ++summary.legal;
        if (result.shallow_matches_deep) ++summary.shallow_deep_agreement;
        if (result.deep_matches_baseline) ++summary.deep_baseline_agreement;
        if (result.deep_matches_external) ++summary.deep_external_agreement;
        if (result.current_classification == "horizon_error") ++summary.horizon_errors;
        else if (result.current_classification == "depth_unstable") ++summary.depth_unstable;
        else if (result.current_classification == "engine_disagreement") ++summary.external_disagreements;
    }
    return summary;
}

}  // namespace albay
