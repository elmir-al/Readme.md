/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/tuning.hpp"

#include "albay/notation.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <cmath>
#include <fstream>
#include <sstream>

namespace albay {
namespace {

[[nodiscard]] std::string trim(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
        return {};
    }
    const auto last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

[[nodiscard]] double sigmoid(double value) noexcept {
    if (value >= 0.0) {
        const double exp_value = std::exp(-value);
        return 1.0 / (1.0 + exp_value);
    }
    const double exp_value = std::exp(value);
    return exp_value / (1.0 + exp_value);
}

using WeightMember = int EvaluationWeights::*;
constexpr std::array<WeightMember, 25> kMembers{{
    &EvaluationWeights::material,
    &EvaluationWeights::center,
    &EvaluationWeights::advancement,
    &EvaluationWeights::promotion_potential,
    &EvaluationWeights::back_rank,
    &EvaluationWeights::mobility,
    &EvaluationWeights::king_activity,
    &EvaluationWeights::restriction,
    &EvaluationWeights::tactical_pressure,
    &EvaluationWeights::phase_adjustment,
    &EvaluationWeights::structure,
    &EvaluationWeights::support_structure,
    &EvaluationWeights::isolation,
    &EvaluationWeights::promotion_lanes,
    &EvaluationWeights::edge_passivity,
    &EvaluationWeights::phase_adjustment_repeat,
    &EvaluationWeights::opening_center_scale,
    &EvaluationWeights::opening_back_rank_scale,
    &EvaluationWeights::middlegame_structure_scale,
    &EvaluationWeights::endgame_king_scale,
    &EvaluationWeights::endgame_mobility_scale,
    &EvaluationWeights::endgame_restriction_scale,
    &EvaluationWeights::endgame_promotion_scale,
    &EvaluationWeights::king_confinement,
    &EvaluationWeights::promotion_race,
}};

}  // namespace

bool load_tuning_dataset(
    std::istream& input,
    std::vector<TuningSample>& samples,
    std::string* error) {
    samples.clear();
    std::string line;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned.front() == '#') {
            continue;
        }
        const std::size_t tab = cleaned.find('\t');
        if (tab == std::string::npos) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": expected result and APF";
            }
            return false;
        }
        const std::string label = trim(cleaned.substr(0, tab));
        double result = 0.5;
        if (label == "1" || label == "1.0" || label == "W") {
            result = 1.0;
        } else if (label == "0.5" || label == "D") {
            result = 0.5;
        } else if (label == "0" || label == "0.0" || label == "B") {
            result = 0.0;
        } else {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": result must be W/D/B or 1/0.5/0";
            }
            return false;
        }
        std::string parse_error;
        const auto position = parse_apf(trim(cleaned.substr(tab + 1)), &parse_error);
        if (!position.has_value()) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": " + parse_error;
            }
            return false;
        }
        samples.push_back(TuningSample{*position, result});
    }
    if (samples.empty()) {
        if (error != nullptr) {
            *error = "tuning dataset contains no samples";
        }
        return false;
    }
    return true;
}

bool load_tuning_dataset_file(
    const std::string& path,
    std::vector<TuningSample>& samples,
    std::string* error) {
    std::ifstream input(path);
    if (!input) {
        if (error != nullptr) {
            *error = "cannot open tuning dataset: " + path;
        }
        return false;
    }
    return load_tuning_dataset(input, samples, error);
}

bool load_weights(
    std::istream& input,
    EvaluationWeights& weights,
    std::string* error) {
    EvaluationWeights parsed = weights;
    std::string line;
    int line_number = 0;
    while (std::getline(input, line)) {
        ++line_number;
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned.front() == '#') {
            continue;
        }
        const std::size_t equals = cleaned.find('=');
        if (equals == std::string::npos) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": expected key=value";
            }
            return false;
        }
        const std::string key = trim(cleaned.substr(0, equals));
        const std::string value_text = trim(cleaned.substr(equals + 1));
        int value = 0;
        const auto [pointer, code] = std::from_chars(
            value_text.data(), value_text.data() + value_text.size(), value);
        if (code != std::errc{} || pointer != value_text.data() + value_text.size() ||
            value < 0 || value > 300) {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": weight must be 0..300";
            }
            return false;
        }

        int* target = nullptr;
        if (key == "EvalMaterial") target = &parsed.material;
        else if (key == "EvalCenter") target = &parsed.center;
        else if (key == "EvalAdvancement") target = &parsed.advancement;
        else if (key == "EvalPromotion") target = &parsed.promotion_potential;
        else if (key == "EvalBackRank") target = &parsed.back_rank;
        else if (key == "EvalMobility") target = &parsed.mobility;
        else if (key == "EvalKingActivity") target = &parsed.king_activity;
        else if (key == "EvalRestriction") target = &parsed.restriction;
        else if (key == "EvalTactical") target = &parsed.tactical_pressure;
        else if (key == "EvalPhase") target = &parsed.phase_adjustment;
        else if (key == "EvalStructure") target = &parsed.structure;
        else if (key == "EvalSupportStructure") target = &parsed.support_structure;
        else if (key == "EvalIsolation") target = &parsed.isolation;
        else if (key == "EvalPromotionLanes") target = &parsed.promotion_lanes;
        else if (key == "EvalEdgePassivity") target = &parsed.edge_passivity;
        else if (key == "EvalPhaseRepeat") target = &parsed.phase_adjustment_repeat;
        else if (key == "EvalOpeningCenterScale") target = &parsed.opening_center_scale;
        else if (key == "EvalOpeningBackRankScale") target = &parsed.opening_back_rank_scale;
        else if (key == "EvalMiddlegameStructureScale") target = &parsed.middlegame_structure_scale;
        else if (key == "EvalEndgameKingScale") target = &parsed.endgame_king_scale;
        else if (key == "EvalEndgameMobilityScale") target = &parsed.endgame_mobility_scale;
        else if (key == "EvalEndgameRestrictionScale") target = &parsed.endgame_restriction_scale;
        else if (key == "EvalEndgamePromotionScale") target = &parsed.endgame_promotion_scale;
        else if (key == "EvalKingConfinement") target = &parsed.king_confinement;
        else if (key == "EvalPromotionRace") target = &parsed.promotion_race;
        else if (key == "EvalWingBalance") target = &parsed.wing_balance;
        else if (key == "EvalRearSupport") target = &parsed.rear_support;
        else if (key == "EvalAdvancedExposure") target = &parsed.advanced_exposure;
        else if (key == "EvalDiagonalControl") target = &parsed.diagonal_control;
        else if (key == "EvalReserveTempo") target = &parsed.reserve_tempo;
        else if (key == "EvalSpacePressure") target = &parsed.space_pressure;
        else if (key == "EvalStrategicPST") target = &parsed.strategic_pst;
        else if (key == "EvalStrategicMinPieces") target = &parsed.strategic_min_pieces;
        else if (key == "EvalStrategicMaxPieces") target = &parsed.strategic_max_pieces;
        else if (key == "EvalStrategicMaxKings") target = &parsed.strategic_max_kings;
        else {
            if (error != nullptr) {
                *error = "line " + std::to_string(line_number) + ": unknown weight " + key;
            }
            return false;
        }
        *target = value;
    }
    weights = parsed;
    return true;
}

bool load_weights_file(
    const std::string& path,
    EvaluationWeights& weights,
    std::string* error) {
    std::ifstream input(path);
    if (!input) {
        if (error != nullptr) {
            *error = "cannot open weight file: " + path;
        }
        return false;
    }
    return load_weights(input, weights, error);
}

double tuning_loss(
    const std::vector<TuningSample>& samples,
    const EvaluationWeights& weights,
    double score_scale) {
    if (samples.empty() || score_scale <= 0.0) {
        return 0.0;
    }
    double total = 0.0;
    constexpr double epsilon = 1.0e-12;
    for (const TuningSample& sample : samples) {
        const double prediction = std::clamp(
            sigmoid(static_cast<double>(evaluate_white_perspective(sample.position, weights)) / score_scale),
            epsilon, 1.0 - epsilon);
        total -= sample.white_result * std::log(prediction) +
            (1.0 - sample.white_result) * std::log(1.0 - prediction);
    }
    return total / static_cast<double>(samples.size());
}

TuningReport coordinate_tune(
    const std::vector<TuningSample>& training_samples,
    EvaluationWeights initial,
    int passes,
    int initial_step,
    double score_scale) {
    TuningReport report{};
    report.weights = initial;
    report.initial_loss = tuning_loss(training_samples, report.weights, score_scale);
    double best_loss = report.initial_loss;
    int step = std::max(initial_step, 1);

    for (int pass = 0; pass < std::max(passes, 0); ++pass) {
        bool changed = false;
        for (const WeightMember member : kMembers) {
            EvaluationWeights local_best = report.weights;
            double local_loss = best_loss;
            for (const int direction : {-1, 1}) {
                EvaluationWeights candidate = report.weights;
                candidate.*member = std::clamp(candidate.*member + direction * step, 0, 300);
                const double candidate_loss = tuning_loss(training_samples, candidate, score_scale);
                if (candidate_loss + 1.0e-12 < local_loss) {
                    local_loss = candidate_loss;
                    local_best = candidate;
                }
            }
            if (local_loss + 1.0e-12 < best_loss) {
                report.weights = local_best;
                best_loss = local_loss;
                changed = true;
                ++report.accepted_changes;
            }
        }
        ++report.passes_completed;
        if (!changed) {
            step = std::max(step / 2, 1);
        }
    }
    report.final_loss = best_loss;
    return report;
}

void write_weights(std::ostream& output, const EvaluationWeights& weights) {
    output << "EvalMaterial=" << weights.material << '\n'
           << "EvalCenter=" << weights.center << '\n'
           << "EvalAdvancement=" << weights.advancement << '\n'
           << "EvalPromotion=" << weights.promotion_potential << '\n'
           << "EvalBackRank=" << weights.back_rank << '\n'
           << "EvalMobility=" << weights.mobility << '\n'
           << "EvalKingActivity=" << weights.king_activity << '\n'
           << "EvalRestriction=" << weights.restriction << '\n'
           << "EvalTactical=" << weights.tactical_pressure << '\n'
           << "EvalPhase=" << weights.phase_adjustment << '\n'
           << "EvalStructure=" << weights.structure << '\n'
           << "EvalSupportStructure=" << weights.support_structure << '\n'
           << "EvalIsolation=" << weights.isolation << '\n'
           << "EvalPromotionLanes=" << weights.promotion_lanes << '\n'
           << "EvalEdgePassivity=" << weights.edge_passivity << '\n'
           << "EvalPhaseRepeat=" << weights.phase_adjustment_repeat << '\n'
           << "EvalOpeningCenterScale=" << weights.opening_center_scale << '\n'
           << "EvalOpeningBackRankScale=" << weights.opening_back_rank_scale << '\n'
           << "EvalMiddlegameStructureScale=" << weights.middlegame_structure_scale << '\n'
           << "EvalEndgameKingScale=" << weights.endgame_king_scale << '\n'
           << "EvalEndgameMobilityScale=" << weights.endgame_mobility_scale << '\n'
           << "EvalEndgameRestrictionScale=" << weights.endgame_restriction_scale << '\n'
           << "EvalEndgamePromotionScale=" << weights.endgame_promotion_scale << '\n'
           << "EvalKingConfinement=" << weights.king_confinement << '\n'
           << "EvalPromotionRace=" << weights.promotion_race << '\n'
           << "EvalWingBalance=" << weights.wing_balance << '\n'
           << "EvalRearSupport=" << weights.rear_support << '\n'
           << "EvalAdvancedExposure=" << weights.advanced_exposure << '\n'
           << "EvalDiagonalControl=" << weights.diagonal_control << '\n'
           << "EvalReserveTempo=" << weights.reserve_tempo << '\n'
           << "EvalSpacePressure=" << weights.space_pressure << '\n'
           << "EvalStrategicPST=" << weights.strategic_pst << '\n'
           << "EvalStrategicMinPieces=" << weights.strategic_min_pieces << '\n'
           << "EvalStrategicMaxPieces=" << weights.strategic_max_pieces << '\n'
           << "EvalStrategicMaxKings=" << weights.strategic_max_kings << '\n';
}

}  // namespace albay
