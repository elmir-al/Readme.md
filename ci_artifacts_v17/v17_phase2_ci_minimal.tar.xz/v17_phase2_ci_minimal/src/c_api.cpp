/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/c_api.h"

#include "albay/engine.hpp"
#include "albay/notation.hpp"
#include "albay/runtime_policy.hpp"
#include "albay/types.hpp"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <exception>
#include <new>
#include <sstream>
#include <string>
#include <vector>

struct albay_engine {
    albay::Engine implementation;
};

static_assert(ALBAY_EVALUATION_SCALE == albay::kMateScore);
static_assert(ALBAY_MATE_THRESHOLD == albay::kMateThreshold);
static_assert(ALBAY_MATE_SCORE == albay::kMateScore);
static_assert(ALBAY_INFINITE_SCORE == albay::kInfiniteScore);

namespace {

[[nodiscard]] albay_status copy_text(
    const std::string& text,
    char* buffer,
    size_t capacity,
    size_t* required_size) noexcept {
    const size_t required = text.size() + 1U;
    if (required_size != nullptr) {
        *required_size = required;
    }
    if (buffer == nullptr || capacity < required) {
        if (buffer != nullptr && capacity > 0) {
            buffer[0] = '\0';
        }
        return ALBAY_STATUS_BUFFER_TOO_SMALL;
    }
    std::memcpy(buffer, text.c_str(), required);
    return ALBAY_STATUS_OK;
}

[[nodiscard]] std::string join_moves(const std::vector<std::string>& moves, char separator) {
    std::ostringstream output;
    for (std::size_t index = 0; index < moves.size(); ++index) {
        if (index != 0) {
            output << separator;
        }
        output << moves[index];
    }
    return output.str();
}

[[nodiscard]] std::string format_pv(const std::vector<albay::Move>& moves) {
    std::ostringstream output;
    for (std::size_t index = 0; index < moves.size(); ++index) {
        if (index != 0) {
            output << ' ';
        }
        output << albay::move_to_string(moves[index]);
    }
    return output.str();
}

[[nodiscard]] std::string format_multipv(const std::vector<albay::PrincipalVariationLine>& lines) {
    std::ostringstream output;
    for (std::size_t index = 0; index < lines.size(); ++index) {
        if (index != 0) {
            output << '\n';
        }
        output << lines[index].rank << '|'
               << lines[index].score << '|'
               << format_pv(lines[index].principal_variation);
    }
    return output.str();
}

}  // namespace

extern "C" {

albay_engine* albay_engine_create(void) {
    try {
        return new albay_engine{};
    } catch (...) {
        return nullptr;
    }
}

void albay_engine_destroy(albay_engine* engine) {
    delete engine;
}

albay_status albay_engine_new_game(albay_engine* engine) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        engine->implementation.new_game();
        return ALBAY_STATUS_OK;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_set_position(albay_engine* engine, const char* position) {
    if (engine == nullptr || position == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        return engine->implementation.set_position(position)
            ? ALBAY_STATUS_OK
            : ALBAY_STATUS_INVALID_POSITION;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_get_position(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        return copy_text(engine->implementation.get_position(), buffer, capacity, required_size);
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_generate_legal_moves(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        const std::string text = join_moves(engine->implementation.generate_legal_moves(), ';');
        return copy_text(text, buffer, capacity, required_size);
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

int32_t albay_engine_is_legal_move(const albay_engine* engine, const char* move) {
    if (engine == nullptr || move == nullptr) {
        return 0;
    }
    try {
        return engine->implementation.is_legal_move(move) ? 1 : 0;
    } catch (...) {
        return 0;
    }
}

albay_status albay_engine_make_move(albay_engine* engine, const char* move) {
    if (engine == nullptr || move == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        return engine->implementation.make_move(move)
            ? ALBAY_STATUS_OK
            : ALBAY_STATUS_ILLEGAL_MOVE;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_undo_move(albay_engine* engine) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        return engine->implementation.undo_move()
            ? ALBAY_STATUS_OK
            : ALBAY_STATUS_NOT_AVAILABLE;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_start_search(albay_engine* engine, const albay_search_limits* limits) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    if (limits != nullptr && limits->struct_size < sizeof(albay_search_limits)) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        albay::SearchLimits converted{};
        if (limits != nullptr) {
            converted.depth = limits->depth;
            converted.nodes = limits->nodes;
            converted.move_time = std::chrono::milliseconds(limits->move_time_ms);
            converted.infinite = limits->infinite != 0;
        }
        return engine->implementation.start_search(converted)
            ? ALBAY_STATUS_OK
            : ALBAY_STATUS_BUSY;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_stop_search(albay_engine* engine) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    engine->implementation.stop_search();
    return ALBAY_STATUS_OK;
}

albay_status albay_engine_pause_search(albay_engine* engine) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    engine->implementation.pause_search();
    return ALBAY_STATUS_OK;
}

albay_status albay_engine_resume_search(albay_engine* engine) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    engine->implementation.resume_search();
    return ALBAY_STATUS_OK;
}


albay_status albay_engine_set_runtime_environment(
    albay_engine* engine, const albay_runtime_environment* environment) {
    if (engine == nullptr || environment == nullptr ||
        environment->struct_size < sizeof(albay_runtime_environment)) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    if (environment->thermal_status < ALBAY_THERMAL_UNKNOWN ||
        environment->thermal_status > ALBAY_THERMAL_SHUTDOWN) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        albay::RuntimeEnvironment native{};
        native.logical_cpu_count = std::max(environment->logical_cpu_count, 1);
        native.thermal_status = static_cast<albay::ThermalStatus>(environment->thermal_status);
        native.power_save_mode = environment->power_save_mode != 0;
        native.app_in_background = environment->app_in_background != 0;
        engine->implementation.update_runtime_environment(native);
        return ALBAY_STATUS_OK;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_get_runtime_info(
    const albay_engine* engine, albay_runtime_info* info) {
    if (engine == nullptr || info == nullptr || info->struct_size < sizeof(albay_runtime_info)) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        const albay::ThreadPolicyDecision source = engine->implementation.runtime_policy_info();
        const uint32_t caller_size = info->struct_size;
        albay_runtime_info output{};
        output.struct_size = caller_size;
        output.profile = static_cast<int32_t>(source.profile);
        output.automatic_threads = source.automatic ? 1 : 0;
        output.hardware_threads = source.hardware_threads;
        output.pool_threads = source.pool_threads;
        output.target_threads = source.target_threads;
        output.thermal_status = static_cast<int32_t>(source.thermal_status);
        output.constrained_by_thermal = source.constrained_by_thermal ? 1 : 0;
        output.constrained_by_power_saver = source.constrained_by_power_saver ? 1 : 0;
        output.constrained_by_background = source.constrained_by_background ? 1 : 0;
        std::memcpy(info, &output, std::min<std::size_t>(caller_size, sizeof(output)));
        return ALBAY_STATUS_OK;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_set_option(albay_engine* engine, const char* name, const char* value) {
    if (engine == nullptr || name == nullptr || value == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        if (engine->implementation.set_option(name, value)) {
            return ALBAY_STATUS_OK;
        }
        return engine->implementation.is_searching() ? ALBAY_STATUS_BUSY : ALBAY_STATUS_INVALID_ARGUMENT;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_get_search_info(const albay_engine* engine, albay_search_info* info) {
    if (engine == nullptr || info == nullptr || info->struct_size < ALBAY_SEARCH_INFO_V1_SIZE) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        const albay::SearchInfo source = engine->implementation.search_info();
        const uint32_t caller_size = info->struct_size;
        albay_search_info output{};
        output.struct_size = caller_size;
        output.depth = source.depth;
        output.selective_depth = source.selective_depth;
        output.score = source.score;
        output.nodes = source.nodes;
        output.nodes_per_second = source.nodes_per_second;
        output.elapsed_ms = static_cast<uint64_t>(std::max<int64_t>(0, source.elapsed.count()));
        output.tt_probes = source.transposition_table.probes;
        output.tt_hits = source.transposition_table.hits;
        output.tt_cutoffs = source.transposition_table.cutoffs;
        output.tt_stores = source.transposition_table.stores;
        output.tt_hashfull_per_mille = source.transposition_table.hashfull_per_mille;
        output.searching = engine->implementation.is_searching() ? 1 : 0;
        output.paused = source.paused ? 1 : 0;
        output.threads = source.threads;
        output.active_threads = source.active_threads;
        output.target_threads = source.target_threads;
        output.parked_threads = source.parked_threads;
        std::memcpy(info, &output, std::min<std::size_t>(caller_size, sizeof(output)));
        return ALBAY_STATUS_OK;
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_get_best_move(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        const auto move = engine->implementation.best_move();
        if (!move.has_value()) {
            if (required_size != nullptr) {
                *required_size = 0;
            }
            if (buffer != nullptr && capacity > 0) {
                buffer[0] = '\0';
            }
            return ALBAY_STATUS_NOT_AVAILABLE;
        }
        return copy_text(albay::move_to_string(*move), buffer, capacity, required_size);
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_get_principal_variation(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        const std::vector<albay::Move> pv = engine->implementation.principal_variation();
        if (pv.empty()) {
            return ALBAY_STATUS_NOT_AVAILABLE;
        }
        return copy_text(format_pv(pv), buffer, capacity, required_size);
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

albay_status albay_engine_get_multipv(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        const std::vector<albay::PrincipalVariationLine> lines = engine->implementation.multipv();
        if (lines.empty()) {
            return ALBAY_STATUS_NOT_AVAILABLE;
        }
        return copy_text(format_multipv(lines), buffer, capacity, required_size);
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

int32_t albay_engine_get_evaluation_scale(void) {
    return ALBAY_EVALUATION_SCALE;
}

int32_t albay_engine_evaluate_position(const albay_engine* engine) {
    if (engine == nullptr) {
        return 0;
    }
    try {
        return engine->implementation.evaluate_position();
    } catch (...) {
        return 0;
    }
}

int32_t albay_engine_is_searching(const albay_engine* engine) {
    return engine != nullptr && engine->implementation.is_searching() ? 1 : 0;
}

const char* albay_engine_get_name(void) {
    return "Albay Russian Draughts Engine";
}

const char* albay_engine_get_author(void) {
    return "Elmir Hajizada";
}

const char* albay_engine_get_version(void) {
    return albay::kEngineVersion.data();
}

albay_status albay_engine_get_last_error(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size) {
    if (engine == nullptr) {
        return ALBAY_STATUS_INVALID_ARGUMENT;
    }
    try {
        return copy_text(engine->implementation.last_error(), buffer, capacity, required_size);
    } catch (...) {
        return ALBAY_STATUS_INTERNAL_ERROR;
    }
}

}  // extern "C"
