/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 38 — incremental NNUE runtime with safe HCE fallback.
*/
#include "albay/nnue_runtime.hpp"

#include <algorithm>
#include <cstdint>
#include <exception>

namespace albay {
namespace {

[[nodiscard]] bool fail(std::string* error, std::string message) {
    if (error != nullptr) *error = std::move(message);
    return false;
}

}  // namespace

bool load_nnue_runtime_model(
    const std::string& path,
    std::shared_ptr<const NnueModel>& output,
    std::string* error) {
    if (path.empty()) return fail(error, "NNUE model path is empty");
    try {
        auto candidate = std::make_shared<NnueModel>();
        std::string model_error;
        if (!candidate->load(path, &model_error)) {
            return fail(error, "NNUE model load failed: " + model_error);
        }
        if (!candidate->validate(&model_error)) {
            return fail(error, "NNUE model validation failed: " + model_error);
        }
        output = std::move(candidate);
        return true;
    } catch (const std::exception& exception) {
        return fail(error, std::string("NNUE model load exception: ") + exception.what());
    } catch (...) {
        return fail(error, "NNUE model load failed with an unknown exception");
    }
}

NnueRuntimeEvaluation evaluate_with_nnue_fallback(
    const Position& position,
    Score hce_score,
    const NnueRuntimeOptions& options,
    const NnueAccumulator* accumulator) noexcept {
    NnueRuntimeEvaluation result{};
    result.hce_score = hce_score;
    result.score = hce_score;
    if (!options.enabled) return result;
    if (!options.model) {
        result.used_fallback = true;
        return result;
    }

    // NnueAccumulator::evaluate() already performs the validity check and
    // refreshes safely when needed.  Calling valid_for() here first duplicated
    // two complete feature-mask reconstructions at every evaluated node.
    result.nnue_score = accumulator != nullptr
        ? accumulator->evaluate_assuming_valid(position, *options.model)
        : evaluate_nnue(position, *options.model);
    const int blend = std::clamp(options.blend_percent, 0, 100);
    const std::int64_t mixed =
        static_cast<std::int64_t>(result.nnue_score) * blend +
        static_cast<std::int64_t>(hce_score) * (100 - blend);
    result.score = static_cast<Score>(std::clamp<std::int64_t>(
        mixed / 100, -static_cast<std::int64_t>(kMateThreshold - 1),
        static_cast<std::int64_t>(kMateThreshold - 1)));
    result.used_nnue = blend > 0;
    return result;
}

}  // namespace albay
