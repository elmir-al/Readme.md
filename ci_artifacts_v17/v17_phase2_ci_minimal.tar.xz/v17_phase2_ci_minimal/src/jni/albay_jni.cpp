/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/c_api.h"

#include <jni.h>

#include <cstdint>
#include <thread>
#include <sstream>
#include <string>
#include <vector>

#if defined(__unix__) || defined(__ANDROID__)
#include <unistd.h>
#endif

namespace {

[[nodiscard]] albay_engine* from_handle(jlong handle) noexcept {
    return reinterpret_cast<albay_engine*>(static_cast<std::uintptr_t>(handle));
}

[[nodiscard]] jlong to_handle(albay_engine* engine) noexcept {
    return static_cast<jlong>(reinterpret_cast<std::uintptr_t>(engine));
}

class UtfChars {
public:
    UtfChars(JNIEnv* environment, jstring value)
        : environment_(environment), value_(value) {
        if (value_ != nullptr) {
            characters_ = environment_->GetStringUTFChars(value_, nullptr);
        }
    }

    ~UtfChars() {
        if (characters_ != nullptr) {
            environment_->ReleaseStringUTFChars(value_, characters_);
        }
    }

    UtfChars(const UtfChars&) = delete;
    UtfChars& operator=(const UtfChars&) = delete;

    [[nodiscard]] const char* get() const noexcept { return characters_; }

private:
    JNIEnv* environment_ = nullptr;
    jstring value_ = nullptr;
    const char* characters_ = nullptr;
};

[[nodiscard]] const char* build_platform() noexcept {
#if defined(__ANDROID__)
    return "android";
#elif defined(_WIN32)
    return "windows";
#elif defined(__linux__)
    return "linux";
#elif defined(__APPLE__)
    return "apple";
#else
    return "unknown";
#endif
}

[[nodiscard]] const char* build_architecture() noexcept {
#if defined(__aarch64__) || defined(_M_ARM64)
    return "arm64-v8a";
#elif defined(__x86_64__) || defined(_M_X64)
    return "x86-64";
#elif defined(__arm__) || defined(_M_ARM)
    return "armeabi-v7a";
#elif defined(__i386__) || defined(_M_IX86)
    return "x86";
#else
    return "unknown";
#endif
}

[[nodiscard]] long runtime_page_size() noexcept {
#if defined(__unix__) || defined(__ANDROID__)
    const long value = ::sysconf(_SC_PAGESIZE);
    return value > 0 ? value : 0;
#else
    return 0;
#endif
}

[[nodiscard]] int android_api_level() noexcept {
#if defined(__ANDROID_API__)
    return __ANDROID_API__;
#else
    return 0;
#endif
}

using TextGetter = albay_status (*)(const albay_engine*, char*, size_t, size_t*);

[[nodiscard]] jstring get_text(JNIEnv* environment, albay_engine* engine, TextGetter getter) {
    size_t required = 0;
    const albay_status query_status = getter(engine, nullptr, 0, &required);
    if (query_status == ALBAY_STATUS_NOT_AVAILABLE) {
        return nullptr;
    }
    if (query_status != ALBAY_STATUS_BUFFER_TOO_SMALL || required == 0) {
        return nullptr;
    }
    std::vector<char> buffer(required);
    if (getter(engine, buffer.data(), buffer.size(), &required) != ALBAY_STATUS_OK) {
        return nullptr;
    }
    return environment->NewStringUTF(buffer.data());
}

}  // namespace

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*, void*) {
    return JNI_VERSION_1_6;
}

JNIEXPORT jlong JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeCreate(JNIEnv*, jclass) {
    return to_handle(albay_engine_create());
}

JNIEXPORT void JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeDestroy(JNIEnv*, jclass, jlong handle) {
    albay_engine_destroy(from_handle(handle));
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeNewGame(JNIEnv*, jclass, jlong handle) {
    return albay_engine_new_game(from_handle(handle));
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeSetPosition(
    JNIEnv* environment, jclass, jlong handle, jstring position) {
    UtfChars text(environment, position);
    return albay_engine_set_position(from_handle(handle), text.get());
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetPosition(JNIEnv* environment, jclass, jlong handle) {
    return get_text(environment, from_handle(handle), albay_engine_get_position);
}

JNIEXPORT jobjectArray JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGenerateLegalMoves(
    JNIEnv* environment, jclass, jlong handle) {
    albay_engine* engine = from_handle(handle);
    size_t required = 0;
    if (albay_engine_generate_legal_moves(engine, nullptr, 0, &required) != ALBAY_STATUS_BUFFER_TOO_SMALL) {
        return nullptr;
    }
    std::vector<char> buffer(required);
    if (albay_engine_generate_legal_moves(engine, buffer.data(), buffer.size(), &required) != ALBAY_STATUS_OK) {
        return nullptr;
    }

    std::vector<std::string> moves;
    std::string text(buffer.data());
    std::size_t start = 0;
    while (start <= text.size() && !text.empty()) {
        const std::size_t separator = text.find(';', start);
        moves.push_back(text.substr(start, separator == std::string::npos ? std::string::npos : separator - start));
        if (separator == std::string::npos) {
            break;
        }
        start = separator + 1;
    }

    jclass string_class = environment->FindClass("java/lang/String");
    if (string_class == nullptr) {
        return nullptr;
    }
    jobjectArray result = environment->NewObjectArray(
        static_cast<jsize>(moves.size()), string_class, nullptr);
    for (std::size_t index = 0; index < moves.size(); ++index) {
        jstring move = environment->NewStringUTF(moves[index].c_str());
        environment->SetObjectArrayElement(result, static_cast<jsize>(index), move);
        environment->DeleteLocalRef(move);
    }
    environment->DeleteLocalRef(string_class);
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeIsLegalMove(
    JNIEnv* environment, jclass, jlong handle, jstring move) {
    UtfChars text(environment, move);
    return albay_engine_is_legal_move(from_handle(handle), text.get()) != 0 ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeMakeMove(
    JNIEnv* environment, jclass, jlong handle, jstring move) {
    UtfChars text(environment, move);
    return albay_engine_make_move(from_handle(handle), text.get());
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeUndoMove(JNIEnv*, jclass, jlong handle) {
    return albay_engine_undo_move(from_handle(handle));
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeStartSearch(
    JNIEnv*, jclass, jlong handle, jint depth, jlong nodes, jlong move_time_ms, jboolean infinite) {
    albay_search_limits limits{};
    limits.struct_size = sizeof(limits);
    limits.depth = depth;
    limits.nodes = nodes < 0 ? 0 : static_cast<uint64_t>(nodes);
    limits.move_time_ms = move_time_ms < 0 ? 0 : static_cast<uint64_t>(move_time_ms);
    limits.infinite = infinite == JNI_TRUE ? 1 : 0;
    return albay_engine_start_search(from_handle(handle), &limits);
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeStopSearch(JNIEnv*, jclass, jlong handle) {
    return albay_engine_stop_search(from_handle(handle));
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativePauseSearch(JNIEnv*, jclass, jlong handle) {
    return albay_engine_pause_search(from_handle(handle));
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeResumeSearch(JNIEnv*, jclass, jlong handle) {
    return albay_engine_resume_search(from_handle(handle));
}


JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeUpdateRuntimeEnvironment(
    JNIEnv*, jclass, jlong handle, jint logical_cpu_count, jint thermal_status,
    jboolean power_save_mode, jboolean app_in_background) {
    albay_runtime_environment environment{};
    environment.struct_size = sizeof(environment);
    environment.logical_cpu_count = logical_cpu_count;
    environment.thermal_status = thermal_status;
    environment.power_save_mode = power_save_mode == JNI_TRUE ? 1 : 0;
    environment.app_in_background = app_in_background == JNI_TRUE ? 1 : 0;
    return albay_engine_set_runtime_environment(from_handle(handle), &environment);
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetRuntimeInfo(
    JNIEnv* environment, jclass, jlong handle) {
    albay_runtime_info info{};
    info.struct_size = sizeof(info);
    if (albay_engine_get_runtime_info(from_handle(handle), &info) != ALBAY_STATUS_OK) {
        return nullptr;
    }
    std::ostringstream json;
    json << '{'
         << "\"profile\":" << info.profile << ','
         << "\"automaticThreads\":" << (info.automatic_threads != 0 ? "true" : "false") << ','
         << "\"hardwareThreads\":" << info.hardware_threads << ','
         << "\"poolThreads\":" << info.pool_threads << ','
         << "\"targetThreads\":" << info.target_threads << ','
         << "\"thermalStatus\":" << info.thermal_status << ','
         << "\"thermalConstrained\":" << (info.constrained_by_thermal != 0 ? "true" : "false") << ','
         << "\"powerSaverConstrained\":" << (info.constrained_by_power_saver != 0 ? "true" : "false") << ','
         << "\"backgroundConstrained\":" << (info.constrained_by_background != 0 ? "true" : "false")
         << '}';
    return environment->NewStringUTF(json.str().c_str());
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeSetOption(
    JNIEnv* environment, jclass, jlong handle, jstring name, jstring value) {
    UtfChars option_name(environment, name);
    UtfChars option_value(environment, value);
    return albay_engine_set_option(from_handle(handle), option_name.get(), option_value.get());
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetSearchInfo(
    JNIEnv* environment, jclass, jlong handle) {
    albay_search_info info{};
    info.struct_size = sizeof(info);
    if (albay_engine_get_search_info(from_handle(handle), &info) != ALBAY_STATUS_OK) {
        return nullptr;
    }
    std::ostringstream json;
    json << '{'
         << "\"depth\":" << info.depth << ','
         << "\"selectiveDepth\":" << info.selective_depth << ','
         << "\"score\":" << info.score << ','
         << "\"nodes\":" << info.nodes << ','
         << "\"nps\":" << info.nodes_per_second << ','
         << "\"elapsedMs\":" << info.elapsed_ms << ','
         << "\"ttProbes\":" << info.tt_probes << ','
         << "\"ttHits\":" << info.tt_hits << ','
         << "\"ttCutoffs\":" << info.tt_cutoffs << ','
         << "\"ttStores\":" << info.tt_stores << ','
         << "\"hashfullPermille\":" << info.tt_hashfull_per_mille << ','
         << "\"threads\":" << info.threads << ','
         << "\"activeThreads\":" << info.active_threads << ','
         << "\"targetThreads\":" << info.target_threads << ','
         << "\"parkedThreads\":" << info.parked_threads << ','
         << "\"searching\":" << (info.searching != 0 ? "true" : "false") << ','
         << "\"paused\":" << (info.paused != 0 ? "true" : "false")
         << '}';
    return environment->NewStringUTF(json.str().c_str());
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetBestMove(JNIEnv* environment, jclass, jlong handle) {
    return get_text(environment, from_handle(handle), albay_engine_get_best_move);
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetPrincipalVariation(
    JNIEnv* environment, jclass, jlong handle) {
    return get_text(environment, from_handle(handle), albay_engine_get_principal_variation);
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetMultiPv(JNIEnv* environment, jclass, jlong handle) {
    return get_text(environment, from_handle(handle), albay_engine_get_multipv);
}

JNIEXPORT jint JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeEvaluatePosition(JNIEnv*, jclass, jlong handle) {
    return albay_engine_evaluate_position(from_handle(handle));
}

JNIEXPORT jboolean JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeIsSearching(JNIEnv*, jclass, jlong handle) {
    return albay_engine_is_searching(from_handle(handle)) != 0 ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetName(JNIEnv* environment, jclass) {
    return environment->NewStringUTF(albay_engine_get_name());
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetAuthor(JNIEnv* environment, jclass) {
    return environment->NewStringUTF(albay_engine_get_author());
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetVersion(JNIEnv* environment, jclass) {
    return environment->NewStringUTF(albay_engine_get_version());
}

JNIEXPORT jstring JNICALL
Java_com_elmirhajizada_albay_AlbayNative_nativeGetBuildInfo(JNIEnv* environment, jclass) {
    std::ostringstream json;
    json << '{'
         << "\"platform\":\"" << build_platform() << "\","
         << "\"arch\":\"" << build_architecture() << "\","
         << "\"androidApi\":" << android_api_level() << ','
         << "\"pageSize\":" << runtime_page_size() << ','
         << "\"hardwareThreads\":" << std::thread::hardware_concurrency() << ','
         << "\"cppStandard\":" << __cplusplus
         << '}';
    return environment->NewStringUTF(json.str().c_str());
}

}  // extern "C"
