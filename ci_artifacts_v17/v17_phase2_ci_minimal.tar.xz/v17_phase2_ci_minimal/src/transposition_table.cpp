/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/transposition_table.hpp"

#include <algorithm>
#include <bit>
#include <limits>
#include <thread>

namespace albay {
namespace {

[[nodiscard]] std::size_t floor_power_of_two(std::size_t value) noexcept {
    if (value == 0) {
        return 1;
    }
    const auto exponent = static_cast<unsigned int>(std::bit_width(value) - 1);
    return std::size_t{1} << exponent;
}

[[nodiscard]] int generation_age(
    std::uint8_t current,
    std::uint8_t stored) noexcept {
    return static_cast<int>(static_cast<std::uint8_t>(current - stored));
}

[[nodiscard]] int replacement_value(
    const TTEntry& entry,
    std::uint8_t generation,
    const TTReplacementPolicy& policy) noexcept {
    if (entry.bound == TTBound::None) {
        return std::numeric_limits<int>::min();
    }
    int value = static_cast<int>(entry.depth);
    if (policy.use_age_aware_replacement) {
        const int age = generation_age(generation, entry.generation);
        value -= std::min(192, age * policy.age_penalty_per_generation);
    } else if (entry.generation != generation) {
        value -= 64;
    }
    if (entry.bound == TTBound::Exact) {
        value += policy.use_age_aware_replacement ? policy.exact_bound_bonus : 4;
    }
    return value;
}

}  // namespace

void TranspositionTable::SpinLock::lock() noexcept {
    unsigned int attempts = 0;
    while (flag_.test_and_set(std::memory_order_acquire)) {
        ++attempts;
        if ((attempts & 31U) == 0U) {
            std::this_thread::yield();
        }
    }
}

void TranspositionTable::SpinLock::unlock() noexcept {
    flag_.clear(std::memory_order_release);
}

TranspositionTable::TranspositionTable(std::size_t size_mb) {
    resize(size_mb);
}

void TranspositionTable::resize(std::size_t size_mb) {
    const std::size_t clamped_mb = std::clamp<std::size_t>(size_mb, 1, 2048);
    const std::size_t bytes = clamped_mb * 1024U * 1024U;
    const std::size_t requested_clusters = std::max<std::size_t>(1, bytes / sizeof(Cluster));
    const std::size_t cluster_count = policy_.use_full_capacity_indexing
        ? requested_clusters
        : floor_power_of_two(requested_clusters);
    clusters_.assign(cluster_count, Cluster{});
    mask_ = cluster_count - 1U;
    size_mb_ = clamped_mb;
    lock_count_ = std::min(cluster_count, kMaximumLockStripes);
    locks_ = std::make_unique<SpinLock[]>(lock_count_);
    generation_.store(1, std::memory_order_relaxed);
}

void TranspositionTable::clear() noexcept {
    std::fill(clusters_.begin(), clusters_.end(), Cluster{});
    generation_.store(1, std::memory_order_relaxed);
}

void TranspositionTable::configure(
    std::size_t size_mb,
    const TTReplacementPolicy& policy) {
    TTReplacementPolicy normalized = policy;
    normalized.age_penalty_per_generation =
        std::clamp(normalized.age_penalty_per_generation, 1, 64);
    normalized.exact_bound_bonus = std::clamp(normalized.exact_bound_bonus, 0, 32);
    const bool layout_changed =
        normalized.use_full_capacity_indexing != policy_.use_full_capacity_indexing;
    policy_ = normalized;
    if (layout_changed || size_mb_ != std::clamp<std::size_t>(size_mb, 1, 2048)) {
        resize(size_mb);
    }
}

void TranspositionTable::new_search() noexcept {
    const std::uint8_t previous = generation_.fetch_add(1, std::memory_order_relaxed);
    if (previous == std::numeric_limits<std::uint8_t>::max()) {
        clear();
    }
}

std::size_t TranspositionTable::cluster_index(HashKey key) const noexcept {
    if (!policy_.use_full_capacity_indexing) {
        return static_cast<std::size_t>(key) & mask_;
    }
#if defined(__SIZEOF_INT128__)
    __extension__ using WideUnsigned = unsigned __int128;
    const auto product = static_cast<WideUnsigned>(key) *
        static_cast<WideUnsigned>(clusters_.size());
    return static_cast<std::size_t>(product >> 64U);
#else
    return static_cast<std::size_t>(key % clusters_.size());
#endif
}

TranspositionTable::SpinLock& TranspositionTable::lock_for_cluster(
    std::size_t cluster_index_value) const noexcept {
    return locks_[cluster_index_value % lock_count_];
}

bool TranspositionTable::probe(HashKey key, TTEntry& entry) const noexcept {
    return probe_impl(key, entry, true);
}

bool TranspositionTable::probe_single_thread(HashKey key, TTEntry& entry) const noexcept {
    if (clusters_.empty()) {
        return false;
    }
    const std::size_t index = cluster_index(key);
    const auto& entries = clusters_[index].entries;
    if (entries[0].bound != TTBound::None && entries[0].key == key) {
        entry = entries[0];
        return true;
    }
    if (entries[1].bound != TTBound::None && entries[1].key == key) {
        entry = entries[1];
        return true;
    }
    if (entries[2].bound != TTBound::None && entries[2].key == key) {
        entry = entries[2];
        return true;
    }
    if (entries[3].bound != TTBound::None && entries[3].key == key) {
        entry = entries[3];
        return true;
    }
    return false;
}

bool TranspositionTable::probe_impl(HashKey key, TTEntry& entry, bool take_lock) const noexcept {
    if (clusters_.empty()) {
        return false;
    }
    const std::size_t index = cluster_index(key);
    const auto find_entry = [&]() noexcept {
        const Cluster& cluster = clusters_[index];
        for (const TTEntry& candidate : cluster.entries) {
            if (candidate.bound != TTBound::None && candidate.key == key) {
                entry = candidate;
                return true;
            }
        }
        return false;
    };
    if (!take_lock) {
        return find_entry();
    }
    ScopedLock lock(lock_for_cluster(index));
    return find_entry();
}

void TranspositionTable::store(
    HashKey key,
    int depth,
    Score score,
    TTBound bound,
    const Move* best_move) noexcept {
    store_impl(key, depth, score, bound, best_move, true);
}

void TranspositionTable::store_single_thread(
    HashKey key,
    int depth,
    Score score,
    TTBound bound,
    const Move* best_move) noexcept {
    store_impl(key, depth, score, bound, best_move, false);
}

void TranspositionTable::store_impl(
    HashKey key,
    int depth,
    Score score,
    TTBound bound,
    const Move* best_move,
    bool take_lock) noexcept {
    if (clusters_.empty() || bound == TTBound::None) {
        return;
    }

    const std::size_t index = cluster_index(key);
    const auto write_entry = [&]() noexcept {
        Cluster& cluster = clusters_[index];
        TTEntry* target = nullptr;
        const std::uint8_t current_generation = generation_.load(std::memory_order_relaxed);

        for (TTEntry& candidate : cluster.entries) {
            if (candidate.bound != TTBound::None && candidate.key == key) {
                target = &candidate;
                break;
            }
            if (candidate.bound == TTBound::None) {
                target = &candidate;
                break;
            }
        }

        if (target == nullptr) {
            target = &*std::min_element(
                cluster.entries.begin(),
                cluster.entries.end(),
                [&](const TTEntry& first, const TTEntry& second) {
                    return replacement_value(first, current_generation, policy_) <
                        replacement_value(second, current_generation, policy_);
                });
        }

        if (target->key == key && target->bound != TTBound::None) {
            const bool legacy_preserve = target->depth > depth &&
                bound != TTBound::Exact && target->generation == current_generation;
            const bool depth_preferred_preserve = policy_.use_depth_preferred_updates &&
                ((target->depth > depth) ||
                 (target->depth == depth && target->bound == TTBound::Exact &&
                  bound != TTBound::Exact));
            if (legacy_preserve || depth_preferred_preserve) {
                if (best_move != nullptr) {
                    target->best_move = MoveIdentity::from_move(*best_move);
                }
                if (depth_preferred_preserve) {
                    target->generation = current_generation;
                }
                return;
            }
        }

        target->key = key;
        target->score = score;
        target->depth = static_cast<std::int16_t>(std::clamp(depth, -1, 32767));
        target->bound = bound;
        target->generation = current_generation;
        target->best_move = best_move != nullptr
            ? MoveIdentity::from_move(*best_move)
            : MoveIdentity{};
    };

    if (!take_lock) {
        write_entry();
        return;
    }
    ScopedLock lock(lock_for_cluster(index));
    write_entry();
}

std::size_t TranspositionTable::entry_count() const noexcept {
    return clusters_.size() * kClusterSize;
}

std::size_t TranspositionTable::allocated_bytes() const noexcept {
    return clusters_.size() * sizeof(Cluster);
}

std::uint16_t TranspositionTable::hashfull_per_mille() const noexcept {
    if (clusters_.empty()) {
        return 0;
    }
    const std::size_t sample_clusters = std::min<std::size_t>(clusters_.size(), 250);
    std::size_t occupied = 0;
    const std::uint8_t current_generation = generation_.load(std::memory_order_relaxed);
    for (std::size_t index = 0; index < sample_clusters; ++index) {
        ScopedLock lock(lock_for_cluster(index));
        for (const TTEntry& entry : clusters_[index].entries) {
            if (entry.bound != TTBound::None && entry.generation == current_generation) {
                ++occupied;
            }
        }
    }
    const std::size_t sampled_entries = sample_clusters * kClusterSize;
    return static_cast<std::uint16_t>(occupied * 1000U / sampled_entries);
}

}  // namespace albay
