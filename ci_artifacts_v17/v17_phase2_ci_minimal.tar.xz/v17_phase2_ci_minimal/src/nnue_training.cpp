/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 35 — NNUE dataset and training infrastructure.
*/
#include "albay/nnue_training.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <limits>
#include <numeric>
#include <random>
#include <sstream>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>

namespace albay {
namespace {

constexpr std::array<std::uint8_t, 8> kDatasetMagic{{'A','L','N','D','S','3','5','\0'}};
constexpr std::uint64_t kFnvOffset = 1469598103934665603ULL;
constexpr std::uint64_t kFnvPrime = 1099511628211ULL;

[[nodiscard]] bool fail(std::string* error, std::string message) {
    if (error != nullptr) *error = std::move(message);
    return false;
}

void fnv_update(std::uint64_t& hash, const std::uint8_t* data, std::size_t size) noexcept {
    for (std::size_t index = 0; index < size; ++index) {
        hash ^= data[index];
        hash *= kFnvPrime;
    }
}

template <typename T>
void write_le(std::uint8_t* out, std::size_t offset, T value) noexcept {
    using U = std::make_unsigned_t<T>;
    const U raw = static_cast<U>(value);
    for (std::size_t index = 0; index < sizeof(T); ++index) {
        out[offset + index] = static_cast<std::uint8_t>((raw >> (index * 8U)) & 0xFFU);
    }
}

template <typename T>
[[nodiscard]] T read_le(const std::uint8_t* in, std::size_t offset) noexcept {
    using U = std::make_unsigned_t<T>;
    U raw = 0;
    for (std::size_t index = 0; index < sizeof(T); ++index) {
        const U byte = static_cast<U>(in[offset + index]);
        const unsigned shift = static_cast<unsigned>(index * 8U);
        raw = static_cast<U>(raw | static_cast<U>(byte << shift));
    }
    return static_cast<T>(raw);
}

[[nodiscard]] std::size_t phase_index(HcePhase phase) noexcept {
    return static_cast<std::size_t>(phase);
}
[[nodiscard]] std::size_t split_index(HceSplit split) noexcept {
    return static_cast<std::size_t>(split);
}
[[nodiscard]] std::size_t source_index(HceSource source) noexcept {
    return static_cast<std::size_t>(source);
}

void encode_record(const NnueDatasetRecord& record,
                   std::array<std::uint8_t, kNnueDatasetRecordBytes>& bytes) noexcept {
    bytes.fill(0);
    write_le(bytes.data(), 0, record.white);
    write_le(bytes.data(), 8, record.black);
    write_le(bytes.data(), 16, record.kings);
    write_le(bytes.data(), 24, record.group_id);
    write_le(bytes.data(), 32, record.target_score_stm);
    write_le(bytes.data(), 34, record.ply);
    write_le(bytes.data(), 36, record.no_progress_plies);
    write_le(bytes.data(), 38, record.flags);
    bytes[40] = static_cast<std::uint8_t>(record.side_to_move == Color::White ? 0 : 1);
    bytes[41] = static_cast<std::uint8_t>(record.phase);
    bytes[42] = static_cast<std::uint8_t>(record.split);
    bytes[43] = static_cast<std::uint8_t>(record.source);
    bytes[44] = static_cast<std::uint8_t>(record.game_result_stm);
    bytes[45] = record.teacher_depth;
    write_le(bytes.data(), 46, record.reserved);
}

[[nodiscard]] NnueDatasetRecord decode_record(const std::uint8_t* bytes) noexcept {
    NnueDatasetRecord record{};
    record.white = read_le<Bitboard>(bytes, 0);
    record.black = read_le<Bitboard>(bytes, 8);
    record.kings = read_le<Bitboard>(bytes, 16);
    record.group_id = read_le<std::uint64_t>(bytes, 24);
    record.target_score_stm = read_le<std::int16_t>(bytes, 32);
    record.ply = read_le<std::uint16_t>(bytes, 34);
    record.no_progress_plies = read_le<std::uint16_t>(bytes, 36);
    record.flags = read_le<std::uint16_t>(bytes, 38);
    record.side_to_move = bytes[40] == 0 ? Color::White : Color::Black;
    record.phase = static_cast<HcePhase>(bytes[41]);
    record.split = static_cast<HceSplit>(bytes[42]);
    record.source = static_cast<HceSource>(bytes[43]);
    record.game_result_stm = static_cast<std::int8_t>(bytes[44]);
    record.teacher_depth = bytes[45];
    record.reserved = read_le<std::uint16_t>(bytes, 46);
    return record;
}

void encode_header(const NnueDatasetHeader& header,
                   std::array<std::uint8_t, kNnueDatasetHeaderBytes>& bytes) noexcept {
    bytes.fill(0);
    std::copy(kDatasetMagic.begin(), kDatasetMagic.end(), bytes.begin());
    write_le(bytes.data(), 8, header.format_version);
    write_le(bytes.data(), 12, header.header_bytes);
    write_le(bytes.data(), 16, header.record_bytes);
    write_le(bytes.data(), 20, header.input_features);
    write_le(bytes.data(), 24, header.hidden_size);
    write_le(bytes.data(), 32, header.feature_schema);
    write_le(bytes.data(), 40, header.record_count);
    write_le(bytes.data(), 48, header.seed);
    write_le(bytes.data(), 56, header.payload_fnv1a64);
    std::size_t offset = 64;
    for (const auto value : header.phase_counts) { write_le(bytes.data(), offset, value); offset += 8; }
    for (const auto value : header.split_counts) { write_le(bytes.data(), offset, value); offset += 8; }
    for (const auto value : header.source_counts) { write_le(bytes.data(), offset, value); offset += 8; }
    write_le(bytes.data(), offset, header.known_score_count); offset += 8;
    write_le(bytes.data(), offset, header.known_result_count); offset += 8;
    write_le(bytes.data(), offset, header.unique_group_count);
}

[[nodiscard]] bool decode_header(
    const std::array<std::uint8_t, kNnueDatasetHeaderBytes>& bytes,
    NnueDatasetHeader& header,
    std::string* error) {
    if (!std::equal(kDatasetMagic.begin(), kDatasetMagic.end(), bytes.begin())) {
        return fail(error, "NNUE dataset magic mismatch");
    }
    header.format_version = read_le<std::uint32_t>(bytes.data(), 8);
    header.header_bytes = read_le<std::uint32_t>(bytes.data(), 12);
    header.record_bytes = read_le<std::uint32_t>(bytes.data(), 16);
    header.input_features = read_le<std::uint32_t>(bytes.data(), 20);
    header.hidden_size = read_le<std::uint32_t>(bytes.data(), 24);
    header.feature_schema = read_le<std::uint64_t>(bytes.data(), 32);
    header.record_count = read_le<std::uint64_t>(bytes.data(), 40);
    header.seed = read_le<std::uint64_t>(bytes.data(), 48);
    header.payload_fnv1a64 = read_le<std::uint64_t>(bytes.data(), 56);
    std::size_t offset = 64;
    for (auto& value : header.phase_counts) { value = read_le<std::uint64_t>(bytes.data(), offset); offset += 8; }
    for (auto& value : header.split_counts) { value = read_le<std::uint64_t>(bytes.data(), offset); offset += 8; }
    for (auto& value : header.source_counts) { value = read_le<std::uint64_t>(bytes.data(), offset); offset += 8; }
    header.known_score_count = read_le<std::uint64_t>(bytes.data(), offset); offset += 8;
    header.known_result_count = read_le<std::uint64_t>(bytes.data(), offset); offset += 8;
    header.unique_group_count = read_le<std::uint64_t>(bytes.data(), offset);
    if (header.format_version != kNnueDatasetFormatVersion ||
        header.header_bytes != kNnueDatasetHeaderBytes ||
        header.record_bytes != kNnueDatasetRecordBytes ||
        header.input_features != kNnueInputFeatures ||
        header.hidden_size != kNnueHiddenSize ||
        header.feature_schema != kNnueFeatureSchema) {
        return fail(error, "NNUE dataset layout/schema mismatch");
    }
    return true;
}

[[nodiscard]] NnueDatasetHeader summarize_records(
    const std::vector<NnueDatasetRecord>& records,
    std::uint64_t seed,
    std::uint64_t checksum) {
    NnueDatasetHeader header{};
    header.record_count = records.size();
    header.seed = seed;
    header.payload_fnv1a64 = checksum;
    std::unordered_set<std::uint64_t> groups;
    groups.reserve(records.size() / 4 + 1);
    for (const auto& record : records) {
        ++header.phase_counts[phase_index(record.phase)];
        ++header.split_counts[split_index(record.split)];
        ++header.source_counts[source_index(record.source)];
        header.known_score_count += (record.flags & NnueDatasetTargetScoreKnown) != 0 ? 1U : 0U;
        header.known_result_count += (record.flags & NnueDatasetGameResultKnown) != 0 ? 1U : 0U;
        groups.insert(record.group_id);
    }
    header.unique_group_count = groups.size();
    return header;
}

struct PositionKey {
    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    std::uint8_t side = 0;
    [[nodiscard]] bool operator==(const PositionKey&) const noexcept = default;
};
struct PositionKeyHash {
    [[nodiscard]] std::size_t operator()(const PositionKey& key) const noexcept {
        std::uint64_t h = key.white * 0x9E3779B97F4A7C15ULL;
        h ^= key.black + 0x517CC1B727220A95ULL + (h << 6U) + (h >> 2U);
        h ^= key.kings + 0x94D049BB133111EBULL + (h << 6U) + (h >> 2U);
        h ^= key.side;
        return static_cast<std::size_t>(h ^ (h >> 32U));
    }
};

[[nodiscard]] double target_cp(const NnueDatasetRecord& record) noexcept {
    if ((record.flags & NnueDatasetTargetScoreKnown) != 0) return record.target_score_stm;
    if ((record.flags & NnueDatasetGameResultKnown) != 0) return record.game_result_stm * 800.0;
    return 0.0;
}

struct FloatNetwork {
    std::array<float, kNnueHiddenSize> hidden_bias{};
    std::array<float, kNnueInputFeatures * kNnueHiddenSize> input_weights{};
    std::array<float, kNnueHiddenSize> output_weights{};
    float output_bias = 0.0F;
};

[[nodiscard]] FloatNetwork initial_network(std::uint64_t seed) {
    FloatNetwork network{};
    std::mt19937_64 rng(seed);
    std::uniform_real_distribution<float> input_distribution(-0.015F, 0.015F);
    std::uniform_real_distribution<float> output_distribution(-0.02F, 0.02F);
    for (auto& value : network.hidden_bias) value = 0.20F;
    for (auto& value : network.input_weights) value = input_distribution(rng);
    for (auto& value : network.output_weights) value = output_distribution(rng);
    return network;
}

struct ForwardState {
    std::array<float, kNnueHiddenSize> raw{};
    std::array<float, kNnueHiddenSize> activated{};
    NnueFeatureList features{};
    float output = 0.0F;
};

[[nodiscard]] ForwardState forward(
    const NnueDatasetRecord& record,
    const FloatNetwork& network) {
    ForwardState state{};
    const Position position = nnue_dataset_position(record);
    state.features = nnue_active_features(position, position.side_to_move());
    state.raw = network.hidden_bias;
    for (std::size_t i = 0; i < state.features.count; ++i) {
        const std::size_t base = static_cast<std::size_t>(state.features.indices[i]) * kNnueHiddenSize;
        for (std::size_t hidden = 0; hidden < kNnueHiddenSize; ++hidden) {
            state.raw[hidden] += network.input_weights[base + hidden];
        }
    }
    state.output = network.output_bias;
    constexpr float activation_max = static_cast<float>(kNnueActivationMax) / 64.0F;
    for (std::size_t hidden = 0; hidden < kNnueHiddenSize; ++hidden) {
        state.activated[hidden] = std::clamp(state.raw[hidden], 0.0F, activation_max);
        state.output += state.activated[hidden] * network.output_weights[hidden];
    }
    return state;
}

[[nodiscard]] Phase35LossMetrics float_metrics(
    const std::vector<NnueDatasetRecord>& records,
    HceSplit split,
    const FloatNetwork& network,
    double score_scale,
    std::size_t maximum_samples) {
    Phase35LossMetrics metrics{};
    double squared = 0.0;
    double absolute_cp = 0.0;
    std::uint64_t signs = 0;
    for (const auto& record : records) {
        if (record.split != split ||
            (record.flags & (NnueDatasetTargetScoreKnown | NnueDatasetGameResultKnown)) == 0) continue;
        const double target = target_cp(record) / score_scale;
        const double prediction = forward(record, network).output;
        const double error = prediction - target;
        squared += error * error;
        absolute_cp += std::abs(error * score_scale);
        const int target_sign = target > 0.05 ? 1 : (target < -0.05 ? -1 : 0);
        const int prediction_sign = prediction > 0.05 ? 1 : (prediction < -0.05 ? -1 : 0);
        signs += target_sign == prediction_sign ? 1U : 0U;
        ++metrics.samples;
        if (maximum_samples != 0 && metrics.samples >= maximum_samples) break;
    }
    if (metrics.samples != 0) {
        metrics.mean_squared_error = squared / static_cast<double>(metrics.samples);
        metrics.mean_absolute_error_cp = absolute_cp / static_cast<double>(metrics.samples);
        metrics.root_mean_squared_error_cp =
            std::sqrt(metrics.mean_squared_error) * score_scale;
        metrics.sign_accuracy = static_cast<double>(signs) / static_cast<double>(metrics.samples);
    }
    return metrics;
}

[[nodiscard]] NnueModel quantize(const FloatNetwork& network, double score_scale) {
    std::array<std::int32_t, kNnueHiddenSize> hidden_bias{};
    std::array<std::int16_t, kNnueInputFeatures * kNnueHiddenSize> input_weights{};
    std::array<std::int16_t, kNnueHiddenSize> output_weights{};
    for (std::size_t i = 0; i < hidden_bias.size(); ++i) {
        hidden_bias[i] = static_cast<std::int32_t>(std::clamp<long long>(
            std::llround(network.hidden_bias[i] * 64.0), -32768, 32767));
    }
    for (std::size_t i = 0; i < input_weights.size(); ++i) {
        input_weights[i] = static_cast<std::int16_t>(std::clamp<long long>(
            std::llround(network.input_weights[i] * 64.0), -32768, 32767));
    }
    for (std::size_t i = 0; i < output_weights.size(); ++i) {
        output_weights[i] = static_cast<std::int16_t>(std::clamp<long long>(
            std::llround(network.output_weights[i] * score_scale), -32768, 32767));
    }
    const auto output_bias = static_cast<std::int32_t>(std::clamp<long long>(
        std::llround(network.output_bias * score_scale * kNnueOutputScale),
        std::numeric_limits<std::int32_t>::min(),
        std::numeric_limits<std::int32_t>::max()));
    return NnueModel::from_parameters(hidden_bias, input_weights, output_weights, output_bias);
}

[[nodiscard]] double selection_loss(const Phase35LossMetrics& metrics) noexcept {
    return metrics.samples == 0 ? std::numeric_limits<double>::infinity() : metrics.mean_squared_error;
}

void write_metrics_json(std::ostream& output, const char* name, const Phase35LossMetrics& metrics, bool comma) {
    output << "    \"" << name << "\": {\"samples\": " << metrics.samples
           << ", \"mse\": " << metrics.mean_squared_error
           << ", \"mae_cp\": " << metrics.mean_absolute_error_cp
           << ", \"rmse_cp\": " << metrics.root_mean_squared_error_cp
           << ", \"sign_accuracy\": " << metrics.sign_accuracy << "}"
           << (comma ? "," : "") << "\n";
}

}  // namespace

Position nnue_dataset_position(const NnueDatasetRecord& record) {
    return Position::from_bitboards(
        record.white, record.black, record.kings,
        record.side_to_move, record.no_progress_plies);
}

NnueDatasetRecord make_nnue_dataset_record(const HceRecord& record) {
    NnueDatasetRecord output{};
    output.white = record.white;
    output.black = record.black;
    output.kings = record.kings;
    output.group_id = record.group_id;
    output.ply = record.ply;
    output.no_progress_plies = record.no_progress_plies;
    output.side_to_move = record.side_to_move;
    output.phase = record.phase;
    output.split = record.split;
    output.source = record.source;
    output.teacher_depth = record.teacher_depth;
    if ((record.flags & HceTeacherScoreKnown) != 0) {
        const int score = record.side_to_move == Color::White
            ? record.teacher_score_white : -record.teacher_score_white;
        output.target_score_stm = static_cast<std::int16_t>(std::clamp(score, -32767, 32767));
        output.flags = static_cast<std::uint16_t>(output.flags | NnueDatasetTargetScoreKnown);
    }
    if ((record.flags & HceGameResultKnown) != 0) {
        output.game_result_stm = static_cast<std::int8_t>(
            record.side_to_move == Color::White ? record.game_result_white : -record.game_result_white);
        output.flags = static_cast<std::uint16_t>(output.flags | NnueDatasetGameResultKnown);
    }
    if ((record.flags & HceQuietPosition) != 0) {
        output.flags = static_cast<std::uint16_t>(output.flags | NnueDatasetQuietPosition);
    }
    if (record.source == HceSource::ExactEndgame) {
        output.flags = static_cast<std::uint16_t>(output.flags | NnueDatasetExactTeacher);
    }
    if (record.source == HceSource::ExternalTeacher) {
        output.flags = static_cast<std::uint16_t>(output.flags | NnueDatasetExternalTeacher);
    }
    if ((record.flags & HceSymmetryDerivedTeacher) != 0) {
        output.flags = static_cast<std::uint16_t>(output.flags | NnueDatasetSymmetryDerived);
    }
    return output;
}

bool phase35_export_hce_records(
    const std::vector<HceRecord>& input,
    const Phase35ExportOptions& options,
    std::vector<NnueDatasetRecord>& output,
    Phase35ExportReport& report,
    std::string* error) {
    output.clear();
    report = {};
    report.input_records = input.size();
    if (options.maximum_absolute_teacher_score < 1 || options.maximum_absolute_teacher_score > 30000) {
        return fail(error, "Phase 35 maximum teacher score is out of range");
    }
    output.reserve(options.maximum_records == 0 ? input.size() :
                   std::min(input.size(), options.maximum_records));
    for (const auto& record : input) {
        const bool score_known = (record.flags & HceTeacherScoreKnown) != 0;
        const bool result_known = (record.flags & HceGameResultKnown) != 0;
        if (options.require_any_label && !score_known && !result_known) {
            ++report.rejected_missing_label; continue;
        }
        if (options.require_legal && (record.flags & HceLegalPosition) == 0) {
            ++report.rejected_flags; continue;
        }
        if (options.require_quiet && (record.flags & HceQuietPosition) == 0) {
            ++report.rejected_flags; continue;
        }
        if (score_known && record.teacher_depth < options.minimum_teacher_depth) {
            ++report.rejected_depth; continue;
        }
        if (score_known && std::abs(static_cast<int>(record.teacher_score_white)) >
                           options.maximum_absolute_teacher_score) {
            ++report.rejected_score; continue;
        }
        NnueDatasetRecord converted = make_nnue_dataset_record(record);
        try {
            const Position position = nnue_dataset_position(converted);
            std::string validation_error;
            if (!position.validate(&validation_error)) {
                ++report.rejected_flags; continue;
            }
        } catch (...) {
            ++report.rejected_flags; continue;
        }
        output.push_back(converted);
        ++report.accepted_records;
        ++report.split_counts[split_index(converted.split)];
        if (options.maximum_records != 0 && output.size() >= options.maximum_records) break;
    }
    if (output.empty()) return fail(error, "Phase 35 export produced no records");
    return true;
}

bool write_nnue_dataset(
    const std::filesystem::path& path,
    const std::vector<NnueDatasetRecord>& records,
    std::uint64_t seed,
    NnueDatasetHeader* written_header,
    std::string* error) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return fail(error, "cannot open NNUE dataset output");
    std::array<std::uint8_t, kNnueDatasetHeaderBytes> blank{};
    output.write(reinterpret_cast<const char*>(blank.data()), static_cast<std::streamsize>(blank.size()));
    std::uint64_t checksum = kFnvOffset;
    std::array<std::uint8_t, kNnueDatasetRecordBytes> bytes{};
    for (const auto& record : records) {
        encode_record(record, bytes);
        fnv_update(checksum, bytes.data(), bytes.size());
        output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!output) return fail(error, "failed while writing NNUE dataset payload");
    }
    NnueDatasetHeader header = summarize_records(records, seed, checksum);
    std::array<std::uint8_t, kNnueDatasetHeaderBytes> header_bytes{};
    encode_header(header, header_bytes);
    output.seekp(0, std::ios::beg);
    output.write(reinterpret_cast<const char*>(header_bytes.data()), static_cast<std::streamsize>(header_bytes.size()));
    output.flush();
    if (!output) return fail(error, "failed while finalizing NNUE dataset");
    if (written_header != nullptr) *written_header = header;
    return true;
}

bool read_nnue_dataset(
    const std::filesystem::path& path,
    NnueDatasetHeader& header,
    std::vector<NnueDatasetRecord>& records,
    std::string* error) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return fail(error, "cannot open NNUE dataset input");
    std::array<std::uint8_t, kNnueDatasetHeaderBytes> header_bytes{};
    input.read(reinterpret_cast<char*>(header_bytes.data()), static_cast<std::streamsize>(header_bytes.size()));
    if (!input || !decode_header(header_bytes, header, error)) return false;
    if (header.record_count > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        return fail(error, "NNUE dataset is too large for this process");
    }
    records.clear();
    records.reserve(static_cast<std::size_t>(header.record_count));
    std::uint64_t checksum = kFnvOffset;
    std::array<std::uint8_t, kNnueDatasetRecordBytes> bytes{};
    for (std::uint64_t index = 0; index < header.record_count; ++index) {
        input.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!input) return fail(error, "truncated NNUE dataset payload");
        fnv_update(checksum, bytes.data(), bytes.size());
        records.push_back(decode_record(bytes.data()));
    }
    char trailing = 0;
    if (input.read(&trailing, 1)) return fail(error, "unexpected trailing bytes in NNUE dataset");
    if (checksum != header.payload_fnv1a64) return fail(error, "NNUE dataset payload checksum mismatch");
    return validate_nnue_dataset(header, records, error);
}

bool inspect_nnue_dataset(
    const std::filesystem::path& path,
    NnueDatasetHeader& header,
    std::string* error) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return fail(error, "cannot open NNUE dataset input");
    std::array<std::uint8_t, kNnueDatasetHeaderBytes> bytes{};
    input.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!input) return fail(error, "truncated NNUE dataset header");
    return decode_header(bytes, header, error);
}

bool validate_nnue_dataset(
    const NnueDatasetHeader& header,
    const std::vector<NnueDatasetRecord>& records,
    std::string* error) {
    if (header.record_count != records.size()) return fail(error, "NNUE dataset record count mismatch");
    std::array<std::uint64_t, static_cast<std::size_t>(HcePhase::Count)> phases{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSplit::Count)> splits{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSource::Count)> sources{};
    std::uint64_t scores = 0;
    std::uint64_t results = 0;
    std::unordered_map<std::uint64_t, HceSplit> group_splits;
    std::unordered_set<PositionKey, PositionKeyHash> seen;
    group_splits.reserve(records.size() / 4 + 1);
    seen.reserve(records.size() * 11 / 10 + 1);
    for (std::size_t index = 0; index < records.size(); ++index) {
        const auto& record = records[index];
        if (phase_index(record.phase) >= phases.size() || split_index(record.split) >= splits.size() ||
            source_index(record.source) >= sources.size()) {
            return fail(error, "NNUE dataset enum out of range at index " + std::to_string(index));
        }
        if ((record.white & record.black) != 0 ||
            (record.kings & ~(record.white | record.black)) != 0 ||
            std::popcount(record.white) > 12 || std::popcount(record.black) > 12) {
            return fail(error, "invalid NNUE dataset bitboards at index " + std::to_string(index));
        }
        if (record.game_result_stm < -1 || record.game_result_stm > 2) {
            return fail(error, "invalid NNUE game result at index " + std::to_string(index));
        }
        if ((record.flags & NnueDatasetTargetScoreKnown) != 0 &&
            record.target_score_stm == kNnueUnknownTargetScore) {
            return fail(error, "NNUE score flag/value mismatch at index " + std::to_string(index));
        }
        if ((record.flags & (NnueDatasetTargetScoreKnown | NnueDatasetGameResultKnown)) == 0) {
            return fail(error, "NNUE record has no training label at index " + std::to_string(index));
        }
        Position position;
        try { position = nnue_dataset_position(record); }
        catch (...) { return fail(error, "cannot reconstruct NNUE position at index " + std::to_string(index)); }
        std::string validation_error;
        if (!position.validate(&validation_error)) {
            return fail(error, "invalid NNUE position at index " + std::to_string(index));
        }
        if (classify_hce_phase(position) != record.phase) {
            return fail(error, "NNUE phase mismatch at index " + std::to_string(index));
        }
        const PositionKey key{record.white, record.black, record.kings,
                              static_cast<std::uint8_t>(record.side_to_move == Color::White ? 0 : 1)};
        if (!seen.insert(key).second) {
            return fail(error, "duplicate NNUE position at index " + std::to_string(index));
        }
        const auto [iterator, inserted] = group_splits.emplace(record.group_id, record.split);
        if (!inserted && iterator->second != record.split) {
            return fail(error, "NNUE group crosses dataset splits");
        }
        ++phases[phase_index(record.phase)];
        ++splits[split_index(record.split)];
        ++sources[source_index(record.source)];
        scores += (record.flags & NnueDatasetTargetScoreKnown) != 0 ? 1U : 0U;
        results += (record.flags & NnueDatasetGameResultKnown) != 0 ? 1U : 0U;
    }
    if (phases != header.phase_counts || splits != header.split_counts || sources != header.source_counts ||
        scores != header.known_score_count || results != header.known_result_count ||
        group_splits.size() != header.unique_group_count) {
        return fail(error, "NNUE dataset header statistics mismatch");
    }
    return true;
}

Phase35LossMetrics phase35_model_metrics(
    const std::vector<NnueDatasetRecord>& records,
    HceSplit split,
    const NnueModel& model,
    double score_scale,
    std::size_t maximum_samples) {
    Phase35LossMetrics metrics{};
    double squared = 0.0;
    double absolute_cp = 0.0;
    std::uint64_t signs = 0;
    for (const auto& record : records) {
        if (record.split != split ||
            (record.flags & (NnueDatasetTargetScoreKnown | NnueDatasetGameResultKnown)) == 0) continue;
        const double target = target_cp(record);
        const double prediction = evaluate_nnue(nnue_dataset_position(record), model);
        const double error = prediction - target;
        squared += (error / score_scale) * (error / score_scale);
        absolute_cp += std::abs(error);
        const int target_sign = target > 20.0 ? 1 : (target < -20.0 ? -1 : 0);
        const int prediction_sign = prediction > 20.0 ? 1 : (prediction < -20.0 ? -1 : 0);
        signs += target_sign == prediction_sign ? 1U : 0U;
        ++metrics.samples;
        if (maximum_samples != 0 && metrics.samples >= maximum_samples) break;
    }
    if (metrics.samples != 0) {
        metrics.mean_squared_error = squared / static_cast<double>(metrics.samples);
        metrics.mean_absolute_error_cp = absolute_cp / static_cast<double>(metrics.samples);
        metrics.root_mean_squared_error_cp = std::sqrt(metrics.mean_squared_error) * score_scale;
        metrics.sign_accuracy = static_cast<double>(signs) / static_cast<double>(metrics.samples);
    }
    return metrics;
}

bool phase35_train_nnue(
    const NnueDatasetHeader& header,
    const std::vector<NnueDatasetRecord>& records,
    const Phase35TrainOptions& options,
    NnueModel& output_model,
    Phase35TrainReport& report,
    const std::filesystem::path& checkpoint_prefix,
    std::string* error) {
    if (!validate_nnue_dataset(header, records, error)) return false;
    if (options.epochs < 1 || options.epochs > 100 || options.batch_size < 1 ||
        options.learning_rate_output <= 0.0 || options.learning_rate_hidden <= 0.0 ||
        options.score_scale < 50.0 || options.score_scale > 5000.0 ||
        options.gradient_clip <= 0.0) {
        return fail(error, "Phase 35 training options are invalid");
    }
    std::vector<std::size_t> training_indices;
    training_indices.reserve(static_cast<std::size_t>(header.split_counts[split_index(HceSplit::Train)]));
    for (std::size_t index = 0; index < records.size(); ++index) {
        if (records[index].split == HceSplit::Train &&
            (records[index].flags & (NnueDatasetTargetScoreKnown | NnueDatasetGameResultKnown)) != 0) {
            training_indices.push_back(index);
            if (options.maximum_training_samples != 0 &&
                training_indices.size() >= options.maximum_training_samples) break;
        }
    }
    if (training_indices.empty()) return fail(error, "NNUE dataset has no training samples");

    FloatNetwork network = initial_network(options.seed);
    report = {};
    report.dataset_checksum = header.payload_fnv1a64;
    report.train_before = float_metrics(records, HceSplit::Train, network, options.score_scale,
                                        options.maximum_training_samples);
    report.validation_before = float_metrics(records, HceSplit::Validation, network, options.score_scale, 0);
    report.holdout_before = float_metrics(records, HceSplit::Holdout, network, options.score_scale, 0);

    FloatNetwork best = network;
    const bool has_validation = report.validation_before.samples != 0;
    double best_loss = selection_loss(has_validation ? report.validation_before : report.train_before);
    std::mt19937_64 rng(options.seed ^ header.payload_fnv1a64);

    for (int epoch = 1; epoch <= options.epochs; ++epoch) {
        std::shuffle(training_indices.begin(), training_indices.end(), rng);
        for (std::size_t order = 0; order < training_indices.size(); ++order) {
            const NnueDatasetRecord& record = records[training_indices[order]];
            ForwardState state = forward(record, network);
            const float target = static_cast<float>(target_cp(record) / options.score_scale);
            const float error_value = std::clamp(
                state.output - target,
                static_cast<float>(-options.gradient_clip),
                static_cast<float>(options.gradient_clip));
            const auto old_output_weights = network.output_weights;
            network.output_bias -= static_cast<float>(options.learning_rate_output) * error_value;
            const float batch_scale = 1.0F / static_cast<float>(
                std::max<std::size_t>(1, std::min(options.batch_size, training_indices.size())));
            for (std::size_t hidden = 0; hidden < kNnueHiddenSize; ++hidden) {
                const float output_gradient = error_value * state.activated[hidden] +
                    static_cast<float>(options.l2) * network.output_weights[hidden];
                network.output_weights[hidden] -=
                    static_cast<float>(options.learning_rate_output) * output_gradient;
                const bool active = state.raw[hidden] > 0.0F &&
                    state.raw[hidden] < static_cast<float>(kNnueActivationMax) / 64.0F;
                if (!active) continue;
                const float hidden_gradient = error_value * old_output_weights[hidden] * batch_scale;
                network.hidden_bias[hidden] -=
                    static_cast<float>(options.learning_rate_hidden) * hidden_gradient;
                for (std::size_t i = 0; i < state.features.count; ++i) {
                    const std::size_t parameter =
                        static_cast<std::size_t>(state.features.indices[i]) * kNnueHiddenSize + hidden;
                    const float gradient = hidden_gradient +
                        static_cast<float>(options.l2) * network.input_weights[parameter];
                    network.input_weights[parameter] -=
                        static_cast<float>(options.learning_rate_hidden) * gradient;
                }
            }
        }
        const Phase35LossMetrics train = float_metrics(
            records, HceSplit::Train, network, options.score_scale, options.maximum_training_samples);
        const Phase35LossMetrics validation = float_metrics(
            records, HceSplit::Validation, network, options.score_scale, 0);
        const double current_loss = selection_loss(has_validation ? validation : train);
        if (current_loss + 1.0e-12 < best_loss) {
            best_loss = current_loss;
            best = network;
            report.best_epoch = epoch;
            report.validation_improved = true;
        }
        report.epochs_completed = epoch;
        if (!checkpoint_prefix.empty()) {
            NnueModel checkpoint = quantize(network, options.score_scale);
            std::filesystem::path checkpoint_path = checkpoint_prefix;
            checkpoint_path += ".epoch" + std::to_string(epoch) + ".albnn";
            std::string checkpoint_error;
            if (!checkpoint.save(checkpoint_path, &checkpoint_error)) {
                return fail(error, "cannot save NNUE checkpoint: " + checkpoint_error);
            }
        }
    }
    if (report.best_epoch == 0) {
        best = network;
        report.best_epoch = options.epochs;
    }
    output_model = quantize(best, options.score_scale);
    std::string model_error;
    if (!output_model.validate(&model_error)) return fail(error, "trained NNUE model invalid: " + model_error);
    report.model_checksum = output_model.metadata().payload_checksum;
    report.train_after = phase35_model_metrics(
        records, HceSplit::Train, output_model, options.score_scale, options.maximum_training_samples);
    report.validation_after = phase35_model_metrics(
        records, HceSplit::Validation, output_model, options.score_scale, 0);
    report.holdout_after = phase35_model_metrics(
        records, HceSplit::Holdout, output_model, options.score_scale, 0);
    return true;
}

void write_phase35_json_report(
    const std::filesystem::path& path,
    const Phase35ExportReport* export_report,
    const Phase35TrainReport* train_report) {
    std::ofstream output(path, std::ios::trunc);
    if (!output) return;
    output << std::fixed << std::setprecision(9) << "{\n";
    bool wrote = false;
    if (export_report != nullptr) {
        output << "  \"export\": {\"input_records\": " << export_report->input_records
               << ", \"accepted_records\": " << export_report->accepted_records
               << ", \"rejected_missing_label\": " << export_report->rejected_missing_label
               << ", \"rejected_flags\": " << export_report->rejected_flags
               << ", \"rejected_depth\": " << export_report->rejected_depth
               << ", \"rejected_score\": " << export_report->rejected_score << "}";
        wrote = true;
    }
    if (train_report != nullptr) {
        if (wrote) output << ",\n";
        output << "  \"training\": {\n"
               << "    \"epochs_completed\": " << train_report->epochs_completed << ",\n"
               << "    \"best_epoch\": " << train_report->best_epoch << ",\n"
               << "    \"validation_improved\": " << (train_report->validation_improved ? "true" : "false") << ",\n"
               << "    \"dataset_checksum\": " << train_report->dataset_checksum << ",\n"
               << "    \"model_checksum\": " << train_report->model_checksum << ",\n";
        write_metrics_json(output, "train_before", train_report->train_before, true);
        write_metrics_json(output, "validation_before", train_report->validation_before, true);
        write_metrics_json(output, "holdout_before", train_report->holdout_before, true);
        write_metrics_json(output, "train_after", train_report->train_after, true);
        write_metrics_json(output, "validation_after", train_report->validation_after, true);
        write_metrics_json(output, "holdout_after", train_report->holdout_after, false);
        output << "  }";
    }
    output << "\n}\n";
}

}  // namespace albay
