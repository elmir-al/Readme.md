/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/strategic_ordering.hpp"

#include "albay/evaluation.hpp"
#include "albay/geometry.hpp"

#include <array>
#include <bit>
#include <cstdlib>

namespace albay {
namespace {

// Static man-square tables retained from the validated Strength Phase 9 tuning.
inline constexpr std::array<int, kBoardSquares> kOpeningManPst{{
    -6,0,4,2,-4,0,0,2,2,2,2,0,-2,2,-2,0,
    4,0,-4,-2,0,-4,-2,2,0,4,0,0,0,0,0,0}};
inline constexpr std::array<int, kBoardSquares> kMiddlegameManPst{{
    -6,4,0,0,-2,0,0,0,4,2,2,-2,2,0,2,2,
    0,-2,-2,-4,0,2,0,0,0,0,-4,-4,2,2,4,-2}};

[[nodiscard]] std::size_t canonical_index(Color color, Square square) noexcept {
    const int original = static_cast<int>(square);
    if (original < 0 || original >= kBoardSquares) return 0U;
    if (color == Color::White) return static_cast<std::size_t>(original);
    const BoardCoordinate coordinate = coordinate_of(square);
    const Square rotated = square_from_file_rank(7 - coordinate.file, 7 - coordinate.rank);
    const int value = static_cast<int>(rotated);
    return value >= 0 && value < kBoardSquares
        ? static_cast<std::size_t>(value)
        : static_cast<std::size_t>(original);
}

}  // namespace

int strategic_man_square_value(
    const Position& position, Color color, Square square) noexcept {
    if (!is_valid_square(square) || position.is_king(square)) return 0;
    const EvaluationPhaseMix phase = evaluation_phase_mix(position);
    if (phase.opening == 0 && phase.middlegame == 0) return 0;
    const std::size_t index = canonical_index(color, square);
    return (kOpeningManPst[index] * phase.opening +
            kMiddlegameManPst[index] * phase.middlegame) / 100;
}

int strategic_quiet_move_delta(
    const Position& position, const Move& move) noexcept {
    if (move.is_capture() || move.moving_piece_was_king() ||
        !is_valid_square(move.from) || !is_valid_square(move.to)) {
        return 0;
    }
    const Color mover = position.side_to_move();
    return strategic_man_square_value(position, mover, move.to) -
           strategic_man_square_value(position, mover, move.from);
}


int strategic_opening_quiet_move_delta(
    const Position& position, const Move& move) noexcept {
    if (move.is_capture() || move.moving_piece_was_king() ||
        !is_valid_square(move.from) || !is_valid_square(move.to)) {
        return 0;
    }
    const EvaluationPhaseMix phase = evaluation_phase_mix(position);
    if (phase.opening == 0) return 0;
    const Color mover = position.side_to_move();
    const std::size_t from = canonical_index(mover, move.from);
    const std::size_t to = canonical_index(mover, move.to);
    return (kOpeningManPst[to] - kOpeningManPst[from]) * phase.opening / 100;
}

int strategic_quiet_continuation_prior(
    const Position& position,
    const Move& move,
    const Move* previous_move) noexcept {
    int score = strategic_quiet_move_delta(position, move) * 16;
    if (previous_move == nullptr || !is_valid_square(previous_move->to) ||
        move.is_capture() || move.moving_piece_was_king()) {
        return score;
    }

    const BoardCoordinate previous = coordinate_of(previous_move->to);
    const BoardCoordinate from = coordinate_of(move.from);
    const BoardCoordinate to = coordinate_of(move.to);

    // A response on the same wing is a useful but deliberately weak prior.
    const bool previous_left = previous.file <= 3;
    const bool target_left = to.file <= 3;
    score += previous_left == target_left ? 6 : -2;

    // Reward a connected continuation; penalize abandoning the local structure.
    const int from_distance = std::abs(from.file - previous.file) +
        std::abs(from.rank - previous.rank);
    const int to_distance = std::abs(to.file - previous.file) +
        std::abs(to.rank - previous.rank);
    if (to_distance <= 2) score += 8;
    else if (from_distance <= 2 && to_distance >= 4) score -= 5;

    return score;
}

}  // namespace albay
