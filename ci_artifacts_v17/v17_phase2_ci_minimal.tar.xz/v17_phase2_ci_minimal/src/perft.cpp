/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/perft.hpp"

#include "albay/movegen.hpp"

namespace albay {

std::uint64_t perft(Position& position, int depth) {
    if (depth <= 0) {
        return 1;
    }

    MoveList moves;
    generate_legal_moves(position, moves);
    if (depth == 1) {
        return moves.size();
    }

    std::uint64_t nodes = 0;
    for (const Move& move : moves) {
        UndoState undo{};
        position.make_move_unchecked(move, undo);
        nodes += perft(position, depth - 1);
        position.unmake_move(move, undo);
    }
    return nodes;
}

std::vector<std::pair<Move, std::uint64_t>> perft_divide(Position& position, int depth) {
    std::vector<std::pair<Move, std::uint64_t>> result;
    if (depth <= 0) {
        return result;
    }

    MoveList moves;
    generate_legal_moves(position, moves);
    result.reserve(moves.size());
    for (const Move& move : moves) {
        UndoState undo{};
        position.make_move_unchecked(move, undo);
        const std::uint64_t nodes = perft(position, depth - 1);
        position.unmake_move(move, undo);
        result.emplace_back(move, nodes);
    }
    return result;
}

}  // namespace albay
