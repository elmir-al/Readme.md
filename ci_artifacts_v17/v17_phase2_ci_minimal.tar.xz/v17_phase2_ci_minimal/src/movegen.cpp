/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/movegen.hpp"

#include "albay/geometry.hpp"

#include <bit>

namespace albay {
namespace {

struct CaptureContext {
    Color mover;
    Bitboard occupied_without_origin;
    Bitboard opponent_pieces;
    bool started_as_king;
    MoveList& output;
};

[[nodiscard]] inline Square pop_nearest_on_ray(Bitboard& squares, std::size_t direction) noexcept {
    const Square square = direction < 2
        ? static_cast<Square>(31 - std::countl_zero(squares))
        : static_cast<Square>(std::countr_zero(squares));
    squares &= ~bit(square);
    return square;
}

[[nodiscard]] inline Square first_blocker_on_ray(
    Square from,
    std::size_t direction,
    Bitboard occupied) noexcept {
    Bitboard blockers =
        kDiagonalRayTable[static_cast<std::size_t>(from)][direction].mask & occupied;
    if (blockers == 0) {
        return kNoSquare;
    }
    return direction < 2
        ? static_cast<Square>(31 - std::countl_zero(blockers))
        : static_cast<Square>(std::countr_zero(blockers));
}

[[nodiscard]] inline Bitboard empty_ray_prefix(
    Square from,
    std::size_t direction,
    Bitboard occupied) noexcept {
    const DiagonalRay& ray = kDiagonalRayTable[static_cast<std::size_t>(from)][direction];
    const Bitboard blockers = ray.mask & occupied;
    if (blockers == 0) {
        return ray.mask;
    }
    const Square blocker = direction < 2
        ? static_cast<Square>(31 - std::countl_zero(blockers))
        : static_cast<Square>(std::countr_zero(blockers));
    return kDiagonalBeforeTable[static_cast<std::size_t>(from)][direction]
                               [static_cast<std::size_t>(blocker)];
}

[[nodiscard]] inline Bitboard dynamic_occupied(
    const CaptureContext& context,
    Square current) noexcept {
    return context.occupied_without_origin | bit(current);
}

[[nodiscard]] inline bool man_has_immediate_capture(
    Bitboard occupied,
    Bitboard opponents,
    Square from) noexcept {
    const auto& step_bits = kDiagonalStepBitTable[static_cast<std::size_t>(from)];
    const auto& jump_bits = kDiagonalJumpBitTable[static_cast<std::size_t>(from)];
    for (std::size_t direction = 0; direction < 4; ++direction) {
        if (step_bits[direction] != 0 && jump_bits[direction] != 0 &&
            (opponents & step_bits[direction]) != 0 &&
            (occupied & jump_bits[direction]) == 0) {
            return true;
        }
    }
    return false;
}

[[nodiscard]] inline bool king_has_immediate_capture(
    Bitboard occupied,
    Bitboard opponents,
    Square from) noexcept {
    for (std::size_t direction = 0; direction < 4; ++direction) {
        const Square blocker = first_blocker_on_ray(from, direction, occupied);
        if (!is_valid_square(blocker) || (opponents & bit(blocker)) == 0) {
            continue;
        }
        const Square landing = kDiagonalStepTable[static_cast<std::size_t>(blocker)][direction];
        if (is_valid_square(landing) && (occupied & bit(landing)) == 0) {
            return true;
        }
    }
    return false;
}

[[nodiscard]] Bitboard immediate_capture_starters(const Position& position) noexcept {
    const Color mover = position.side_to_move();
    const Bitboard occupied = position.occupied();
    const Bitboard opponents = position.pieces(opposite(mover));
    const Bitboard kings = position.kings(mover);
    Bitboard starters = 0;

    Bitboard men_left = position.men(mover);
    while (men_left != 0) {
        const Square from = static_cast<Square>(std::countr_zero(men_left));
        men_left &= men_left - 1U;
        if (man_has_immediate_capture(occupied, opponents, from)) {
            starters |= bit(from);
        }
    }

    Bitboard kings_left = kings;
    while (kings_left != 0) {
        const Square from = static_cast<Square>(std::countr_zero(kings_left));
        kings_left &= kings_left - 1U;
        if (king_has_immediate_capture(occupied, opponents, from)) {
            starters |= bit(from);
        }
    }
    return starters;
}

void emit_capture_leaf(
    const CaptureContext& context,
    Square current,
    bool current_is_king,
    const Move& partial) {
    Move complete = partial;
    complete.to = current;
    complete.landing_count = complete.capture_count;
    complete.flags = static_cast<std::uint8_t>(MoveCapture);
    if (context.started_as_king) {
        complete.flags = static_cast<std::uint8_t>(complete.flags | MoveMovingKing);
    }
    if (!context.started_as_king && current_is_king) {
        complete.flags = static_cast<std::uint8_t>(complete.flags | MovePromotion);
    }
    context.output.push_back(complete);
}

void generate_king_capture_chain(
    const CaptureContext& context,
    Square current,
    Bitboard captured_mask,
    Move& partial);

void generate_man_capture_chain(
    const CaptureContext& context,
    Square current,
    Bitboard captured_mask,
    Move& partial) {
    bool found_continuation = false;
    const Bitboard occupied = dynamic_occupied(context, current);
    const auto& steps = kDiagonalStepTable[static_cast<std::size_t>(current)];
    const auto& jumps = kDiagonalJumpTable[static_cast<std::size_t>(current)];
    const auto& step_bits = kDiagonalStepBitTable[static_cast<std::size_t>(current)];
    const auto& jump_bits = kDiagonalJumpBitTable[static_cast<std::size_t>(current)];

    for (std::size_t direction = 0; direction < 4; ++direction) {
        const Bitboard jumped_bit = step_bits[direction];
        const Bitboard landing_bit = jump_bits[direction];
        if (jumped_bit == 0 || landing_bit == 0 ||
            (context.opponent_pieces & jumped_bit) == 0 ||
            (captured_mask & jumped_bit) != 0 ||
            (occupied & landing_bit) != 0) {
            continue;
        }

        found_continuation = true;
        const std::uint8_t path_index = partial.capture_count;
        const Square landing = jumps[direction];
        partial.captures[path_index] = steps[direction];
        partial.landings[path_index] = landing;
        ++partial.capture_count;

        if (is_promotion_rank(context.mover, landing)) {
            generate_king_capture_chain(context, landing, captured_mask | jumped_bit, partial);
        } else {
            generate_man_capture_chain(context, landing, captured_mask | jumped_bit, partial);
        }
        --partial.capture_count;
    }

    if (!found_continuation && partial.capture_count > 0) {
        emit_capture_leaf(context, current, false, partial);
    }
}

void generate_king_capture_chain(
    const CaptureContext& context,
    Square current,
    Bitboard captured_mask,
    Move& partial) {
    bool found_capture_direction = false;
    const Bitboard occupied = dynamic_occupied(context, current);

    for (std::size_t direction = 0; direction < 4; ++direction) {
        const Square jumped = first_blocker_on_ray(current, direction, occupied);
        if (!is_valid_square(jumped)) {
            continue;
        }

        const Bitboard jumped_bit = bit(jumped);
        if ((context.opponent_pieces & jumped_bit) == 0 ||
            (captured_mask & jumped_bit) != 0) {
            continue;
        }

        Bitboard landings = empty_ray_prefix(jumped, direction, occupied);
        if (landings == 0) {
            continue;
        }
        found_capture_direction = true;

        // Russian draughts allows a free choice between different capture
        // directions, but a chosen king jump may not be stopped on a landing
        // square when another landing beyond the same jumped piece continues
        // the capture. Generate this direction contiguously, then remove only
        // its truncated one-jump leaves when a complete continuation exists.
        // This is not the Brazilian maximum-capture rule: another initial
        // direction may still legally capture fewer pieces.
        const std::size_t direction_begin = context.output.size();
        const std::uint8_t count_before_jump = partial.capture_count;

        while (landings != 0) {
            const Square landing = pop_nearest_on_ray(landings, direction);
            const std::uint8_t path_index = partial.capture_count;
            partial.captures[path_index] = jumped;
            partial.landings[path_index] = landing;
            ++partial.capture_count;

            generate_king_capture_chain(
                context, landing, captured_mask | jumped_bit, partial);

            --partial.capture_count;
        }

        const std::uint8_t one_jump_count =
            static_cast<std::uint8_t>(count_before_jump + 1U);
        const std::size_t direction_end = context.output.size();
        bool has_forced_continuation = false;
        for (std::size_t index = direction_begin; index < direction_end; ++index) {
            if (context.output[index].capture_count > one_jump_count) {
                has_forced_continuation = true;
                break;
            }
        }
        if (has_forced_continuation) {
            std::size_t write = direction_begin;
            for (std::size_t read = direction_begin; read < direction_end; ++read) {
                if (context.output[read].capture_count > one_jump_count) {
                    if (write != read) {
                        context.output[write] = context.output[read];
                    }
                    ++write;
                }
            }
            context.output.resize(write);
        }
    }

    if (!found_capture_direction && partial.capture_count > 0) {
        emit_capture_leaf(context, current, true, partial);
    }
}

void generate_captures_for_piece(const Position& position, Square from, MoveList& output) {
    const Color mover = position.side_to_move();
    const bool started_as_king = position.is_king(from);
    CaptureContext context{
        mover,
        position.occupied() & ~bit(from),
        position.pieces(opposite(mover)),
        started_as_king,
        output,
    };

    Move partial{};
    partial.from = from;
    if (started_as_king) {
        generate_king_capture_chain(context, from, 0, partial);
    } else {
        generate_man_capture_chain(context, from, 0, partial);
    }
}

void generate_quiet_moves(const Position& position, MoveList& output) {
    const Color mover = position.side_to_move();
    const Bitboard occupied = position.occupied();
    const Bitboard kings = position.kings(mover);
    Bitboard pieces_left = position.pieces(mover);

    while (pieces_left != 0) {
        const Square from = static_cast<Square>(std::countr_zero(pieces_left));
        pieces_left &= pieces_left - 1U;

        if ((kings & bit(from)) != 0) {
            for (std::size_t direction = 0; direction < 4; ++direction) {
                Bitboard landings = empty_ray_prefix(from, direction, occupied);
                while (landings != 0) {
                    const Square landing = pop_nearest_on_ray(landings, direction);
                    Move move{};
                    move.from = from;
                    move.to = landing;
                    move.landings[0] = landing;
                    move.landing_count = 1;
                    move.flags = MoveMovingKing;
                    output.push_back(move);
                }
            }
            continue;
        }

        const std::size_t first_direction = mover == Color::White ? 2U : 0U;
        const auto& steps = kDiagonalStepTable[static_cast<std::size_t>(from)];
        const auto& step_bits = kDiagonalStepBitTable[static_cast<std::size_t>(from)];
        for (std::size_t offset = 0; offset < 2; ++offset) {
            const std::size_t direction = first_direction + offset;
            if (step_bits[direction] == 0 || (occupied & step_bits[direction]) != 0) {
                continue;
            }
            const Square landing = steps[direction];
            Move move{};
            move.from = from;
            move.to = landing;
            move.landings[0] = landing;
            move.landing_count = 1;
            if (is_promotion_rank(mover, landing)) {
                move.flags = MovePromotion;
            }
            output.push_back(move);
        }
    }
}

}  // namespace

bool generate_capture_moves(const Position& position, MoveList& output) {
    output.clear();
    Bitboard capture_starters = immediate_capture_starters(position);
    if (capture_starters == 0) {
        return false;
    }

    while (capture_starters != 0) {
        const Square from = static_cast<Square>(std::countr_zero(capture_starters));
        capture_starters &= capture_starters - 1U;
        generate_captures_for_piece(position, from, output);
    }
    return true;
}

void generate_legal_moves(const Position& position, MoveList& output) {
    if (generate_capture_moves(position, output)) {
        return;
    }
    generate_quiet_moves(position, output);
}

MoveList generate_legal_moves(const Position& position) {
    MoveList output;
    generate_legal_moves(position, output);
    return output;
}

bool has_any_capture(const Position& position) {
    return immediate_capture_starters(position) != 0;
}

bool has_any_quiet_move(const Position& position) {
    const Color mover = position.side_to_move();
    const Bitboard occupied = position.occupied();
    const Bitboard kings = position.kings(mover);
    Bitboard pieces_left = position.pieces(mover);

    while (pieces_left != 0) {
        const Square from = static_cast<Square>(std::countr_zero(pieces_left));
        pieces_left &= pieces_left - 1U;

        if ((kings & bit(from)) != 0) {
            for (std::size_t direction = 0; direction < 4; ++direction) {
                if (empty_ray_prefix(from, direction, occupied) != 0) {
                    return true;
                }
            }
            continue;
        }

        const std::size_t first_direction = mover == Color::White ? 2U : 0U;
        const auto& step_bits = kDiagonalStepBitTable[static_cast<std::size_t>(from)];
        for (std::size_t offset = 0; offset < 2; ++offset) {
            const Bitboard target = step_bits[first_direction + offset];
            if (target != 0 && (occupied & target) == 0) {
                return true;
            }
        }
    }
    return false;
}

bool is_legal_move(const Position& position, const Move& candidate) {
    MoveList legal_moves;
    generate_legal_moves(position, legal_moves);
    for (const Move& move : legal_moves) {
        if (move == candidate) {
            return true;
        }
    }
    return false;
}

}  // namespace albay
