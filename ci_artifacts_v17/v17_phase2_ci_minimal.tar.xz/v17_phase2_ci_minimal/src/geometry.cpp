/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#include "albay/geometry.hpp"

#include <cctype>

namespace albay {

std::string square_name(Square square) {
    if (!is_valid_square(square)) {
        return "--";
    }
    const BoardCoordinate coordinate = coordinate_of(square);
    std::string result;
    result.push_back(static_cast<char>('a' + coordinate.file));
    result.push_back(static_cast<char>('1' + coordinate.rank));
    return result;
}

std::optional<Square> parse_square(std::string_view text) {
    if (text.size() != 2) {
        return std::nullopt;
    }
    const char file_character = static_cast<char>(std::tolower(static_cast<unsigned char>(text[0])));
    const char rank_character = text[1];
    if (file_character < 'a' || file_character > 'h' || rank_character < '1' || rank_character > '8') {
        return std::nullopt;
    }
    const Square square = square_from_file_rank(file_character - 'a', rank_character - '1');
    if (!is_valid_square(square)) {
        return std::nullopt;
    }
    return square;
}

}  // namespace albay
