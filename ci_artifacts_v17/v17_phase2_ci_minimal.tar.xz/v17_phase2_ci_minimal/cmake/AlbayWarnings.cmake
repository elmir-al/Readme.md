# Copyright © 2026 Elmir Hajizada
# All rights reserved.
#
# This software was independently designed and developed for the
# Albay Russian Draughts Engine project.

function(albay_enable_warnings target_name)
    if(MSVC)
        target_compile_options(${target_name} PRIVATE /W4 /permissive-)
    else()
        target_compile_options(${target_name} PRIVATE
            -Wall
            -Wextra
            -Wpedantic
            -Wconversion
            -Wshadow
            -Wnon-virtual-dtor
        )
    endif()
endfunction()
