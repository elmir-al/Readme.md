/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/position.hpp"

#include <array>
#include <cstdint>
#include <iosfwd>
#include <string>
#include <vector>

namespace albay {

struct OpeningPosition {
    std::string id;
    Position position;
    std::string move_sequence;
};

[[nodiscard]] bool load_opening_suite(
    std::istream& input,
    std::vector<OpeningPosition>& openings,
    std::string* error = nullptr);
[[nodiscard]] bool load_opening_suite_file(
    const std::string& path,
    std::vector<OpeningPosition>& openings,
    std::string* error = nullptr);

enum class SprtDecision {
    Continue,
    AcceptNull,
    AcceptAlternative,
};

struct SprtConfig {
    double elo0 = -5.0;
    double elo1 = 5.0;
    double alpha = 0.05;
    double beta = 0.05;
};

struct SprtState {
    int wins = 0;
    int draws = 0;
    int losses = 0;
    double points = 0.0;
    double llr = 0.0;

    [[nodiscard]] int games() const noexcept { return wins + draws + losses; }
};

[[nodiscard]] bool validate_sprt_config(const SprtConfig& config) noexcept;
[[nodiscard]] double elo_expected_score(double elo) noexcept;
[[nodiscard]] double sprt_lower_boundary(const SprtConfig& config) noexcept;
[[nodiscard]] double sprt_upper_boundary(const SprtConfig& config) noexcept;
[[nodiscard]] double sprt_score_increment(double score, const SprtConfig& config) noexcept;
void update_sprt(SprtState& state, double score, const SprtConfig& config) noexcept;
[[nodiscard]] SprtDecision sprt_decision(
    const SprtState& state,
    const SprtConfig& config) noexcept;
[[nodiscard]] const char* sprt_decision_name(SprtDecision decision) noexcept;


struct PairedScoreStatistics {
    // Pair score bins for engine A: 0.0, 0.5, 1.0, 1.5, 2.0 points.
    std::array<std::uint64_t, 5> bins{};

    void add(double pair_score) noexcept;
    [[nodiscard]] std::uint64_t pairs() const noexcept;
    [[nodiscard]] double total_points() const noexcept;
    [[nodiscard]] double mean_game_score() const noexcept;
    [[nodiscard]] double standard_error_game_score() const noexcept;
    [[nodiscard]] double elo_estimate() const noexcept;
    [[nodiscard]] double elo_lower_95() const noexcept;
    [[nodiscard]] double elo_upper_95() const noexcept;
};

struct MatchCheckpoint {
    int format_version = 2;
    std::string run_fingerprint;
    int completed_pairs = 0;
    int max_ply_adjudications = 0;
    std::uint64_t nodes_a = 0;
    std::uint64_t nodes_b = 0;
    SprtState sprt{};
    PairedScoreStatistics paired{};
};

[[nodiscard]] bool save_match_checkpoint_atomic(
    const std::string& path,
    const MatchCheckpoint& checkpoint,
    std::string* error = nullptr);
[[nodiscard]] bool load_match_checkpoint(
    const std::string& path,
    MatchCheckpoint& checkpoint,
    std::string* error = nullptr);

}  // namespace albay
