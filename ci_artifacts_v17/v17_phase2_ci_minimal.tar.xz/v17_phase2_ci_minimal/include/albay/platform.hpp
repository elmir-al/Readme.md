/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include <bit>
#include <cstdint>
#include <string_view>

namespace albay {

enum class CpuArchitecture : std::uint8_t {
    Unknown,
    X86_64,
    Arm64,
};

enum class AndroidCpuProfile : std::uint8_t {
    NotAndroid,
    Portable,
    Modern,
    Custom,
};

#if defined(__aarch64__) || defined(_M_ARM64)
inline constexpr CpuArchitecture kCpuArchitecture = CpuArchitecture::Arm64;
#elif defined(__x86_64__) || defined(_M_X64)
inline constexpr CpuArchitecture kCpuArchitecture = CpuArchitecture::X86_64;
#else
inline constexpr CpuArchitecture kCpuArchitecture = CpuArchitecture::Unknown;
#endif

#if defined(ALBAY_ANDROID_CPU_PROFILE_PORTABLE)
inline constexpr AndroidCpuProfile kAndroidCpuProfile = AndroidCpuProfile::Portable;
#elif defined(ALBAY_ANDROID_CPU_PROFILE_MODERN)
inline constexpr AndroidCpuProfile kAndroidCpuProfile = AndroidCpuProfile::Modern;
#elif defined(ALBAY_ANDROID_CPU_PROFILE_CUSTOM)
inline constexpr AndroidCpuProfile kAndroidCpuProfile = AndroidCpuProfile::Custom;
#else
inline constexpr AndroidCpuProfile kAndroidCpuProfile = AndroidCpuProfile::NotAndroid;
#endif

[[nodiscard]] constexpr int popcount32(std::uint32_t value) noexcept {
    return std::popcount(value);
}

[[nodiscard]] constexpr int lsb_index32(std::uint32_t value) noexcept {
    return value == 0U ? 32 : static_cast<int>(std::countr_zero(value));
}

[[nodiscard]] constexpr int msb_index32(std::uint32_t value) noexcept {
    return value == 0U ? -1 : 31 - static_cast<int>(std::countl_zero(value));
}

[[nodiscard]] constexpr std::string_view cpu_architecture_name() noexcept {
    switch (kCpuArchitecture) {
        case CpuArchitecture::X86_64: return "x86_64";
        case CpuArchitecture::Arm64: return "arm64";
        default: return "unknown";
    }
}

[[nodiscard]] constexpr std::string_view android_cpu_profile_name() noexcept {
    switch (kAndroidCpuProfile) {
        case AndroidCpuProfile::Portable: return "portable-armv8-a";
        case AndroidCpuProfile::Modern: return "modern-armv8.2-a+dotprod";
        case AndroidCpuProfile::Custom: return "custom-mcpu";
        default: return "not-android";
    }
}

#if defined(__aarch64__) || defined(_M_ARM64)
inline constexpr bool kArm64NeonAvailable = true;
#else
inline constexpr bool kArm64NeonAvailable = false;
#endif

#if defined(ALBAY_BUILD_THIN_LTO)
inline constexpr bool kBuildThinLto = true;
#else
inline constexpr bool kBuildThinLto = false;
#endif
#if defined(ALBAY_BUILD_PGO_GENERATE)
inline constexpr bool kBuildPgoGenerate = true;
#else
inline constexpr bool kBuildPgoGenerate = false;
#endif
#if defined(ALBAY_BUILD_PGO_USE)
inline constexpr bool kBuildPgoUse = true;
#else
inline constexpr bool kBuildPgoUse = false;
#endif

}  // namespace albay
