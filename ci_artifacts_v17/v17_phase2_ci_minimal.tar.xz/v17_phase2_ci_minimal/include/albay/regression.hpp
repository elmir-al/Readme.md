/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/search.hpp"

#include <iosfwd>
#include <string>
#include <vector>

namespace albay {

enum class RegressionCaseKind {
    Objective,
    SearchBaseline,
};

struct RegressionCase {
    std::string id;
    RegressionCaseKind kind = RegressionCaseKind::Objective;
    int depth = 6;
    std::string apf;
    std::vector<std::string> accepted_moves;
    Score minimum_score = -kInfiniteScore;
    Score maximum_score = kInfiniteScore;
};

struct RegressionCaseResult {
    std::string id;
    bool passed = false;
    std::string message;
    std::string best_move;
    Score score = 0;
    int completed_depth = 0;
    std::uint64_t nodes = 0;
};

[[nodiscard]] bool load_regression_suite(
    std::istream& input,
    std::vector<RegressionCase>& cases,
    std::string* error = nullptr);
[[nodiscard]] bool load_regression_suite_file(
    const std::string& path,
    std::vector<RegressionCase>& cases,
    std::string* error = nullptr);
[[nodiscard]] RegressionCaseResult run_regression_case(
    const RegressionCase& test_case,
    const SearchOptions& options = {});

}  // namespace albay
