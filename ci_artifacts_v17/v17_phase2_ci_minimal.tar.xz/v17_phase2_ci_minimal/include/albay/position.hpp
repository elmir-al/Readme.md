/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/move.hpp"
#include "albay/types.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace albay {

struct UndoState {
    Bitboard captured_mask = 0;
    Bitboard captured_kings = 0;
    std::uint16_t previous_no_progress_plies = 0;
    bool moving_piece_was_king = false;
};

enum class GameResult : std::uint8_t {
    Ongoing,
    WhiteWin,
    BlackWin,
    DrawByRepetition,
    DrawByNoProgress,
};

class Position {
public:
    Position();
    Position(const Position& other) noexcept;
    Position& operator=(const Position& other) noexcept;

    [[nodiscard]] static Position initial();
    [[nodiscard]] static Position from_bitboards(
        Bitboard white,
        Bitboard black,
        Bitboard kings,
        Color side_to_move,
        std::uint16_t no_progress_plies = 0);

    void reset_to_initial();

    [[nodiscard]] Bitboard white() const noexcept { return white_; }
    [[nodiscard]] Bitboard black() const noexcept { return black_; }
    [[nodiscard]] Bitboard kings() const noexcept { return kings_; }
    [[nodiscard]] Bitboard occupied() const noexcept { return white_ | black_; }
    [[nodiscard]] Bitboard pieces(Color color) const noexcept {
        return color == Color::White ? white_ : black_;
    }
    [[nodiscard]] Bitboard men(Color color) const noexcept {
        return pieces(color) & ~kings_;
    }
    [[nodiscard]] Bitboard kings(Color color) const noexcept {
        return pieces(color) & kings_;
    }
    [[nodiscard]] bool is_king(Square square) const noexcept {
        return (kings_ & bit(square)) != 0;
    }
    [[nodiscard]] bool is_empty(Square square) const noexcept {
        return (occupied() & bit(square)) == 0;
    }
    [[nodiscard]] Color side_to_move() const noexcept { return side_to_move_; }
    [[nodiscard]] HashKey key() const noexcept { return key_; }
    [[nodiscard]] std::uint16_t no_progress_plies() const noexcept { return no_progress_plies_; }
    [[nodiscard]] std::uint16_t history_size() const noexcept { return history_size_; }
    [[nodiscard]] HashKey history_fingerprint() const noexcept;

    [[nodiscard]] bool validate(std::string* error = nullptr) const;
    [[nodiscard]] HashKey recompute_key() const noexcept;

    void make_move(const Move& move, UndoState& undo);
    // Search/perft fast path. The caller must pass a generated legal move.
    void make_move_unchecked(const Move& move, UndoState& undo);
    void unmake_move(const Move& move, const UndoState& undo) noexcept;

    [[nodiscard]] int repetition_count() const noexcept;
    [[nodiscard]] bool is_threefold_repetition() const noexcept {
        return repetition_count() >= 3;
    }

    [[nodiscard]] GameResult game_result() const;

private:
    void initialize_history() noexcept;

    Bitboard white_ = 0;
    Bitboard black_ = 0;
    Bitboard kings_ = 0;
    Color side_to_move_ = Color::White;
    HashKey key_ = 0;
    std::uint16_t no_progress_plies_ = 0;
    std::array<HashKey, kMaxHistoryPly> key_history_{};
    std::uint16_t history_size_ = 0;
};

}  // namespace albay
