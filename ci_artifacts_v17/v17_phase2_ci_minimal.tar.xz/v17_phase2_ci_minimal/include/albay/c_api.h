/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#ifndef ALBAY_C_API_H
#define ALBAY_C_API_H

#include <stddef.h>
#include <stdint.h>

#if defined(_WIN32) && !defined(ALBAY_STATIC)
  #if defined(ALBAY_IMPLEMENTATION)
    #define ALBAY_API __declspec(dllexport)
  #else
    #define ALBAY_API __declspec(dllimport)
  #endif
#else
  #define ALBAY_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct albay_engine albay_engine;

typedef enum albay_status {
    ALBAY_STATUS_OK = 0,
    ALBAY_STATUS_INVALID_ARGUMENT = 1,
    ALBAY_STATUS_INVALID_POSITION = 2,
    ALBAY_STATUS_ILLEGAL_MOVE = 3,
    ALBAY_STATUS_BUSY = 4,
    ALBAY_STATUS_NOT_AVAILABLE = 5,
    ALBAY_STATUS_BUFFER_TOO_SMALL = 6,
    ALBAY_STATUS_INTERNAL_ERROR = 7
} albay_status;

typedef enum albay_performance_profile {
    ALBAY_PROFILE_ECO = 0,
    ALBAY_PROFILE_BALANCED = 1,
    ALBAY_PROFILE_PERFORMANCE = 2,
    ALBAY_PROFILE_ANALYSIS = 3,
    ALBAY_PROFILE_MANUAL = 4
} albay_performance_profile;

typedef enum albay_thermal_status {
    ALBAY_THERMAL_UNKNOWN = -1,
    ALBAY_THERMAL_NONE = 0,
    ALBAY_THERMAL_LIGHT = 1,
    ALBAY_THERMAL_MODERATE = 2,
    ALBAY_THERMAL_SEVERE = 3,
    ALBAY_THERMAL_CRITICAL = 4,
    ALBAY_THERMAL_EMERGENCY = 5,
    ALBAY_THERMAL_SHUTDOWN = 6
} albay_thermal_status;

typedef struct albay_runtime_environment {
    uint32_t struct_size;
    int32_t logical_cpu_count;
    int32_t thermal_status;
    int32_t power_save_mode;
    int32_t app_in_background;
} albay_runtime_environment;

typedef struct albay_runtime_info {
    uint32_t struct_size;
    int32_t profile;
    int32_t automatic_threads;
    int32_t hardware_threads;
    int32_t pool_threads;
    int32_t target_threads;
    int32_t thermal_status;
    int32_t constrained_by_thermal;
    int32_t constrained_by_power_saver;
    int32_t constrained_by_background;
} albay_runtime_info;

typedef struct albay_search_limits {
    uint32_t struct_size;
    int32_t depth;
    uint64_t nodes;
    uint64_t move_time_ms;
    int32_t infinite;
} albay_search_limits;

/*
 * Original Albay score contract (raw native domain):
 * - C API score fields/functions return the searcher's unscaled native score;
 * - ordinary/non-terminal evaluations stay in -28999..+28999;
 * - abs(score) >= 29000 denotes a proven/forced terminal result;
 * - mate/result scores are centred around +/-30000 with distance preserved;
 * - +/-32000 is an internal alpha-beta infinity sentinel and is not a normal
 *   position evaluation exposed by a completed search.
 */
#define ALBAY_EVALUATION_SCALE 30000
#define ALBAY_MATE_THRESHOLD 29000
#define ALBAY_MATE_SCORE 30000
#define ALBAY_INFINITE_SCORE 32000

typedef struct albay_search_info {
    uint32_t struct_size;
    int32_t depth;
    int32_t selective_depth;
    int32_t score;
    uint64_t nodes;
    uint64_t nodes_per_second;
    uint64_t elapsed_ms;
    uint64_t tt_probes;
    uint64_t tt_hits;
    uint64_t tt_cutoffs;
    uint64_t tt_stores;
    uint32_t tt_hashfull_per_mille;
    int32_t searching;
    int32_t paused;
    int32_t threads;
    int32_t active_threads;
    int32_t target_threads;
    int32_t parked_threads;
} albay_search_info;

/* Size of the original Phase 4 search-info prefix for ABI-compatible callers. */
#define ALBAY_SEARCH_INFO_V1_SIZE ((uint32_t)offsetof(albay_search_info, threads))
#define ALBAY_SEARCH_INFO_V2_SIZE ((uint32_t)offsetof(albay_search_info, target_threads))

ALBAY_API albay_engine* albay_engine_create(void);
ALBAY_API void albay_engine_destroy(albay_engine* engine);
ALBAY_API albay_status albay_engine_new_game(albay_engine* engine);
ALBAY_API albay_status albay_engine_set_position(albay_engine* engine, const char* position);
ALBAY_API albay_status albay_engine_get_position(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size);
ALBAY_API albay_status albay_engine_generate_legal_moves(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size);
ALBAY_API int32_t albay_engine_is_legal_move(const albay_engine* engine, const char* move);
ALBAY_API albay_status albay_engine_make_move(albay_engine* engine, const char* move);
ALBAY_API albay_status albay_engine_undo_move(albay_engine* engine);
ALBAY_API albay_status albay_engine_start_search(
    albay_engine* engine, const albay_search_limits* limits);
ALBAY_API albay_status albay_engine_stop_search(albay_engine* engine);
ALBAY_API albay_status albay_engine_pause_search(albay_engine* engine);
ALBAY_API albay_status albay_engine_resume_search(albay_engine* engine);
ALBAY_API albay_status albay_engine_set_runtime_environment(
    albay_engine* engine, const albay_runtime_environment* environment);
ALBAY_API albay_status albay_engine_get_runtime_info(
    const albay_engine* engine, albay_runtime_info* info);
ALBAY_API albay_status albay_engine_set_option(
    albay_engine* engine, const char* name, const char* value);
ALBAY_API albay_status albay_engine_get_search_info(
    const albay_engine* engine, albay_search_info* info);
ALBAY_API albay_status albay_engine_get_best_move(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size);
ALBAY_API albay_status albay_engine_get_principal_variation(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size);
ALBAY_API albay_status albay_engine_get_multipv(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size);
ALBAY_API int32_t albay_engine_get_evaluation_scale(void);
ALBAY_API int32_t albay_engine_evaluate_position(const albay_engine* engine);
ALBAY_API int32_t albay_engine_is_searching(const albay_engine* engine);
ALBAY_API const char* albay_engine_get_name(void);
ALBAY_API const char* albay_engine_get_author(void);
ALBAY_API const char* albay_engine_get_version(void);
ALBAY_API albay_status albay_engine_get_last_error(
    const albay_engine* engine, char* buffer, size_t capacity, size_t* required_size);

#ifdef __cplusplus
}
#endif

#endif
