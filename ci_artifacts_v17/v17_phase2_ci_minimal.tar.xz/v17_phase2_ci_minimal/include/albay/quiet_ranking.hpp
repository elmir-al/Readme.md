/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/move.hpp"
#include "albay/position.hpp"

namespace albay {

struct QuietMoveFeatures {
    int center_delta = 0;
    int friendly_support = 0;
    int forward_lanes = 0;
    int king_mobility = 0;
    int edge_entry = 0;
    int home_rank_departure = 0;
    int advancement_delta = 0;
    int promotion = 0;
};

struct QuietOrderingWeights {
    int center = 48;
    int support = 36;
    int forward_lanes = 24;
    int king_mobility = 8;
    int edge_entry = 44;
    int home_rank_departure = 18;
    int advancement = 0;
    int promotion = 0;
};

[[nodiscard]] QuietMoveFeatures extract_quiet_move_features(
    const Position& position, const Move& move) noexcept;
[[nodiscard]] int score_quiet_move(
    const QuietMoveFeatures& features, const QuietOrderingWeights& weights) noexcept;
[[nodiscard]] int score_quiet_move(
    const Position& position,
    const Move& move,
    const QuietOrderingWeights& weights = {}) noexcept;

}  // namespace albay
