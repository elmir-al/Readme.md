/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/types.hpp"

#include <array>
#include <cstddef>
#include <optional>
#include <utility>
#include <string>
#include <string_view>

namespace albay {

struct BoardCoordinate {
    int file = -1;
    int rank = -1;
};

[[nodiscard]] constexpr bool is_dark_square(int file, int rank) noexcept {
    return file >= 0 && file < 8 && rank >= 0 && rank < 8 && ((file + rank) & 1) == 0;
}

[[nodiscard]] constexpr Square square_from_file_rank(int file, int rank) noexcept {
    return is_dark_square(file, rank)
        ? static_cast<Square>(rank * 4 + file / 2)
        : kNoSquare;
}

[[nodiscard]] constexpr BoardCoordinate coordinate_of(Square square) noexcept {
    if (!is_valid_square(square)) {
        return {};
    }
    const int rank = square / 4;
    const int column = square % 4;
    const int file = 2 * column + (rank & 1);
    return {file, rank};
}

[[nodiscard]] constexpr Square step(Square square, int file_delta, int rank_delta) noexcept {
    const BoardCoordinate coordinate = coordinate_of(square);
    return square_from_file_rank(coordinate.file + file_delta, coordinate.rank + rank_delta);
}


inline constexpr std::array<std::pair<int, int>, 4> kDiagonalDirections{{
    {-1, -1}, {1, -1}, {-1, 1}, {1, 1},
}};

[[nodiscard]] consteval auto make_diagonal_step_table() noexcept {
    std::array<std::array<Square, 4>, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        for (std::size_t direction = 0; direction < kDiagonalDirections.size(); ++direction) {
            const auto [file_delta, rank_delta] = kDiagonalDirections[direction];
            result[static_cast<std::size_t>(square)][direction] =
                step(static_cast<Square>(square), file_delta, rank_delta);
        }
    }
    return result;
}

inline constexpr auto kDiagonalStepTable = make_diagonal_step_table();

[[nodiscard]] constexpr Square diagonal_step(Square square, std::size_t direction) noexcept {
    return is_valid_square(square) && direction < 4
        ? kDiagonalStepTable[static_cast<std::size_t>(square)][direction]
        : kNoSquare;
}

[[nodiscard]] consteval auto make_diagonal_jump_table() noexcept {
    std::array<std::array<Square, 4>, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        for (std::size_t direction = 0; direction < 4; ++direction) {
            const Square middle = diagonal_step(static_cast<Square>(square), direction);
            result[static_cast<std::size_t>(square)][direction] =
                is_valid_square(middle) ? diagonal_step(middle, direction) : kNoSquare;
        }
    }
    return result;
}

inline constexpr auto kDiagonalJumpTable = make_diagonal_jump_table();

[[nodiscard]] constexpr Square diagonal_jump(Square square, std::size_t direction) noexcept {
    return is_valid_square(square) && direction < 4
        ? kDiagonalJumpTable[static_cast<std::size_t>(square)][direction]
        : kNoSquare;
}

inline constexpr std::size_t kMaxDiagonalRayLength = 7;

struct DiagonalRay {
    std::array<Square, kMaxDiagonalRayLength> squares{};
    std::uint8_t length = 0;
    Bitboard mask = 0;
};

[[nodiscard]] consteval auto make_diagonal_ray_table() noexcept {
    std::array<std::array<DiagonalRay, 4>, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        for (std::size_t direction = 0; direction < 4; ++direction) {
            DiagonalRay& ray = result[static_cast<std::size_t>(square)][direction];
            Square cursor = kDiagonalStepTable[static_cast<std::size_t>(square)][direction];
            while (is_valid_square(cursor)) {
                ray.squares[ray.length++] = cursor;
                ray.mask |= bit(cursor);
                cursor = kDiagonalStepTable[static_cast<std::size_t>(cursor)][direction];
            }
        }
    }
    return result;
}

inline constexpr auto kDiagonalRayTable = make_diagonal_ray_table();

[[nodiscard]] consteval auto make_diagonal_before_table() noexcept {
    std::array<std::array<std::array<Bitboard, kBoardSquares>, 4>, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        for (std::size_t direction = 0; direction < 4; ++direction) {
            Bitboard prefix = 0;
            const DiagonalRay& ray =
                kDiagonalRayTable[static_cast<std::size_t>(square)][direction];
            for (std::uint8_t index = 0; index < ray.length; ++index) {
                const Square ray_square = ray.squares[index];
                result[static_cast<std::size_t>(square)][direction]
                      [static_cast<std::size_t>(ray_square)] = prefix;
                prefix |= bit(ray_square);
            }
        }
    }
    return result;
}

inline constexpr auto kDiagonalBeforeTable = make_diagonal_before_table();

[[nodiscard]] consteval auto make_diagonal_step_bit_table() noexcept {
    std::array<std::array<Bitboard, 4>, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        for (std::size_t direction = 0; direction < 4; ++direction) {
            const Square target = kDiagonalStepTable[static_cast<std::size_t>(square)][direction];
            result[static_cast<std::size_t>(square)][direction] =
                is_valid_square(target) ? bit(target) : Bitboard{0};
        }
    }
    return result;
}

inline constexpr auto kDiagonalStepBitTable = make_diagonal_step_bit_table();

[[nodiscard]] consteval auto make_diagonal_jump_bit_table() noexcept {
    std::array<std::array<Bitboard, 4>, kBoardSquares> result{};
    for (int square = 0; square < kBoardSquares; ++square) {
        for (std::size_t direction = 0; direction < 4; ++direction) {
            const Square target = kDiagonalJumpTable[static_cast<std::size_t>(square)][direction];
            result[static_cast<std::size_t>(square)][direction] =
                is_valid_square(target) ? bit(target) : Bitboard{0};
        }
    }
    return result;
}

inline constexpr auto kDiagonalJumpBitTable = make_diagonal_jump_bit_table();

[[nodiscard]] constexpr bool is_promotion_rank(Color color, Square square) noexcept {
    const int rank = coordinate_of(square).rank;
    return color == Color::White ? rank == 7 : rank == 0;
}

[[nodiscard]] std::string square_name(Square square);
[[nodiscard]] std::optional<Square> parse_square(std::string_view text);

}  // namespace albay
