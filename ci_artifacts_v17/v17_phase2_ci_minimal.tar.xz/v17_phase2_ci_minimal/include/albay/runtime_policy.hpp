/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include <string_view>

namespace albay {

enum class PerformanceProfile : int {
    Eco = 0,
    Balanced = 1,
    Performance = 2,
    Analysis = 3,
    Manual = 4,
};

enum class ThermalStatus : int {
    Unknown = -1,
    None = 0,
    Light = 1,
    Moderate = 2,
    Severe = 3,
    Critical = 4,
    Emergency = 5,
    Shutdown = 6,
};

struct RuntimeEnvironment {
    int logical_cpu_count = 1;
    ThermalStatus thermal_status = ThermalStatus::Unknown;
    bool power_save_mode = false;
    bool app_in_background = false;
};

struct ThreadPolicyDecision {
    int hardware_threads = 1;
    int pool_threads = 1;
    int target_threads = 1;
    PerformanceProfile profile = PerformanceProfile::Balanced;
    ThermalStatus thermal_status = ThermalStatus::Unknown;
    bool automatic = true;
    bool constrained_by_thermal = false;
    bool constrained_by_power_saver = false;
    bool constrained_by_background = false;
};

[[nodiscard]] int detected_logical_cpu_count() noexcept;
[[nodiscard]] int normalize_supported_thread_count(int requested) noexcept;
[[nodiscard]] ThreadPolicyDecision select_thread_policy(
    PerformanceProfile profile,
    bool automatic,
    int manual_threads,
    const RuntimeEnvironment& environment) noexcept;
[[nodiscard]] const char* performance_profile_name(PerformanceProfile profile) noexcept;
[[nodiscard]] const char* thermal_status_name(ThermalStatus status) noexcept;
[[nodiscard]] bool parse_performance_profile(
    std::string_view text, PerformanceProfile& profile) noexcept;

}  // namespace albay
