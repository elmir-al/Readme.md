/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include <iosfwd>
#include <string>
#include <vector>

namespace albay {

struct ReleaseCheck {
    std::string name;
    bool passed = false;
    std::string details;
};

struct ReleaseReport {
    std::vector<ReleaseCheck> checks;

    [[nodiscard]] int passed_count() const noexcept;
    [[nodiscard]] int failed_count() const noexcept;
    [[nodiscard]] bool passed() const noexcept;
};

struct ReleaseGateConfig {
    std::string source_root = ".";
    int perft_depth = 8;
    int search_depth = 6;
    int lifecycle_iterations = 24;
};

[[nodiscard]] ReleaseReport run_release_gate(const ReleaseGateConfig& config);
void write_release_report_json(const ReleaseReport& report, std::ostream& output);

}  // namespace albay
