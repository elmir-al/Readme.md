/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/move.hpp"
#include "albay/position.hpp"

#include <cstdint>
#include <functional>
#include <optional>
#include <unordered_map>
#include <vector>

namespace albay {

enum class EndgameOutcome : std::int8_t {
    Unknown = -2,
    Loss = -1,
    Draw = 0,
    Win = 1,
};

struct EndgameSolveOptions {
    int maximum_pieces = 4;
    std::uint64_t node_limit = 250'000;
    int maximum_ply = 192;
    std::function<bool()> should_stop{};
};

struct EndgameSolveResult {
    EndgameOutcome outcome = EndgameOutcome::Unknown;
    int distance_to_result = 0;
    bool distance_is_exact = false;
    std::optional<Move> best_move;
    std::vector<Move> principal_variation;
    std::uint64_t nodes = 0;
    bool complete = false;
};

/**
 * Exact forward WDL solver with a proven principal-line distance for low-material positions.
 *
 * The solver uses Albay's real move generator, no-progress counter and complete
 * repetition history. It returns complete=true only when the WDL outcome has been proven within
 * the configured limits. distance_is_exact states whether the reported line
 * length is also globally exact. Unknown results must never be
 * treated as draws or wins by callers.
 */
class EndgameSolver {
public:
    [[nodiscard]] EndgameSolveResult solve(
        const Position& root,
        const EndgameSolveOptions& options = {});

private:
    struct MemoKey {
        HashKey position_key = 0;
        HashKey history_fingerprint = 0;
        std::uint16_t no_progress_plies = 0;
        std::uint16_t history_size = 0;

        [[nodiscard]] bool operator==(const MemoKey& other) const noexcept = default;
    };

    struct MemoKeyHash {
        [[nodiscard]] std::size_t operator()(const MemoKey& key) const noexcept;
    };

    struct NodeResult {
        EndgameOutcome outcome = EndgameOutcome::Unknown;
        int distance = 0;
        bool distance_is_exact = false;
        std::optional<Move> best_move;
        std::vector<Move> pv;
        bool complete = false;
    };

    [[nodiscard]] NodeResult solve_node(Position& position, int ply);
    [[nodiscard]] bool control_requested() const;
    [[nodiscard]] static EndgameOutcome terminal_outcome(const Position& position);
    [[nodiscard]] static EndgameOutcome invert(EndgameOutcome outcome) noexcept;

    EndgameSolveOptions options_{};
    std::uint64_t nodes_ = 0;
    bool aborted_ = false;
    std::unordered_map<MemoKey, NodeResult, MemoKeyHash> memo_{};
};

}  // namespace albay
