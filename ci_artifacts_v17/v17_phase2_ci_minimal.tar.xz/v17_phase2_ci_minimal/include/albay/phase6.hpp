/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/quiet_ranking.hpp"
#include "albay/evaluation.hpp"
#include "albay/search.hpp"

#include <iosfwd>
#include <string>
#include <vector>

namespace albay {

struct Phase6RankingCase {
    std::string id;
    std::string split;
    std::string category;
    Position position;
    Move teacher_move{};
    Score teacher_score = 0;
};

struct QuietRankingMetrics {
    std::size_t cases = 0;
    std::size_t top1_matches = 0;
    std::size_t pairwise_correct = 0;
    std::size_t pairwise_total = 0;
    long long margin_sum = 0;

    [[nodiscard]] double top1_rate() const noexcept;
    [[nodiscard]] double pairwise_rate() const noexcept;
};

struct QuietRankingTrainingReport {
    QuietOrderingWeights initial{};
    QuietOrderingWeights trained{};
    QuietRankingMetrics training_before{};
    QuietRankingMetrics training_after{};
    QuietRankingMetrics validation_before{};
    QuietRankingMetrics validation_after{};
    int passes = 0;
    int accepted_changes = 0;
};

[[nodiscard]] bool load_phase6_ranking_dataset(
    std::istream& input,
    std::vector<Phase6RankingCase>& cases,
    std::string* error = nullptr);
[[nodiscard]] bool load_phase6_ranking_dataset_file(
    const std::string& path,
    std::vector<Phase6RankingCase>& cases,
    std::string* error = nullptr);
[[nodiscard]] QuietRankingMetrics evaluate_quiet_ranking(
    const std::vector<Phase6RankingCase>& cases,
    const QuietOrderingWeights& weights);
[[nodiscard]] QuietRankingTrainingReport train_quiet_ranking(
    const std::vector<Phase6RankingCase>& training,
    const std::vector<Phase6RankingCase>& validation,
    QuietOrderingWeights initial = {},
    int passes = 8,
    int initial_step = 16);
void write_quiet_ordering_weights(
    std::ostream& output,
    const QuietOrderingWeights& weights);
[[nodiscard]] bool load_phase6_search_config(
    std::istream& input,
    SearchOptions& options,
    std::string* error = nullptr);
[[nodiscard]] bool load_phase6_search_config_file(
    const std::string& path,
    SearchOptions& options,
    std::string* error = nullptr);

}  // namespace albay
