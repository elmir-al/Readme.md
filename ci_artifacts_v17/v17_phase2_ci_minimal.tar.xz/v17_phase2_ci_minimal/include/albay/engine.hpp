/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/evaluation.hpp"
#include "albay/move.hpp"
#include "albay/position.hpp"
#include "albay/search.hpp"
#include "albay/runtime_policy.hpp"

#include <atomic>
#include <cstdint>
#include <mutex>
#include <optional>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

namespace albay {

class Engine {
public:
    Engine();
    ~Engine();

    Engine(const Engine&) = delete;
    Engine& operator=(const Engine&) = delete;

    void new_game();
    [[nodiscard]] bool set_position(std::string_view text, std::string* error = nullptr);
    [[nodiscard]] std::string get_position() const;
    [[nodiscard]] std::vector<std::string> generate_legal_moves() const;
    [[nodiscard]] bool is_legal_move(std::string_view text) const;
    [[nodiscard]] bool make_move(std::string_view text, std::string* error = nullptr);
    [[nodiscard]] bool undo_move();

    [[nodiscard]] bool start_search(const SearchLimits& limits);
    void stop_search() noexcept;
    void pause_search() noexcept;
    void resume_search() noexcept;
    void wait_for_search() noexcept;

    [[nodiscard]] bool set_option(std::string_view name, std::string_view value, std::string* error = nullptr);
    void update_runtime_environment(const RuntimeEnvironment& environment) noexcept;
    [[nodiscard]] RuntimeEnvironment runtime_environment() const noexcept;
    [[nodiscard]] ThreadPolicyDecision runtime_policy_info() const noexcept;
    [[nodiscard]] SearchOptions options() const;
    [[nodiscard]] SearchInfo search_info() const;
    [[nodiscard]] SearchResult last_result() const;
    [[nodiscard]] std::optional<Move> best_move() const;
    [[nodiscard]] std::vector<Move> principal_variation() const;
    [[nodiscard]] std::vector<PrincipalVariationLine> multipv() const;
    [[nodiscard]] Score evaluate_position() const;
    [[nodiscard]] bool is_searching() const noexcept;
    [[nodiscard]] std::string last_error() const;

private:
    struct PlayedMove {
        Move move{};
        UndoState undo{};
    };

    void stop_and_join() noexcept;
    void set_last_error(std::string message);

    mutable std::mutex position_mutex_;
    Position position_{};
    std::vector<PlayedMove> move_history_{};

    mutable std::mutex options_mutex_;
    SearchOptions options_{};

    mutable std::mutex runtime_mutex_;
    RuntimeEnvironment runtime_environment_{};
    ThreadPolicyDecision runtime_decision_{};
    PerformanceProfile performance_profile_ = PerformanceProfile::Balanced;
    bool automatic_threads_ = true;
    int active_pool_threads_ = 1;

    mutable std::mutex result_mutex_;
    SearchResult last_result_{};
    std::string last_error_{};

    Searcher searcher_{};
    mutable std::mutex worker_mutex_;
    std::jthread worker_{};
    std::atomic<bool> worker_active_{false};
    std::atomic<bool> external_pause_requested_{false};
};

}  // namespace albay
