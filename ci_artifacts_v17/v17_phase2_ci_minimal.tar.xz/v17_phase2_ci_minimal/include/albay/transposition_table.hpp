/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/evaluation.hpp"
#include "albay/move.hpp"
#include "albay/types.hpp"

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

namespace albay {

enum class TTBound : std::uint8_t {
    None = 0,
    Upper,
    Lower,
    Exact,
};

struct TTEntry {
    HashKey key = 0;
    MoveIdentity best_move{};
    Score score = 0;
    std::int16_t depth = -1;
    std::uint8_t generation = 0;
    TTBound bound = TTBound::None;

    [[nodiscard]] bool has_move() const noexcept {
        return best_move.valid();
    }
};

static_assert(sizeof(TTEntry) <= 24, "Albay TT entry must remain cache compact");

struct TTReplacementPolicy {
    bool use_full_capacity_indexing = false;
    bool use_age_aware_replacement = false;
    bool use_depth_preferred_updates = false;
    int age_penalty_per_generation = 8;
    int exact_bound_bonus = 4;
};

struct TTStatistics {
    std::uint64_t probes = 0;
    std::uint64_t hits = 0;
    std::uint64_t cutoffs = 0;
    std::uint64_t stores = 0;
    std::uint16_t hashfull_per_mille = 0;
};

[[nodiscard]] constexpr Score score_to_tt(Score score, int ply) noexcept {
    if (score >= kMateThreshold) {
        return score + ply;
    }
    if (score <= -kMateThreshold) {
        return score - ply;
    }
    return score;
}

[[nodiscard]] constexpr Score score_from_tt(Score score, int ply) noexcept {
    if (score >= kMateThreshold) {
        return score - ply;
    }
    if (score <= -kMateThreshold) {
        return score + ply;
    }
    return score;
}

/**
 * Race-safe shared transposition table.
 *
 * Search threads share clusters. A small striped spin-lock array protects each
 * cluster operation. resize(), clear(), and new_search() must only be called
 * when no search thread is accessing the table.
 */
class TranspositionTable {
public:
    explicit TranspositionTable(std::size_t size_mb = 32);

    void resize(std::size_t size_mb);
    void clear() noexcept;
    void new_search() noexcept;
    void configure(std::size_t size_mb, const TTReplacementPolicy& policy);

    [[nodiscard]] bool probe(HashKey key, TTEntry& entry) const noexcept;
    [[nodiscard]] bool probe_single_thread(HashKey key, TTEntry& entry) const noexcept;
    void store(
        HashKey key,
        int depth,
        Score score,
        TTBound bound,
        const Move* best_move) noexcept;
    void store_single_thread(
        HashKey key,
        int depth,
        Score score,
        TTBound bound,
        const Move* best_move) noexcept;

    [[nodiscard]] std::size_t size_mb() const noexcept { return size_mb_; }
    [[nodiscard]] std::size_t entry_count() const noexcept;
    [[nodiscard]] std::size_t allocated_bytes() const noexcept;
    [[nodiscard]] std::size_t cluster_count() const noexcept { return clusters_.size(); }
    [[nodiscard]] const TTReplacementPolicy& replacement_policy() const noexcept { return policy_; }
    [[nodiscard]] std::uint16_t hashfull_per_mille() const noexcept;
    [[nodiscard]] std::uint8_t generation() const noexcept {
        return generation_.load(std::memory_order_relaxed);
    }

private:
    static constexpr std::size_t kClusterSize = 4;
    static constexpr std::size_t kMaximumLockStripes = 4096;

    struct Cluster {
        std::array<TTEntry, kClusterSize> entries{};
    };

    class SpinLock {
    public:
        void lock() noexcept;
        void unlock() noexcept;

    private:
        std::atomic_flag flag_ = ATOMIC_FLAG_INIT;
    };

    class ScopedLock {
    public:
        explicit ScopedLock(SpinLock& lock) noexcept : lock_(lock) { lock_.lock(); }
        ~ScopedLock() { lock_.unlock(); }
        ScopedLock(const ScopedLock&) = delete;
        ScopedLock& operator=(const ScopedLock&) = delete;

    private:
        SpinLock& lock_;
    };

    [[nodiscard]] std::size_t cluster_index(HashKey key) const noexcept;
    [[nodiscard]] SpinLock& lock_for_cluster(std::size_t cluster_index) const noexcept;
    [[nodiscard]] bool probe_impl(HashKey key, TTEntry& entry, bool take_lock) const noexcept;
    void store_impl(
        HashKey key,
        int depth,
        Score score,
        TTBound bound,
        const Move* best_move,
        bool take_lock) noexcept;

    std::vector<Cluster> clusters_{};
    mutable std::unique_ptr<SpinLock[]> locks_{};
    std::size_t lock_count_ = 0;
    std::size_t mask_ = 0;
    std::size_t size_mb_ = 0;
    std::atomic<std::uint8_t> generation_{1};
    TTReplacementPolicy policy_{};
};

}  // namespace albay
