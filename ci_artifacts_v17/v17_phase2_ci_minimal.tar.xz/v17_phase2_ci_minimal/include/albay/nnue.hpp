/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 38 — incremental NNUE and optimized integer kernels.
*/
#pragma once

#include "albay/evaluation.hpp"
#include "albay/position.hpp"

#include <array>
#include <cstdint>
#include <filesystem>
#include <string>

namespace albay {

inline constexpr std::uint32_t kNnueFormatVersion = 1;
inline constexpr std::uint32_t kNnueInputFeatures = 128;
inline constexpr std::uint32_t kNnueHiddenSize = 64;
inline constexpr std::int32_t kNnueActivationMax = 127;
inline constexpr std::int32_t kNnueOutputScale = 64;
inline constexpr std::uint64_t kNnueFeatureSchema = 0x414C4241594E3334ULL; // "ALBAYN34"
inline constexpr std::size_t kNnueMaximumActiveFeatures = 24;

struct NnueFeatureList {
    std::array<std::uint16_t, kNnueMaximumActiveFeatures> indices{};
    std::uint8_t count = 0;
};

struct NnueFeatureMask {
    std::array<std::uint64_t, 2> words{};

    [[nodiscard]] bool operator==(const NnueFeatureMask&) const noexcept = default;
};


inline constexpr std::size_t kNnueMaximumDeltaFeatures = kMaxCaptureCount + 2U;

struct NnuePerspectiveDelta {
    std::array<std::uint16_t, kNnueMaximumDeltaFeatures> removed{};
    std::array<std::uint16_t, kNnueMaximumDeltaFeatures> added{};
    std::uint8_t removed_count = 0;
    std::uint8_t added_count = 0;
};

struct NnueFeatureDelta {
    std::array<NnuePerspectiveDelta, 2> perspectives{};
};

struct NnueModelMetadata {
    std::uint32_t format_version = kNnueFormatVersion;
    std::uint32_t input_features = kNnueInputFeatures;
    std::uint32_t hidden_size = kNnueHiddenSize;
    std::int32_t activation_max = kNnueActivationMax;
    std::int32_t output_scale = kNnueOutputScale;
    std::uint64_t feature_schema = kNnueFeatureSchema;
    std::uint64_t payload_checksum = 0;
};

class NnueModel {
public:
    [[nodiscard]] static NnueModel zero_model();
    [[nodiscard]] static NnueModel deterministic_fixture(std::uint64_t seed);
    [[nodiscard]] static NnueModel from_parameters(
        const std::array<std::int32_t, kNnueHiddenSize>& hidden_bias,
        const std::array<std::int16_t, kNnueInputFeatures * kNnueHiddenSize>& input_weights,
        const std::array<std::int16_t, kNnueHiddenSize>& output_weights,
        std::int32_t output_bias);

    [[nodiscard]] bool load(const std::filesystem::path& path, std::string* error = nullptr);
    [[nodiscard]] bool save(const std::filesystem::path& path, std::string* error = nullptr) const;
    [[nodiscard]] bool validate(std::string* error = nullptr) const;

    [[nodiscard]] const NnueModelMetadata& metadata() const noexcept { return metadata_; }
    [[nodiscard]] std::uint64_t payload_checksum() const;
    [[nodiscard]] const auto& hidden_bias() const noexcept { return hidden_bias_; }
    [[nodiscard]] const auto& input_weights() const noexcept { return input_weights_; }
    [[nodiscard]] const auto& output_weights() const noexcept { return output_weights_; }
    [[nodiscard]] std::int32_t output_bias() const noexcept { return output_bias_; }

private:
    friend class NnueAccumulator;

    NnueModelMetadata metadata_{};
    std::array<std::int32_t, kNnueHiddenSize> hidden_bias_{};
    std::array<std::int16_t, kNnueInputFeatures * kNnueHiddenSize> input_weights_{};
    std::array<std::int16_t, kNnueHiddenSize> output_weights_{};
    std::int32_t output_bias_ = 0;
};

[[nodiscard]] NnueFeatureMask nnue_feature_mask(
    const Position& position,
    Color perspective) noexcept;
[[nodiscard]] NnueFeatureList nnue_active_features(
    const Position& position,
    Color perspective) noexcept;
[[nodiscard]] NnueFeatureDelta nnue_move_delta(
    Color mover,
    Bitboard parent_kings,
    const Move& move) noexcept;
[[nodiscard]] NnueFeatureDelta nnue_move_delta(
    const Position& before,
    const Move& move) noexcept;

enum class NnueKernel : std::uint8_t {
    Scalar = 0,
    ArmNeon = 1,
};

[[nodiscard]] NnueKernel nnue_active_kernel() noexcept;
[[nodiscard]] const char* nnue_kernel_name(NnueKernel kernel) noexcept;

class NnueAccumulator {
public:
    void refresh(const Position& position, const NnueModel& model) noexcept;
    void update(
        const Position& before,
        const Position& after,
        const NnueModel& model) noexcept;
    // Fast search-tree update. The accumulator is assumed to represent the
    // parent position; only the child feature mask is computed.
    void update_to(const Position& after, const NnueModel& model) noexcept;
    void apply_delta(const NnueFeatureDelta& delta, const NnueModel& model) noexcept;

    [[nodiscard]] bool valid_for(const Position& position, const NnueModel& model) const noexcept;
    [[nodiscard]] Score evaluate(const Position& position, const NnueModel& model) const noexcept;
    // Search hot path: the caller already maintained and validated this
    // accumulator for the current ply. Model identity is still checked.
    [[nodiscard]] Score evaluate_assuming_valid(
        const Position& position, const NnueModel& model) const noexcept;
    [[nodiscard]] const std::array<std::int32_t, kNnueHiddenSize>& values(
        Color perspective) const noexcept;

private:
    std::array<std::array<std::int32_t, kNnueHiddenSize>, 2> accumulators_{};
    std::array<NnueFeatureMask, 2> masks_{};
    std::uint64_t model_checksum_ = 0;
    bool initialized_ = false;
};

[[nodiscard]] Score evaluate_nnue(const Position& position, const NnueModel& model) noexcept;

}  // namespace albay
