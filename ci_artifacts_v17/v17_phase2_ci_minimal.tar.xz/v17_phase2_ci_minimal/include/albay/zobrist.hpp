/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/types.hpp"

#include <array>

namespace albay::zobrist {

struct Tables {
    std::array<std::array<std::array<HashKey, kBoardSquares>, 2>, 2> piece{};
    HashKey side_to_move = 0;
};

[[nodiscard]] constexpr HashKey splitmix64(HashKey& state) noexcept {
    state += 0x9E3779B97F4A7C15ULL;
    HashKey value = state;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

[[nodiscard]] constexpr Tables create_tables() noexcept {
    Tables result{};
    HashKey state = 0x414C4241595F3230ULL;  // "ALBAY_20"
    for (auto& color : result.piece) {
        for (auto& type : color) {
            for (HashKey& key : type) {
                key = splitmix64(state);
            }
        }
    }
    result.side_to_move = splitmix64(state);
    return result;
}

inline constexpr Tables kTables = create_tables();

[[nodiscard]] constexpr const Tables& tables() noexcept {
    return kTables;
}

}  // namespace albay::zobrist
