/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 38 — incremental NNUE runtime with safe HCE fallback.
*/
#pragma once

#include "albay/evaluation.hpp"
#include "albay/nnue.hpp"

#include <memory>
#include <string>

namespace albay {

struct NnueRuntimeOptions {
    bool enabled = false;
    int blend_percent = 100; // 0 = HCE, 100 = pure NNUE.
    std::shared_ptr<const NnueModel> model{};
    std::string model_path{};
};

struct NnueRuntimeEvaluation {
    Score score = 0;
    Score hce_score = 0;
    Score nnue_score = 0;
    bool used_nnue = false;
    bool used_fallback = false;
};

[[nodiscard]] bool load_nnue_runtime_model(
    const std::string& path,
    std::shared_ptr<const NnueModel>& output,
    std::string* error = nullptr);

[[nodiscard]] NnueRuntimeEvaluation evaluate_with_nnue_fallback(
    const Position& position,
    Score hce_score,
    const NnueRuntimeOptions& options,
    const NnueAccumulator* accumulator = nullptr) noexcept;

}  // namespace albay
