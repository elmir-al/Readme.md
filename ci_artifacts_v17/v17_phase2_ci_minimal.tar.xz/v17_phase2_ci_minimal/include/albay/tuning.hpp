/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/evaluation.hpp"

#include <iosfwd>
#include <string>
#include <vector>

namespace albay {

struct TuningSample {
    Position position;
    double white_result = 0.5; // 1.0 white win, 0.5 draw, 0.0 black win
};

struct TuningReport {
    EvaluationWeights weights{};
    double initial_loss = 0.0;
    double final_loss = 0.0;
    int passes_completed = 0;
    int accepted_changes = 0;
};

[[nodiscard]] bool load_tuning_dataset(
    std::istream& input,
    std::vector<TuningSample>& samples,
    std::string* error = nullptr);
[[nodiscard]] bool load_tuning_dataset_file(
    const std::string& path,
    std::vector<TuningSample>& samples,
    std::string* error = nullptr);
[[nodiscard]] bool load_weights(
    std::istream& input,
    EvaluationWeights& weights,
    std::string* error = nullptr);
[[nodiscard]] bool load_weights_file(
    const std::string& path,
    EvaluationWeights& weights,
    std::string* error = nullptr);
[[nodiscard]] double tuning_loss(
    const std::vector<TuningSample>& samples,
    const EvaluationWeights& weights,
    double score_scale = 400.0);
[[nodiscard]] TuningReport coordinate_tune(
    const std::vector<TuningSample>& training_samples,
    EvaluationWeights initial = {},
    int passes = 4,
    int initial_step = 12,
    double score_scale = 400.0);
void write_weights(std::ostream& output, const EvaluationWeights& weights);

}  // namespace albay
