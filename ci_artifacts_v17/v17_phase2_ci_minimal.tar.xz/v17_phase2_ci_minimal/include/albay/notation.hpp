/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/move.hpp"
#include "albay/position.hpp"

#include <optional>
#include <string>
#include <string_view>

namespace albay {

[[nodiscard]] std::string move_to_string(const Move& move);
[[nodiscard]] std::optional<Move> parse_legal_move(const Position& position, std::string_view text);
[[nodiscard]] std::string position_to_ascii(const Position& position);
[[nodiscard]] std::string position_to_apf(const Position& position);
[[nodiscard]] std::optional<Position> parse_apf(std::string_view text, std::string* error = nullptr);

}  // namespace albay
