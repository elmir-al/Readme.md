/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/endgame_solver.hpp"
#include "albay/position.hpp"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <vector>

namespace albay {

inline constexpr std::uint32_t kExactTablebaseFormatVersion = 2;
inline constexpr std::uint8_t kTablebaseInvalidEntry = 0xFFU;

struct ExactTablebaseProbe {
    EndgameOutcome outcome = EndgameOutcome::Unknown;
    std::uint16_t distance_to_terminal = 0;
    std::optional<Move> best_move;
    bool exact = false;
    bool draw_rule_safe = false;
};

struct ExactTablebaseVerification {
    std::uint64_t legal_states = 0;
    std::uint64_t checked_edges = 0;
    std::uint64_t invalid_state_errors = 0;
    std::uint64_t outcome_errors = 0;
    std::uint64_t distance_errors = 0;
    std::uint64_t best_move_errors = 0;
    bool complete = false;
};

struct ExactTablebaseStatistics {
    int maximum_pieces = 0;
    std::uint64_t dense_states = 0;
    std::uint64_t legal_states = 0;
    std::uint64_t wins = 0;
    std::uint64_t draws = 0;
    std::uint64_t losses = 0;
    std::uint64_t payload_checksum = 0;
};

/**
 * Dense, read-only WDL/DTW tablebase for Russian draughts positions.
 *
 * The file stores every dense state up to maximum_pieces. Invalid states are
 * marked explicitly. WDL is solved without repetition history. Decisive probes
 * are exposed to search only when the stored distance is safe under Albay's
 * 30-ply no-progress rule; otherwise callers must fall back to the exact
 * history-aware forward solver.
 */
class ExactEndgameTablebase {
public:
    [[nodiscard]] bool load(const std::filesystem::path& path, std::string* error = nullptr);
    void clear() noexcept;

    [[nodiscard]] bool loaded() const noexcept { return !entries_.empty(); }
    [[nodiscard]] const ExactTablebaseStatistics& statistics() const noexcept { return statistics_; }
    [[nodiscard]] const std::filesystem::path& path() const noexcept { return path_; }

    [[nodiscard]] ExactTablebaseProbe probe(const Position& position) const;
    [[nodiscard]] ExactTablebaseVerification verify() const;
    [[nodiscard]] std::optional<std::uint64_t> dense_index(const Position& position) const noexcept;

    [[nodiscard]] static std::uint64_t dense_state_count(int maximum_pieces) noexcept;

private:
    [[nodiscard]] ExactTablebaseProbe probe_index(
        const Position& position,
        std::uint64_t index,
        bool include_best_move) const;

    std::filesystem::path path_{};
    ExactTablebaseStatistics statistics_{};
    std::vector<std::uint8_t> entries_{};
};

struct ExactTablebaseBuildOptions {
    int maximum_pieces = 3;
    std::filesystem::path output_path{};
    std::uint64_t maximum_edges = 0;
    bool verify_after_write = true;
};

struct ExactTablebaseBuildResult {
    ExactTablebaseStatistics statistics{};
    std::uint64_t edges = 0;
    std::uint64_t terminal_states = 0;
    std::uint64_t retrograde_updates = 0;
    double enumeration_seconds = 0.0;
    double retrograde_seconds = 0.0;
    double write_seconds = 0.0;
    bool complete = false;
    std::string error{};
};

[[nodiscard]] ExactTablebaseBuildResult build_exact_tablebase(
    const ExactTablebaseBuildOptions& options);

}  // namespace albay
