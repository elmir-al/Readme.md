/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 35 — NNUE dataset and training infrastructure.
*/
#pragma once

#include "albay/hce_dataset.hpp"
#include "albay/nnue.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace albay {

inline constexpr std::uint32_t kNnueDatasetFormatVersion = 1;
inline constexpr std::uint32_t kNnueDatasetHeaderBytes = 256;
inline constexpr std::uint32_t kNnueDatasetRecordBytes = 48;
inline constexpr std::int16_t kNnueUnknownTargetScore = static_cast<std::int16_t>(-32768);

enum NnueDatasetRecordFlag : std::uint16_t {
    NnueDatasetTargetScoreKnown = 1U << 0U,
    NnueDatasetGameResultKnown = 1U << 1U,
    NnueDatasetQuietPosition = 1U << 2U,
    NnueDatasetExactTeacher = 1U << 3U,
    NnueDatasetExternalTeacher = 1U << 4U,
    NnueDatasetSymmetryDerived = 1U << 5U,
};

struct NnueDatasetRecord {
    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    std::uint64_t group_id = 0;
    std::int16_t target_score_stm = kNnueUnknownTargetScore;
    std::uint16_t ply = 0;
    std::uint16_t no_progress_plies = 0;
    std::uint16_t flags = 0;
    Color side_to_move = Color::White;
    HcePhase phase = HcePhase::Opening;
    HceSplit split = HceSplit::Train;
    HceSource source = HceSource::Trajectory;
    std::int8_t game_result_stm = 2;  // -1 loss, 0 draw, 1 win, 2 unknown.
    std::uint8_t teacher_depth = 0;
    std::uint16_t reserved = 0;
};

struct NnueDatasetHeader {
    std::uint32_t format_version = kNnueDatasetFormatVersion;
    std::uint32_t header_bytes = kNnueDatasetHeaderBytes;
    std::uint32_t record_bytes = kNnueDatasetRecordBytes;
    std::uint32_t input_features = kNnueInputFeatures;
    std::uint32_t hidden_size = kNnueHiddenSize;
    std::uint64_t feature_schema = kNnueFeatureSchema;
    std::uint64_t record_count = 0;
    std::uint64_t seed = 0;
    std::uint64_t payload_fnv1a64 = 1469598103934665603ULL;
    std::array<std::uint64_t, static_cast<std::size_t>(HcePhase::Count)> phase_counts{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSplit::Count)> split_counts{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSource::Count)> source_counts{};
    std::uint64_t known_score_count = 0;
    std::uint64_t known_result_count = 0;
    std::uint64_t unique_group_count = 0;
};

struct Phase35ExportOptions {
    int maximum_absolute_teacher_score = 2400;
    std::uint8_t minimum_teacher_depth = 0;
    bool require_legal = true;
    bool require_any_label = true;
    bool require_quiet = false;
    std::size_t maximum_records = 0;
};

struct Phase35ExportReport {
    std::uint64_t input_records = 0;
    std::uint64_t accepted_records = 0;
    std::uint64_t rejected_missing_label = 0;
    std::uint64_t rejected_flags = 0;
    std::uint64_t rejected_depth = 0;
    std::uint64_t rejected_score = 0;
    std::array<std::uint64_t, static_cast<std::size_t>(HceSplit::Count)> split_counts{};
};

struct Phase35LossMetrics {
    std::uint64_t samples = 0;
    double mean_squared_error = 0.0;
    double mean_absolute_error_cp = 0.0;
    double root_mean_squared_error_cp = 0.0;
    double sign_accuracy = 0.0;
};

struct Phase35TrainOptions {
    int epochs = 6;
    std::size_t batch_size = 64;
    double learning_rate_output = 0.003;
    double learning_rate_hidden = 0.0002;
    double l2 = 1.0e-6;
    double score_scale = 400.0;
    double gradient_clip = 4.0;
    std::size_t maximum_training_samples = 0;
    std::uint64_t seed = 0xA1BA3535ULL;
};

struct Phase35TrainReport {
    Phase35LossMetrics train_before{};
    Phase35LossMetrics validation_before{};
    Phase35LossMetrics holdout_before{};
    Phase35LossMetrics train_after{};
    Phase35LossMetrics validation_after{};
    Phase35LossMetrics holdout_after{};
    int epochs_completed = 0;
    int best_epoch = 0;
    bool validation_improved = false;
    std::uint64_t dataset_checksum = 0;
    std::uint64_t model_checksum = 0;
};

[[nodiscard]] Position nnue_dataset_position(const NnueDatasetRecord& record);
[[nodiscard]] NnueDatasetRecord make_nnue_dataset_record(const HceRecord& record);
[[nodiscard]] bool phase35_export_hce_records(
    const std::vector<HceRecord>& input,
    const Phase35ExportOptions& options,
    std::vector<NnueDatasetRecord>& output,
    Phase35ExportReport& report,
    std::string* error = nullptr);

[[nodiscard]] bool write_nnue_dataset(
    const std::filesystem::path& path,
    const std::vector<NnueDatasetRecord>& records,
    std::uint64_t seed,
    NnueDatasetHeader* written_header = nullptr,
    std::string* error = nullptr);
[[nodiscard]] bool read_nnue_dataset(
    const std::filesystem::path& path,
    NnueDatasetHeader& header,
    std::vector<NnueDatasetRecord>& records,
    std::string* error = nullptr);
[[nodiscard]] bool inspect_nnue_dataset(
    const std::filesystem::path& path,
    NnueDatasetHeader& header,
    std::string* error = nullptr);
[[nodiscard]] bool validate_nnue_dataset(
    const NnueDatasetHeader& header,
    const std::vector<NnueDatasetRecord>& records,
    std::string* error = nullptr);

[[nodiscard]] Phase35LossMetrics phase35_model_metrics(
    const std::vector<NnueDatasetRecord>& records,
    HceSplit split,
    const NnueModel& model,
    double score_scale = 400.0,
    std::size_t maximum_samples = 0);
[[nodiscard]] bool phase35_train_nnue(
    const NnueDatasetHeader& header,
    const std::vector<NnueDatasetRecord>& records,
    const Phase35TrainOptions& options,
    NnueModel& output_model,
    Phase35TrainReport& report,
    const std::filesystem::path& checkpoint_prefix = {},
    std::string* error = nullptr);
void write_phase35_json_report(
    const std::filesystem::path& path,
    const Phase35ExportReport* export_report,
    const Phase35TrainReport* train_report);

}  // namespace albay
