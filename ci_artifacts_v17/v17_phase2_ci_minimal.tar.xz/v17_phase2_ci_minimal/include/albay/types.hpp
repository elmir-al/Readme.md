/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include <cstdint>
#include <string_view>

namespace albay {

using Bitboard = std::uint32_t;
using HashKey = std::uint64_t;
using Square = std::uint8_t;

inline constexpr Square kNoSquare = 0xFF;
inline constexpr int kBoardSquares = 32;
inline constexpr int kMaxCaptureCount = 12;
inline constexpr int kMaxMoves = 512;
inline constexpr int kMaxHistoryPly = 2048;

inline constexpr std::string_view kEngineName = "Albay Russian Draughts Engine";
inline constexpr std::string_view kEngineAuthor = "Elmir Hajizada";
inline constexpr std::string_view kEngineVersion = "1.0.45";

enum class Color : std::uint8_t {
    White = 0,
    Black = 1,
};

[[nodiscard]] constexpr Color opposite(Color color) noexcept {
    return color == Color::White ? Color::Black : Color::White;
}

[[nodiscard]] constexpr Bitboard bit(Square square) noexcept {
    return Bitboard{1U} << square;
}

[[nodiscard]] constexpr bool is_valid_square(Square square) noexcept {
    return square < kBoardSquares;
}

}  // namespace albay
