/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/evaluation.hpp"
#include "albay/search.hpp"

#include <iosfwd>
#include <string>
#include <vector>

namespace albay {

enum class DiagnosticPhase {
    Opening,
    Middlegame,
    ManEndgame,
    KingEndgame,
};

struct PositionFeatureSummary {
    DiagnosticPhase phase = DiagnosticPhase::Opening;
    int total_pieces = 0;
    int total_kings = 0;
    int legal_moves = 0;
    bool mandatory_capture = false;
    int white_men = 0;
    int black_men = 0;
    int white_kings = 0;
    int black_kings = 0;
    int white_isolated_men = 0;
    int black_isolated_men = 0;
    int white_blocked_men = 0;
    int black_blocked_men = 0;
    int white_supported_men = 0;
    int black_supported_men = 0;
    int white_promotion_lanes = 0;
    int black_promotion_lanes = 0;
    int white_king_mobility = 0;
    int black_king_mobility = 0;
    EvaluationBreakdown evaluation{};
};

struct DiagnosticCase {
    std::string id;
    std::string category;
    std::string recorded_classification;
    std::string game_label;
    std::string baseline_shallow_move;
    Score baseline_shallow_score = 0;
    std::string baseline_deep_move;
    Score baseline_deep_score = 0;
    std::string external_reference_move;
    Score external_reference_score = 0;
    std::string apf;
};

struct DiagnosticCaseResult {
    std::string id;
    std::string category;
    std::string recorded_classification;
    std::string current_classification;
    std::string shallow_move;
    Score shallow_score = 0;
    std::uint64_t shallow_nodes = 0;
    std::string deep_move;
    Score deep_score = 0;
    std::uint64_t deep_nodes = 0;
    bool shallow_matches_deep = false;
    bool deep_matches_baseline = false;
    bool deep_matches_external = false;
    bool legal = false;
    PositionFeatureSummary features{};
};

struct DiagnosticSummary {
    std::size_t total = 0;
    std::size_t legal = 0;
    std::size_t shallow_deep_agreement = 0;
    std::size_t deep_baseline_agreement = 0;
    std::size_t deep_external_agreement = 0;
    std::size_t horizon_errors = 0;
    std::size_t depth_unstable = 0;
    std::size_t external_disagreements = 0;
};

[[nodiscard]] PositionFeatureSummary extract_position_features(const Position& position);
[[nodiscard]] std::string_view diagnostic_phase_name(DiagnosticPhase phase) noexcept;
[[nodiscard]] bool load_diagnostic_suite(
    std::istream& input,
    std::vector<DiagnosticCase>& cases,
    std::string* error = nullptr);
[[nodiscard]] bool load_diagnostic_suite_file(
    const std::string& path,
    std::vector<DiagnosticCase>& cases,
    std::string* error = nullptr);
[[nodiscard]] DiagnosticCaseResult run_diagnostic_case(
    const DiagnosticCase& diagnostic_case,
    int shallow_depth = 6,
    int deep_depth = 10,
    const SearchOptions& options = {});
[[nodiscard]] DiagnosticSummary summarize_diagnostics(
    const std::vector<DiagnosticCaseResult>& results) noexcept;

}  // namespace albay
