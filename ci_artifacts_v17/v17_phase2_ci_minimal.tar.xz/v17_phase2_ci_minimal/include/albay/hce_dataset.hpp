/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/position.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <iosfwd>
#include <string>
#include <vector>

namespace albay {

inline constexpr std::uint32_t kHceDatasetFormatVersion = 1;
inline constexpr std::uint32_t kHceDatasetRecordBytes = 36;
inline constexpr std::uint32_t kHceDatasetHeaderBytes = 192;
inline constexpr std::int16_t kHceUnknownTeacherScore = static_cast<std::int16_t>(-32768);

enum class HcePhase : std::uint8_t {
    Opening = 0,
    Middlegame = 1,
    ManEndgame = 2,
    KingEndgame = 3,
    Count = 4,
};

enum class HceSplit : std::uint8_t {
    Train = 0,
    Validation = 1,
    Holdout = 2,
    Count = 3,
};

enum class HceSource : std::uint8_t {
    Trajectory = 0,
    SyntheticManEndgame = 1,
    SyntheticKingEndgame = 2,
    ExternalTeacher = 3,
    ExactEndgame = 4,
    ImportedGame = 5,
    Count = 6,
};

enum HceRecordFlag : std::uint16_t {
    HceQuietPosition = 1U << 0U,
    HceLegalPosition = 1U << 1U,
    HceNonForcedPosition = 1U << 2U,
    HceSyntheticPosition = 1U << 3U,
    HceExternalTeacherMove = 1U << 4U,
    HceGameResultKnown = 1U << 5U,
    HceMirroredCanonical = 1U << 6U,
    HceTeacherScoreKnown = 1U << 7U,
    HceStableQuietCandidate = 1U << 8U,
    HceSymmetryDerivedTeacher = 1U << 9U,
};

struct HceRecord {
    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    std::uint64_t group_id = 0;
    std::int16_t teacher_score_white = kHceUnknownTeacherScore;
    std::uint16_t ply = 0;
    std::uint16_t no_progress_plies = 0;
    std::uint16_t flags = 0;
    Color side_to_move = Color::White;
    HcePhase phase = HcePhase::Opening;
    HceSplit split = HceSplit::Train;
    HceSource source = HceSource::Trajectory;
    std::int8_t game_result_white = 2;  // -1 black win, 0 draw, 1 white win, 2 unknown.
    std::uint8_t teacher_depth = 0;
    std::uint16_t reserved = 0;
};

struct HceDatasetHeader {
    std::uint32_t format_version = kHceDatasetFormatVersion;
    std::uint32_t header_bytes = kHceDatasetHeaderBytes;
    std::uint32_t record_bytes = kHceDatasetRecordBytes;
    std::uint64_t record_count = 0;
    std::uint64_t seed = 0;
    std::uint64_t payload_fnv1a64 = 1469598103934665603ULL;
    std::array<std::uint64_t, static_cast<std::size_t>(HcePhase::Count)> phase_counts{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSplit::Count)> split_counts{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSource::Count)> source_counts{};
    std::uint64_t known_result_count = 0;
    std::uint64_t known_teacher_score_count = 0;
    std::uint64_t unique_group_count = 0;
};

struct HceCanonicalPosition {
    Bitboard white = 0;
    Bitboard black = 0;
    Bitboard kings = 0;
    Color side_to_move = Color::White;
    bool mirrored = false;
};

[[nodiscard]] HcePhase classify_hce_phase(const Position& position) noexcept;
[[nodiscard]] HceSplit hce_split_for_group(std::uint64_t group_id, std::uint64_t seed) noexcept;
[[nodiscard]] HceCanonicalPosition canonicalize_hce_position(const Position& position) noexcept;
[[nodiscard]] Position color_swap_rotate_hce_position(const Position& position);
[[nodiscard]] Position hce_record_position(const HceRecord& record);
[[nodiscard]] HceRecord make_hce_record(
    const Position& position,
    std::uint64_t group_id,
    std::uint16_t ply,
    HceSource source,
    HceSplit split,
    std::int8_t game_result_white = 2,
    std::uint16_t extra_flags = 0);

[[nodiscard]] std::string_view hce_phase_name(HcePhase phase) noexcept;
[[nodiscard]] std::string_view hce_split_name(HceSplit split) noexcept;
[[nodiscard]] std::string_view hce_source_name(HceSource source) noexcept;

[[nodiscard]] bool write_hce_dataset(
    const std::string& path,
    const std::vector<HceRecord>& records,
    std::uint64_t seed,
    HceDatasetHeader* written_header = nullptr,
    std::string* error = nullptr);
[[nodiscard]] bool read_hce_dataset(
    const std::string& path,
    HceDatasetHeader& header,
    std::vector<HceRecord>& records,
    std::string* error = nullptr);
[[nodiscard]] bool inspect_hce_dataset(
    const std::string& path,
    HceDatasetHeader& header,
    std::string* error = nullptr);
[[nodiscard]] bool validate_hce_dataset(
    const HceDatasetHeader& header,
    const std::vector<HceRecord>& records,
    std::string* error = nullptr);

}  // namespace albay
