/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

Strength Phase 36 — stable NNUE teacher corpus and real training audit.
*/
#pragma once

#include "albay/hce_dataset.hpp"
#include "albay/nnue_training.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace albay {

struct Phase36TeacherOptions {
    int shallow_depth = 5;
    int deep_depth = 7;
    int maximum_score_drift = 320;
    int draw_band = 80;
    int maximum_absolute_score = 2400;
    std::size_t maximum_input_records = 0;
    int workers = 1;
    bool require_best_move_match = true;
    bool augment_color_symmetry = true;
    bool require_quiet = true;
    std::filesystem::path exact_tablebase_path{};
};

struct Phase36TeacherReport {
    std::uint64_t input_records = 0;
    std::uint64_t selected_records = 0;
    std::uint64_t accepted_primary = 0;
    std::uint64_t accepted_symmetry = 0;
    std::uint64_t rejected_illegal = 0;
    std::uint64_t rejected_forced_or_tactical = 0;
    std::uint64_t rejected_search = 0;
    std::uint64_t rejected_score_drift = 0;
    std::uint64_t rejected_score_sign = 0;
    std::uint64_t rejected_best_move = 0;
    std::uint64_t duplicate_rejections = 0;
    std::uint64_t shallow_nodes = 0;
    std::uint64_t deep_nodes = 0;
    std::uint64_t tablebase_hits = 0;
    std::uint64_t exact_teacher_records = 0;
    std::uint64_t unique_groups = 0;
    std::array<std::uint64_t, static_cast<std::size_t>(HcePhase::Count)> phase_counts{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSplit::Count)> split_counts{};
    double seconds = 0.0;
};

struct Phase36AuditReport {
    Phase35LossMetrics validation_zero{};
    Phase35LossMetrics validation_model{};
    Phase35LossMetrics holdout_zero{};
    Phase35LossMetrics holdout_model{};
    std::array<Phase35LossMetrics, static_cast<std::size_t>(HcePhase::Count)> holdout_by_phase{};
    Phase35LossMetrics holdout_exact{};
    double validation_mse_improvement_percent = 0.0;
    double holdout_mse_improvement_percent = 0.0;
    bool validation_improved = false;
    bool holdout_improved = false;
    bool research_gate_passed = false;
    bool production_accepted = false;
};

[[nodiscard]] bool phase36_build_teacher_corpus(
    const std::vector<HceRecord>& input,
    const Phase36TeacherOptions& options,
    std::vector<NnueDatasetRecord>& output,
    Phase36TeacherReport& report,
    std::string* error = nullptr);

[[nodiscard]] Phase36AuditReport phase36_audit_model(
    const std::vector<NnueDatasetRecord>& records,
    const NnueModel& model,
    double score_scale = 400.0);

void write_phase36_teacher_report(
    const std::filesystem::path& path,
    const Phase36TeacherOptions& options,
    const Phase36TeacherReport& report,
    const NnueDatasetHeader* dataset_header = nullptr);

void write_phase36_audit_report(
    const std::filesystem::path& path,
    const Phase36AuditReport& report,
    std::uint64_t dataset_checksum,
    std::uint64_t model_checksum);

}  // namespace albay
