/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/position.hpp"

namespace albay {

using Score = int;

inline constexpr Score kDrawScore = 0;
inline constexpr Score kMateScore = 30000;
inline constexpr Score kMateThreshold = 29000;
inline constexpr Score kInfiniteScore = 32000;

struct EvaluationWeights {
    int material = 100;
    int center = 100;
    int advancement = 100;
    int promotion_potential = 100;
    int back_rank = 100;
    int mobility = 100;
    int king_activity = 100;
    int restriction = 100;
    int tactical_pressure = 100;
    int phase_adjustment = 100;
    int structure = 0;
    int support_structure = 0;
    int isolation = 0;
    int promotion_lanes = 0;
    int edge_passivity = 0;
    int phase_adjustment_repeat = 0; // Optional experimental repeat; 0 preserves Albay 1.0.5 behavior.
    int opening_center_scale = 100;
    int opening_back_rank_scale = 100;
    int middlegame_structure_scale = 100;
    int endgame_king_scale = 100;
    int endgame_mobility_scale = 100;
    int endgame_restriction_scale = 100;
    int endgame_promotion_scale = 100;
    int king_confinement = 0;
    int promotion_race = 0;
    int wing_balance = 0;
    int rear_support = 0;
    int advanced_exposure = 0;
    int diagonal_control = 0;
    int reserve_tempo = 0;
    int space_pressure = 0;
    int strategic_pst = 0;
    int strategic_min_pieces = 0;
    int strategic_max_pieces = 24;
    int strategic_max_kings = 24;
};

struct EvaluationPhaseMix {
    int opening = 0;
    int middlegame = 100;
    int endgame = 0;
};

struct EvaluationBreakdown {
    Score material = 0;
    Score center = 0;
    Score advancement = 0;
    Score promotion_potential = 0;
    Score back_rank = 0;
    Score mobility = 0;
    Score king_activity = 0;
    Score restriction = 0;
    Score tactical_pressure = 0;
    Score phase_adjustment = 0;
    Score structure = 0;
    Score support_structure = 0;
    Score isolation = 0;
    Score promotion_lanes = 0;
    Score edge_passivity = 0;
    Score king_confinement = 0;
    Score promotion_race = 0;
    Score wing_balance = 0;
    Score rear_support = 0;
    Score advanced_exposure = 0;
    Score diagonal_control = 0;
    Score reserve_tempo = 0;
    Score space_pressure = 0;
    Score strategic_pst = 0;
    Score total_white_perspective = 0;
};

[[nodiscard]] EvaluationBreakdown evaluate_breakdown(
    const Position& position,
    bool include_structure = true,
    bool include_phase5_features = true,
    bool include_phase9_features = true);
[[nodiscard]] EvaluationPhaseMix evaluation_phase_mix(const Position& position) noexcept;
[[nodiscard]] Score weighted_total(
    const EvaluationBreakdown& breakdown,
    const EvaluationWeights& weights = {}) noexcept;
[[nodiscard]] Score weighted_total_for_position(
    const Position& position,
    const EvaluationBreakdown& breakdown,
    const EvaluationWeights& weights = {}) noexcept;
[[nodiscard]] Score evaluate_white_perspective(
    const Position& position,
    const EvaluationWeights& weights = {});
[[nodiscard]] Score evaluate_default(const Position& position) noexcept;
[[nodiscard]] Score evaluate(
    const Position& position,
    const EvaluationWeights& weights = {});

}  // namespace albay
