/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/evaluation.hpp"
#include "albay/hce_dataset.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace albay {

inline constexpr std::size_t kPhase30FeatureCount = 10;

struct Phase30FilterOptions {
    int maximum_absolute_teacher_score = 1800;
    int maximum_static_residual = 1100;
    int neutral_teacher_band = 100;
    int maximum_no_progress_plies = 40;
    std::uint8_t minimum_teacher_depth = 5;
    bool require_quiet = true;
    bool require_non_forced = true;
    bool require_sign_agreement = true;
};

struct Phase30FilterReport {
    std::uint64_t input_records = 0;
    std::uint64_t accepted_records = 0;
    std::uint64_t rejected_missing_teacher = 0;
    std::uint64_t rejected_flags = 0;
    std::uint64_t rejected_depth = 0;
    std::uint64_t rejected_score = 0;
    std::uint64_t rejected_residual = 0;
    std::uint64_t rejected_sign = 0;
    std::uint64_t rejected_no_progress = 0;
    std::array<std::uint64_t, static_cast<std::size_t>(HcePhase::Count)> phase_counts{};
    std::array<std::uint64_t, static_cast<std::size_t>(HceSplit::Count)> split_counts{};
};

struct Phase30FeatureSample {
    std::array<std::int16_t, kPhase30FeatureCount> features{};
    std::int16_t teacher_score_white = 0;
    HceSplit split = HceSplit::Train;
    HcePhase phase = HcePhase::Opening;
    std::uint64_t group_id = 0;
};

struct Phase30LossMetrics {
    std::uint64_t samples = 0;
    double cross_entropy = 0.0;
    double mean_absolute_error = 0.0;
    double root_mean_square_error = 0.0;
    double sign_accuracy = 0.0;
};

struct Phase30TuneOptions {
    int passes = 4;
    int initial_step = 12;
    int minimum_weight = 55;
    int maximum_weight = 145;
    double score_scale = 400.0;
    std::size_t maximum_training_samples = 300000;
    double validation_epsilon = 1.0e-9;
};

struct Phase30TuneReport {
    EvaluationWeights baseline{};
    EvaluationWeights candidate{};
    Phase30LossMetrics train_before{};
    Phase30LossMetrics train_after{};
    Phase30LossMetrics validation_before{};
    Phase30LossMetrics validation_after{};
    Phase30LossMetrics holdout_before{};
    Phase30LossMetrics holdout_after{};
    int passes_completed = 0;
    int accepted_changes = 0;
};

[[nodiscard]] std::array<std::int16_t, kPhase30FeatureCount> phase30_extract_features(
    const Position& position);
[[nodiscard]] int phase30_model_score(
    const std::array<std::int16_t, kPhase30FeatureCount>& features,
    const EvaluationWeights& weights) noexcept;
[[nodiscard]] bool phase30_record_is_stable(
    const HceRecord& record,
    const Phase30FilterOptions& options,
    int* static_score_white = nullptr,
    std::string* reason = nullptr);
[[nodiscard]] bool phase30_filter_dataset(
    const std::vector<HceRecord>& input,
    const Phase30FilterOptions& options,
    std::vector<HceRecord>& output,
    Phase30FilterReport& report,
    std::string* error = nullptr);
[[nodiscard]] std::vector<Phase30FeatureSample> phase30_build_feature_samples(
    const std::vector<HceRecord>& records);
[[nodiscard]] Phase30LossMetrics phase30_loss_metrics(
    const std::vector<Phase30FeatureSample>& samples,
    HceSplit split,
    const EvaluationWeights& weights,
    double score_scale = 400.0,
    std::size_t maximum_samples = 0);
[[nodiscard]] Phase30TuneReport phase30_coordinate_tune(
    const std::vector<Phase30FeatureSample>& samples,
    const Phase30TuneOptions& options = {},
    EvaluationWeights initial = {});
void write_phase30_json_report(
    const std::string& path,
    const Phase30FilterReport* filter,
    const Phase30TuneReport* tuning);

}  // namespace albay
