/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/move.hpp"
#include "albay/position.hpp"

namespace albay {

[[nodiscard]] bool generate_capture_moves(const Position& position, MoveList& output);
void generate_legal_moves(const Position& position, MoveList& output);
[[nodiscard]] MoveList generate_legal_moves(const Position& position);
[[nodiscard]] bool has_any_capture(const Position& position);
[[nodiscard]] bool has_any_quiet_move(const Position& position);
[[nodiscard]] bool is_legal_move(const Position& position, const Move& candidate);

}  // namespace albay
