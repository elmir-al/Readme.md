/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/endgame_solver.hpp"
#include "albay/exact_tablebase.hpp"
#include "albay/evaluation.hpp"
#include "albay/move.hpp"
#include "albay/nnue_runtime.hpp"
#include "albay/position.hpp"
#include "albay/quiet_ranking.hpp"
#include "albay/transposition_table.hpp"

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <stop_token>
#include <string>
#include <vector>

namespace albay {

inline constexpr int kMaxSearchDepth = 64;
inline constexpr int kMaxSearchPly = 96;
inline constexpr int kMaxMultiPV = 16;
inline constexpr std::size_t kEvaluationCacheSize = 1U << 14U;
inline constexpr std::array<int, 6> kSupportedThreadCounts{1, 2, 3, 4, 6, 8};

[[nodiscard]] constexpr bool is_supported_thread_count(int threads) noexcept {
    for (const int supported : kSupportedThreadCounts) {
        if (threads == supported) {
            return true;
        }
    }
    return false;
}

struct SearchLimits {
    int depth = 8;
    std::uint64_t nodes = 0;
    std::chrono::milliseconds move_time{0};
    bool infinite = false;
};

struct SearchOptions {
    bool use_aspiration_windows = true;
    bool use_pvs = true;
    bool use_transposition_table = true;
    bool use_full_capacity_tt = false;
    bool use_age_aware_tt_replacement = false;
    bool use_depth_preferred_tt_updates = false;
    bool use_countermove = true;
    bool use_late_move_reductions = true;
    bool use_evaluation_cache = true;
    bool use_capture_history = true;
    bool use_continuation_history = true;
    bool use_followup_history = true;
    bool use_piece_type_history = false;
    bool use_promotion_threat_ordering = false;
    bool use_history_malus = true;
    bool use_quiescence_tt = false;
    bool quiescence_tt_exact_only = false;
    bool use_quiescence_capture_malus = false;
    bool use_tactical_extensions = false;
    bool use_phase28_extension_policy = true;
    bool use_promotion_extensions = true;
    bool use_phase_aware_promotion_extension = true;
    bool use_single_reply_extensions = true;
    bool single_reply_quiet_only = false;
    bool use_dynamic_lmr = true;
    bool use_russian_lmr_v2 = false;
    bool use_lmr_priority_guard = true;
    bool use_lmr_forcing_capture_guard = false;
    bool use_razoring = true;
    bool use_static_futility_pruning = true;
    bool use_late_move_pruning = true;
    bool use_history_guarded_late_move_pruning = false;
    bool use_history_pruning = false;
    bool use_internal_iterative_reduction = false;
    bool use_adaptive_aspiration_windows = false;
    bool use_capture_signature_history = false;
    bool use_capture_continuation_history = false;
    bool use_recapture_ordering = false;
    bool use_recapture_extensions = false;
    bool use_forced_reply_extensions = false;
    bool use_forced_line_extensions = false;
    bool use_forcing_quiet_lmr_guard = false;
    bool use_quiet_sacrifice_extensions = false;
    bool use_endgame_reply_ordering = false;
    bool use_endgame_lmr_guard = false;
    bool use_promotion_quiescence = false;
    bool use_positional_quiet_ordering = false;
    bool use_strategic_quiet_ordering = false;
    bool strategic_quiet_opening_only = false;
    bool use_strategic_continuation_bias = false;
    bool use_exact_tablebase = false;
    bool exact_tablebase_probe_search = true;
    int exact_tablebase_max_pieces = 4;
    std::string exact_tablebase_path{};
    bool use_exact_endgame_solver = false;
    int exact_endgame_max_pieces = 4;
    std::uint64_t exact_endgame_node_limit = 2'000;
    bool exact_endgame_safe_probe_only = true;
    int tt_age_penalty_per_generation = 8;
    int tt_exact_bound_bonus = 4;
    int quiet_order_weight = 100;
    int positional_quiet_max_ply = kMaxSearchPly;
    int strategic_quiet_order_weight = 100;
    int strategic_quiet_max_ply = kMaxSearchPly;
    int strategic_continuation_weight = 100;
    int followup_history_weight = 15;
    int piece_type_history_weight = 100;
    int promotion_threat_order_bonus = 20'000;
    int capture_continuation_weight = 100;
    int recapture_order_bonus = 40'000;
    int recapture_extension_max_depth = 6;
    int forced_line_extension_max_depth = 8;
    int quiet_sacrifice_extension_max_depth = 6;
    int endgame_reply_order_max_pieces = 8;
    int endgame_reply_order_weight = 100;
    int endgame_lmr_guard_reply_threshold = 2;
    int tactical_max_extensions = 2;
    int promotion_extension_max_depth = 5;
    int promotion_extension_extra_max_pieces = 12;
    int promotion_extension_extra_max_kings = 0;
    int single_reply_extension_max_depth = 2;
    QuietOrderingWeights quiet_ordering_weights{};
    int aspiration_window = 40;
    int aspiration_min_depth = 3;
    int aspiration_growth_percent = 200;
    int aspiration_side_bias_percent = 50;
    int aspiration_volatility_scale_percent = 150;
    int aspiration_max_window = 240;
    int lmr_min_depth = 5;
    int lmr_move_threshold = 4;
    int lmr_history_threshold = 12'000;
    int lmr_deep_depth = 9;
    int lmr_deep_move_threshold = 8;
    int lmr_deep_history_threshold = 0;
    int lmr_max_reduction = 2;
    int lmr_phase_min_pieces = 13;
    int lmr_phase_max_pieces = 20;
    int lmr_phase_max_kings = 0;
    int lmr_phase_min_depth = 4;
    int lmr_phase_move_threshold = 5;
    int lmr_protected_history_threshold = 8'000;
    int lmr_negative_history_threshold = -2'000;
    int lmr_phase_deep_depth = 8;
    int lmr_phase_deep_move_threshold = 8;
    int razor_max_depth = 1;
    int razor_margin_base = 150;
    int razor_margin_per_depth = 150;
    int razor_min_pieces = 0;
    int razor_max_pieces = 19;
    int razor_max_time_ms = 1000; // 0 = no time-control limit; fixed-depth searches remain enabled
    int futility_max_depth = 1;
    int futility_margin_base = 160;
    int futility_margin_per_depth = 120;
    int futility_min_pieces = 0;
    int futility_max_pieces = 19;
    int late_move_pruning_max_depth = 3;
    int late_move_pruning_base_moves = 6;
    int late_move_pruning_history_threshold = -1;
    int late_move_pruning_min_pieces = 0;
    int late_move_pruning_max_pieces = 12;
    int history_pruning_max_depth = 2;
    int history_pruning_move_threshold = 8;
    int history_pruning_threshold = -4'000;
    int history_pruning_min_pieces = 0;
    int history_pruning_max_pieces = 19;
    int iir_min_depth = 7;
    int iir_reduction = 1;
    int iir_max_pieces = 19;
    int quiescence_promotion_max_extensions = 2;
    int strategic_evaluation_min_time_ms = 10;
    int multi_pv = 1;
    std::size_t hash_size_mb = 32;
    int threads = 1;
    int active_threads = 0; // 0 means all configured worker threads
    NnueRuntimeOptions nnue{};
    bool use_incremental_nnue = false;
    EvaluationWeights evaluation_weights = [] {
        EvaluationWeights weights{};
        weights.advanced_exposure = 50;
        weights.strategic_min_pieces = 13;
        weights.strategic_max_pieces = 20;
        weights.strategic_max_kings = 0;
        return weights;
    }();
};

struct PrincipalVariationLine {
    int rank = 1;
    Score score = 0;
    std::vector<Move> principal_variation;
};

struct SearchDiagnostics {
    std::uint64_t quiescence_nodes = 0;
    std::uint64_t quiescence_capture_nodes = 0;
    std::uint64_t quiescence_quiet_nodes = 0;
    std::uint64_t quiescence_quiet_move_generation_skips = 0;
    std::uint64_t evaluation_calls = 0;
    std::uint64_t evaluation_cache_hits = 0;
    std::uint64_t nnue_evaluations = 0;
    std::uint64_t nnue_fallback_evaluations = 0;
    std::uint64_t nnue_incremental_evaluations = 0;
    std::uint64_t nnue_full_refresh_evaluations = 0;
    std::uint64_t nnue_incremental_updates = 0;
    std::uint64_t beta_cutoffs = 0;
    std::uint64_t lmr_reductions = 0;
    std::uint64_t lmr_researches = 0;
    std::uint64_t lmr_priority_guards = 0;
    std::uint64_t lmr_forcing_capture_guards = 0;
    std::uint64_t razor_attempts = 0;
    std::uint64_t razor_cutoffs = 0;
    std::uint64_t futility_pruned_moves = 0;
    std::uint64_t history_pruned_moves = 0;
    std::uint64_t iir_reductions = 0;
    std::uint64_t aspiration_fail_lows = 0;
    std::uint64_t aspiration_fail_highs = 0;
    std::uint64_t aspiration_researches = 0;
    std::uint64_t late_move_pruning_events = 0;
    std::uint64_t late_move_pruned_moves = 0;
    std::uint64_t extensions_applied = 0;
    std::uint64_t extension_plies = 0;
    std::uint64_t tablebase_probes = 0;
    std::uint64_t tablebase_hits = 0;
    std::uint64_t tablebase_unsafe = 0;
    // Phase 32 Lazy-SMP 2.0 telemetry. These counters describe helper
    // contribution without changing the master-authoritative result contract.
    std::uint64_t smp_helpers_started = 0;
    std::uint64_t smp_helper_iterations = 0;
    std::uint64_t smp_root_hint_updates = 0;
    std::uint64_t smp_root_hint_uses = 0;
    std::uint64_t smp_synchronized_starts = 0;
};

struct SearchInfo {
    int depth = 0;
    int selective_depth = 0;
    Score score = 0;
    std::uint64_t nodes = 0;
    std::uint64_t nodes_per_second = 0;
    std::chrono::milliseconds elapsed{0};
    std::vector<Move> principal_variation;
    std::vector<PrincipalVariationLine> multipv;
    TTStatistics transposition_table{};
    SearchDiagnostics diagnostics{};
    int threads = 1;
    int active_threads = 0;
    int target_threads = 1;
    int parked_threads = 0;
    bool searching = false;
    bool paused = false;
};

struct SearchResult {
    std::optional<Move> best_move;
    Score score = 0;
    int completed_depth = 0;
    int selective_depth = 0;
    std::uint64_t nodes = 0;
    std::chrono::milliseconds elapsed{0};
    std::vector<Move> principal_variation;
    std::vector<PrincipalVariationLine> multipv;
    TTStatistics transposition_table{};
    SearchDiagnostics diagnostics{};
    int threads = 1;
    bool stopped = false;
};

using SearchInfoCallback = std::function<void(const SearchInfo&)>;

/**
 * Iterative deepening Alpha-Beta/PVS searcher with optional Lazy-SMP helpers.
 *
 * Thread 0 is authoritative and is the only thread that publishes PV/results.
 * Helper threads independently search the same root with deterministic ordering
 * diversification and share the race-safe transposition table.
 */
class Searcher {
public:
    Searcher();
    ~Searcher();

    Searcher(const Searcher&) = delete;
    Searcher& operator=(const Searcher&) = delete;

    [[nodiscard]] SearchResult search(
        const Position& root,
        const SearchLimits& limits = {},
        const SearchOptions& options = {},
        SearchInfoCallback callback = {},
        std::stop_token external_stop_token = {},
        const std::atomic<bool>* external_pause_requested = nullptr);

    void stop() noexcept;
    void pause() noexcept;
    void resume() noexcept;
    void clear_hash() noexcept;
    void set_hash_size_mb(std::size_t size_mb);
    void set_active_thread_limit(int threads) noexcept;

    [[nodiscard]] bool is_searching() const noexcept;
    [[nodiscard]] bool is_paused() const noexcept;
    [[nodiscard]] SearchInfo info() const;
    [[nodiscard]] std::size_t hash_size_mb() const noexcept;

private:
    struct RootResult {
        Score score = -kInfiniteScore;
        std::optional<Move> best_move;
    };

    struct SharedSearchState {
        explicit SharedSearchState(int configured_threads_value)
            : configured_threads(configured_threads_value) {}

        std::atomic<bool> stop_requested{false};
        std::atomic<bool> pause_requested{false};
        std::atomic<std::uint64_t> nodes{0};
        std::atomic<int> selective_depth{0};
        std::atomic<std::uint64_t> tt_probes{0};
        std::atomic<std::uint64_t> tt_hits{0};
        std::atomic<std::uint64_t> tt_cutoffs{0};
        std::atomic<std::uint64_t> tt_stores{0};
        std::atomic<int> active_threads{0};
        std::atomic<int> paused_threads{0};
        std::atomic<int> parked_threads{0};
        std::atomic<int> active_thread_limit{1};
        mutable std::mutex thread_policy_mutex;
        std::condition_variable thread_policy_condition;
        std::atomic<std::uint64_t> helper_iterations{0};
        std::atomic<std::uint64_t> root_hint_updates{0};
        std::atomic<std::uint64_t> root_hint_uses{0};
        std::atomic<std::uint64_t> synchronized_starts{0};
        mutable std::mutex root_hint_mutex;
        std::optional<Move> root_hint;
        Score root_hint_score = 0;
        int root_hint_depth = 0;
        int root_hint_worker = 0;
        int configured_threads = 1;
    };

    Searcher(std::shared_ptr<TranspositionTable> shared_table, bool helper_instance);

    [[nodiscard]] SearchResult search_internal(
        const Position& root,
        const SearchLimits& limits,
        const SearchOptions& options,
        SearchInfoCallback callback,
        std::stop_token external_stop_token,
        const std::atomic<bool>* external_pause_requested,
        std::shared_ptr<SharedSearchState> session_state,
        int worker_index);

    [[nodiscard]] RootResult search_root(Position& position, int depth, Score alpha, Score beta);
    [[nodiscard]] std::vector<PrincipalVariationLine> search_root_multipv(
        Position& position,
        int depth,
        int line_count);
    [[nodiscard]] Score negamax(
        Position& position,
        int depth,
        Score alpha,
        Score beta,
        int ply,
        bool pv_node,
        const Move* previous_move,
        const Move* previous_previous_move,
        int extensions_used);
    [[nodiscard]] Score quiescence(
        Position& position,
        Score alpha,
        Score beta,
        int ply,
        const Move* previous_move,
        int promotion_extensions = 0);

    void order_moves(
        const Position& position,
        MoveList& moves,
        int ply,
        const Move* pv_move,
        const MoveIdentity* tt_move,
        const Move* previous_move,
        const Move* previous_previous_move);
    [[nodiscard]] int move_order_score(
        const Position& position,
        const Move& move,
        int ply,
        const Move* pv_move,
        const MoveIdentity* tt_move,
        const Move* previous_move,
        const Move* previous_previous_move) const;
    [[nodiscard]] int quiet_positional_order_score(
        const Position& position,
        const Move& move) const noexcept;
    [[nodiscard]] int endgame_reply_order_score(
        const Position& position,
        const Move& move) const;
    [[nodiscard]] int capped_reply_count(
        const Position& child_position,
        int cap) const;
    void update_quiet_heuristics(
        const Position& position,
        Color mover,
        const Move& move,
        int depth,
        int ply,
        const Move* previous_move,
        const Move* previous_previous_move) noexcept;
    void update_capture_heuristics(
        Color mover,
        const Move& move,
        int depth,
        const Move* previous_move,
        const Move* previous_previous_move) noexcept;
    void apply_history_malus(
        const Position& position,
        Color mover,
        const Move& move,
        int depth,
        const Move* previous_move,
        const Move* previous_previous_move) noexcept;
    [[nodiscard]] int forced_reply_extension(
        Position& position,
        const Move& move,
        bool captured_king,
        int depth,
        int extensions_used) const;
    [[nodiscard]] int forced_line_extension(
        std::size_t legal_move_count,
        int depth,
        int extensions_used) const noexcept;
    [[nodiscard]] int recapture_extension(
        const Move& move,
        const Move* previous_move,
        int depth,
        int extensions_used) const noexcept;
    [[nodiscard]] int quiet_sacrifice_extension(
        const Position& child_position,
        const Move& move,
        int depth,
        int extensions_used,
        bool* forces_capture) const;
    [[nodiscard]] bool is_recapture(
        const Move& move,
        const Move* previous_move) const noexcept;
    [[nodiscard]] int tactical_extension(
        const Position& position,
        const Move& move,
        std::size_t legal_move_count,
        int depth,
        int extensions_used) const noexcept;
    [[nodiscard]] std::size_t capture_signature_index(const Move& move) const noexcept;
    [[nodiscard]] Score evaluate_cached(const Position& position, int ply = -1) noexcept;
    void initialize_nnue_accumulator(const Position& root) noexcept;
    void record_nnue_child(const Position& parent, const Move& move, int child_ply) noexcept;
    [[nodiscard]] const NnueAccumulator* ensure_nnue_accumulator(
        const Position& position, int ply) noexcept;
    void update_pv(int ply, const Move& move) noexcept;
    void clear_search_state() noexcept;
    void count_node(int ply) noexcept;
    void flush_node_counters() noexcept;
    [[nodiscard]] bool control_check_due() const noexcept;
    void publish_completed_iteration(
        int depth,
        Score score,
        const std::vector<Move>& pv,
        const std::vector<PrincipalVariationLine>& multipv);
    void publish_helper_root_hint(int depth, Score score, const Move& move) noexcept;
    [[nodiscard]] std::optional<Move> shared_root_hint(int requested_depth) noexcept;
    void apply_shared_smp_diagnostics(SearchDiagnostics& diagnostics) const noexcept;
    [[nodiscard]] bool check_control();
    [[nodiscard]] bool hard_limit_reached() const noexcept;
    [[nodiscard]] std::shared_ptr<SharedSearchState> shared_state() const noexcept {
        return std::atomic_load_explicit(&shared_state_owner_, std::memory_order_acquire);
    }
    // Stable non-owning session pointer for search-thread hot paths. The
    // owning shared_ptr is installed first and keeps this state alive for the
    // complete search session. A plain atomic pointer avoids shared_ptr
    // reference-count traffic at every node while remaining race-free.
    [[nodiscard]] SharedSearchState* session_state() const noexcept {
        return session_state_raw_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] std::uint64_t reported_nodes() const noexcept;
    [[nodiscard]] int reported_selective_depth() const noexcept;
    [[nodiscard]] bool all_active_threads_paused() const noexcept;
    [[nodiscard]] std::vector<Move> current_pv() const;
    [[nodiscard]] std::vector<Move> child_pv(int ply) const;
    [[nodiscard]] HashKey transposition_key(const Position& position) const noexcept;
    [[nodiscard]] bool transposition_allowed(const Position& position) const noexcept;
    [[nodiscard]] bool probe_tt(HashKey key, TTEntry& entry) noexcept;
    void store_tt(
        HashKey key,
        int depth,
        Score score,
        TTBound bound,
        const Move* best_move) noexcept;
    [[nodiscard]] TTStatistics current_tt_statistics() const noexcept;
    void stop_helpers() noexcept;
    void pause_helpers() noexcept;
    void resume_helpers() noexcept;
    void notify_helpers() noexcept;

    SearchLimits limits_{};
    SearchOptions options_{};
    bool use_default_evaluation_ = true;
    bool use_default_move_ordering_ = true;
    SearchInfoCallback callback_{};
    std::stop_token external_stop_token_{};
    const std::atomic<bool>* external_pause_requested_ = nullptr;
    std::chrono::steady_clock::time_point start_time_{};
    std::chrono::steady_clock::time_point deadline_{};

    std::atomic<bool> session_active_{false};
    std::atomic<bool> searching_{false};
    std::atomic<bool> stop_requested_{false};
    std::atomic<bool> pause_requested_{false};
    std::atomic<bool> paused_active_{false};
    std::atomic<bool> policy_parked_{false};
    std::atomic<std::uint64_t> nodes_{0};
    std::atomic<int> selective_depth_{0};
    std::uint64_t local_nodes_ = 0;
    std::uint64_t published_nodes_ = 0;
    int local_selective_depth_ = 0;
    int published_selective_depth_ = 0;

    mutable std::mutex control_mutex_;
    std::condition_variable control_condition_;

    mutable std::mutex info_mutex_;
    SearchInfo info_{};

    std::shared_ptr<TranspositionTable> transposition_table_;
    mutable std::mutex tt_lifecycle_mutex_;
    // C++11 portable atomic shared_ptr operations are used instead of
    // std::atomic<std::shared_ptr<T>>, which is not implemented by every
    // Android NDK libc++ configuration. Returning an owning snapshot keeps the
    // state alive during stop/pause/restart and removes raw-pointer races.
    mutable std::shared_ptr<SharedSearchState> shared_state_owner_{};
    std::atomic<SharedSearchState*> session_state_raw_{nullptr};
    bool helper_instance_ = false;
    int worker_index_ = 0;
    int root_piece_count_ = 0;
    int root_king_count_ = 0;
    bool root_has_capture_ = false;
    ExactEndgameTablebase exact_tablebase_{};

    mutable std::mutex helpers_mutex_;
    std::vector<Searcher*> active_helpers_{};

    std::uint64_t tt_probes_ = 0;
    std::uint64_t tt_hits_ = 0;
    std::uint64_t tt_cutoffs_ = 0;
    std::uint64_t tt_stores_ = 0;
    SearchDiagnostics diagnostics_{};

    std::optional<Move> iterative_pv_move_{};
    std::array<std::array<Move, kMaxSearchPly>, kMaxSearchPly> pv_table_{};
    std::array<int, kMaxSearchPly> pv_length_{};
    std::array<std::array<Move, 2>, kMaxSearchPly> killer_moves_{};
    std::array<std::array<std::array<int, kBoardSquares>, kBoardSquares>, 2> history_{};
    std::array<std::array<std::array<int, kBoardSquares>, kBoardSquares>, 2> capture_history_{};
    std::array<std::array<int, 4096>, 2> capture_signature_history_{};
    std::array<std::array<std::array<std::array<int, kBoardSquares>, kBoardSquares>, kBoardSquares>, 2> capture_continuation_history_{};
    std::array<std::array<std::array<std::array<int, kBoardSquares>, kBoardSquares>, kBoardSquares>, 2> continuation_history_{};
    std::array<std::array<std::array<std::array<int, kBoardSquares>, kBoardSquares>, kBoardSquares>, 2> followup_history_{};
    std::array<std::array<std::array<std::array<int, kBoardSquares>, kBoardSquares>, 2>, 2> piece_type_history_{};
    std::array<std::array<std::array<Move, kBoardSquares>, kBoardSquares>, 2> countermoves_{};

    struct EvaluationCacheEntry {
        HashKey key = 0;
        Score score = 0;
        bool valid = false;
    };
    std::array<EvaluationCacheEntry, kEvaluationCacheSize> evaluation_cache_{};
    std::array<NnueAccumulator, kMaxSearchPly + 1> nnue_accumulator_stack_{};
    std::array<Move, kMaxSearchPly + 1> nnue_move_stack_{};
    std::array<Bitboard, kMaxSearchPly + 1> nnue_parent_kings_stack_{};
    std::array<Color, kMaxSearchPly + 1> nnue_mover_stack_{};
    std::array<bool, kMaxSearchPly + 1> nnue_accumulator_ready_{};
    bool nnue_incremental_active_ = false;
};

}  // namespace albay
