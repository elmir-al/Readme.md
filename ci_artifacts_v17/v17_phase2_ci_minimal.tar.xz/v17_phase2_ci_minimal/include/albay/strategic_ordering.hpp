/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/move.hpp"
#include "albay/position.hpp"

namespace albay {

/** Learned, color-symmetric strategic value of a man on one square.
 *  Values are blended between opening and middlegame by material phase.
 *  Kings and endgame-only positions intentionally receive zero.
 */
[[nodiscard]] int strategic_man_square_value(
    const Position& position, Color color, Square square) noexcept;

/** Change in learned strategic PST value caused by a quiet man move. */
[[nodiscard]] int strategic_quiet_move_delta(
    const Position& position, const Move& move) noexcept;

/** Opening-only learned prior, faded to zero outside the opening phase. */
[[nodiscard]] int strategic_opening_quiet_move_delta(
    const Position& position, const Move& move) noexcept;

/**
 * Contextual prior used only by quiet move ordering and continuation history.
 * It combines the learned square delta with a small, deterministic relation to
 * the previous move. It never changes the static evaluation score.
 */
[[nodiscard]] int strategic_quiet_continuation_prior(
    const Position& position,
    const Move& move,
    const Move* previous_move) noexcept;

}  // namespace albay
