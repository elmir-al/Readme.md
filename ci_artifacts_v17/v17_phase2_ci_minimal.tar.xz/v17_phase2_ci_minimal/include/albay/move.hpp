/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/types.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <new>
#include <stdexcept>
#include <type_traits>
#include <utility>

namespace albay {

enum MoveFlag : std::uint8_t {
    MoveNone = 0,
    MoveCapture = 1U << 0U,
    MovePromotion = 1U << 1U,
    MoveMovingKing = 1U << 2U,
};

struct Move {
    Square from = kNoSquare;
    Square to = kNoSquare;
    std::array<Square, kMaxCaptureCount> landings{};
    std::array<Square, kMaxCaptureCount> captures{};
    std::uint8_t landing_count = 0;
    std::uint8_t capture_count = 0;
    std::uint8_t flags = MoveNone;

    [[nodiscard]] bool is_capture() const noexcept {
        return (flags & MoveCapture) != 0;
    }

    [[nodiscard]] bool is_promotion() const noexcept {
        return (flags & MovePromotion) != 0;
    }

    [[nodiscard]] bool moving_piece_was_king() const noexcept {
        return (flags & MoveMovingKing) != 0;
    }

    [[nodiscard]] Bitboard captured_mask() const noexcept {
        Bitboard mask = 0;
        for (std::uint8_t index = 0; index < capture_count; ++index) {
            mask |= bit(captures[index]);
        }
        return mask;
    }

    [[nodiscard]] bool operator==(const Move& other) const noexcept {
        if (from != other.from || to != other.to || landing_count != other.landing_count ||
            capture_count != other.capture_count || flags != other.flags) {
            return false;
        }
        for (std::uint8_t index = 0; index < landing_count; ++index) {
            if (landings[index] != other.landings[index]) {
                return false;
            }
        }
        for (std::uint8_t index = 0; index < capture_count; ++index) {
            if (captures[index] != other.captures[index]) {
                return false;
            }
        }
        return true;
    }
};

struct MoveIdentity {
    Bitboard captured = 0;
    Square from = kNoSquare;
    Square to = kNoSquare;
    std::uint8_t capture_count = 0;

    [[nodiscard]] static MoveIdentity from_move(const Move& move) noexcept {
        return {move.captured_mask(), move.from, move.to, move.capture_count};
    }

    [[nodiscard]] bool valid() const noexcept {
        return is_valid_square(from) && is_valid_square(to);
    }
};

[[nodiscard]] inline bool same_move_identity(const Move& first, const Move& second) noexcept {
    return first.from == second.from && first.to == second.to &&
        first.capture_count == second.capture_count && first.captured_mask() == second.captured_mask();
}

[[nodiscard]] inline bool same_move_identity(const Move& move, const MoveIdentity& identity) noexcept {
    return move.from == identity.from && move.to == identity.to &&
        move.capture_count == identity.capture_count && move.captured_mask() == identity.captured;
}

[[nodiscard]] inline bool same_move_identity(const MoveIdentity& identity, const Move& move) noexcept {
    return same_move_identity(move, identity);
}

class MoveList {
public:
    using value_type = Move;
    using iterator = Move*;
    using const_iterator = const Move*;

    // Most Russian-draughts positions have far fewer than 32 legal moves.
    // Keeping that common case inline avoids heap traffic, while the rare
    // high-branching capture position transparently grows to the original
    // 512-move capacity on the heap. This keeps recursive search frames small
    // enough for Android's worker-thread stack without reducing legality or
    // move-generation capacity.
    static constexpr std::size_t kInlineCapacity = 32;

    MoveList() noexcept = default;

    MoveList(const MoveList& other) {
        copy_from(other);
    }

    MoveList& operator=(const MoveList& other) {
        if (this != &other) {
            clear();
            copy_from(other);
        }
        return *this;
    }

    MoveList(MoveList&& other) noexcept {
        move_from(std::move(other));
    }

    MoveList& operator=(MoveList&& other) noexcept {
        if (this != &other) {
            clear();
            overflow_.reset();
            move_from(std::move(other));
        }
        return *this;
    }

    ~MoveList() noexcept = default;

    void clear() noexcept {
        // Move is trivially destructible. Keep an already allocated overflow
        // buffer for reuse within the same search node/list instance.
        size_ = 0;
    }

    void push_back(const Move& move) {
        emplace_back(move);
    }

    [[nodiscard]] std::size_t size() const noexcept {
        return size_;
    }

    [[nodiscard]] bool empty() const noexcept {
        return size_ == 0;
    }

    // Shrink the list without reallocating.
    void resize(std::size_t new_size) noexcept {
        if (new_size < size_) {
            size_ = new_size;
        }
    }

    [[nodiscard]] Move& operator[](std::size_t index) noexcept {
        return data()[index];
    }

    [[nodiscard]] const Move& operator[](std::size_t index) const noexcept {
        return data()[index];
    }

    [[nodiscard]] iterator begin() noexcept {
        return data();
    }

    [[nodiscard]] iterator end() noexcept {
        return data() + size_;
    }

    [[nodiscard]] const_iterator begin() const noexcept {
        return data();
    }

    [[nodiscard]] const_iterator end() const noexcept {
        return data() + size_;
    }

private:
    static_assert(std::is_trivially_copyable_v<Move>);
    static_assert(std::is_trivially_destructible_v<Move>);

    void ensure_overflow_storage() {
        if (overflow_) {
            return;
        }
        auto expanded = std::make_unique<Move[]>(kMaxMoves);
        for (std::size_t index = 0; index < size_; ++index) {
            expanded[index] = inline_data()[index];
        }
        overflow_ = std::move(expanded);
    }

    void copy_from(const MoveList& other) {
        if (other.size_ > kInlineCapacity || overflow_) {
            ensure_overflow_storage();
            for (std::size_t index = 0; index < other.size_; ++index) {
                overflow_[index] = other[index];
            }
        } else {
            for (std::size_t index = 0; index < other.size_; ++index) {
                ::new (static_cast<void*>(inline_data() + index)) Move(other[index]);
            }
        }
        size_ = other.size_;
    }

    void move_from(MoveList&& other) noexcept {
        size_ = other.size_;
        if (other.overflow_) {
            overflow_ = std::move(other.overflow_);
        } else {
            for (std::size_t index = 0; index < size_; ++index) {
                ::new (static_cast<void*>(inline_data() + index)) Move(std::move(other.inline_data()[index]));
            }
        }
        other.size_ = 0;
    }

    template <typename T>
    void emplace_back(T&& move) {
        if (size_ >= kMaxMoves) {
            throw std::overflow_error("Albay MoveList capacity exceeded");
        }
        if (size_ == kInlineCapacity && !overflow_) {
            ensure_overflow_storage();
        }
        if (overflow_) {
            overflow_[size_] = std::forward<T>(move);
        } else {
            // V17 hot path: construct only the moves that are actually emitted.
            // The previous std::array<Move, 32> member default-constructed and
            // zeroed every inline slot for every search node, even when a
            // position had only a handful of legal moves. Move is trivially
            // copyable/destructible, so placement construction in aligned raw
            // storage is both safe and removes that fixed per-node cost.
            ::new (static_cast<void*>(inline_data() + size_)) Move(std::forward<T>(move));
        }
        ++size_;
    }

    [[nodiscard]] Move* inline_data() noexcept {
        return std::launder(reinterpret_cast<Move*>(inline_storage_.data()));
    }

    [[nodiscard]] const Move* inline_data() const noexcept {
        return std::launder(reinterpret_cast<const Move*>(inline_storage_.data()));
    }

    [[nodiscard]] Move* data() noexcept {
        return overflow_ ? overflow_.get() : inline_data();
    }

    [[nodiscard]] const Move* data() const noexcept {
        return overflow_ ? overflow_.get() : inline_data();
    }

    alignas(Move) std::array<std::byte, sizeof(Move) * kInlineCapacity> inline_storage_;
    std::unique_ptr<Move[]> overflow_{};
    std::size_t size_ = 0;
};

// This is a release safety invariant: recursive search creates MoveList
// instances on the thread stack. A regression to a large inline buffer can
// overflow Android worker stacks and surface as SIGSEGV rather than a C++
// exception. Keep the per-frame container deliberately small.
static_assert(sizeof(MoveList) <= 2048, "MoveList is too large for recursive Android search frames");

}  // namespace albay
