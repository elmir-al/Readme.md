/*
Copyright © 2026 Elmir Hajizada
All rights reserved.

This software was independently designed and developed for the
Albay Russian Draughts Engine project.
*/
#pragma once

#include "albay/position.hpp"

#include <cstdint>
#include <utility>
#include <vector>

namespace albay {

[[nodiscard]] std::uint64_t perft(Position& position, int depth);
[[nodiscard]] std::vector<std::pair<Move, std::uint64_t>> perft_divide(Position& position, int depth);

}  // namespace albay
